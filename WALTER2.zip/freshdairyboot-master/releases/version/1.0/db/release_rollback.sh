#!/bin/sh
################################################################################
## File Details
################################################################################
## NAME:    Release Rollback
## FILE:    uweee/releases/version/1.0/db/release_rollback.sh
## RELEASE: 1.0

################################################################################
## Author Details
################################################################################
## AUTHOR:  John Dickerson
## CREATED: 15/10/2019

################################################################################
## Description
################################################################################
## This script is used for rolling back a release. If this fails please look
## in release_note_db.txt for how to restore the previous version of the 
## database

################################################################################
## Global Variables
################################################################################
VERSION=1.0
COMMENT_PREFIX=">>>>>>>>>> "
ENV=dev
MYSQL_USER=NOT_SET
MYSQL_PASSWORD=NOT_SET
MYSQL_DB=NOT_SET

################################################################################
## Functions
################################################################################
function getProperty {
   PROP_KEY=$1
   PROP_VALUE=`cat $PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2`
   echo $PROP_VALUE
}

################################################################################
## Read properties for environment
################################################################################
if [ $# -eq 0 ]
then
    echo "$COMMENT_PREFIX ERROR"
    echo "$COMMENT_PREFIX Please add argument [dev|test|prod]"
    echo "$COMMENT_PREFIX e.g ./release.sh prod"
    echo "$COMMENT_PREFIX EXITED"
    exit 1
else
    ENV=$1
    PROPERTY_FILE="../../../properties/$ENV.properties"
    echo "$COMMENT_PREFIX You are running this script in $ENV mode"
    echo "$COMMENT_PREFIX You are now running version $VERSION of release_rollback.sh"
    sleep 1
fi

if [ ! -f $PROPERTY_FILE ]
then
    echo "$COMMENT_PREFIX Cannot find properties file, $PROPERTY_FILE"
    echo "$COMMENT_PREFIX EXITED"
    exit 1
else
    MYSQL_USER=`getProperty "MYSQL_USER"`
    MYSQL_PASSWORD=`getProperty "MYSQL_PASSWORD"`
    MYSQL_DB=`getProperty "MYSQL_DB"`
    MYSQL_HOST=`getProperty "MYSQL_HOST"`
    MYSQL_PORT=`getProperty "MYSQL_PORT"`
    echo "$COMMENT_PREFIX MYSQL_USER = $MYSQL_USER"
    echo "$COMMENT_PREFIX MYSQL_PASSWORD = $MYSQL_PASSWORD"
    echo "$COMMENT_PREFIX MYSQL_DB = $MYSQL_DB"
    echo "$COMMENT_PREFIX MYSQL_HOST = $MYSQL_HOST"
    echo "$COMMENT_PREFIX MYSQL_PORT = $MYSQL_PORT"
fi

if [ -z "$MYSQL_USER" ]
then
    echo "$COMMENT_PREFIX Cannot find MYSQL_USER in $PROPERTY_FILE"
    echo "$COMMENT_PREFIX EXITED"
    exit 1
fi

if [ -z "$MYSQL_USER" ]
then
    echo "$COMMENT_PREFIX Cannot find MYSQL_USER in $PROPERTY_FILE"
    echo "$COMMENT_PREFIX EXITED"
    exit 1
fi

if [ -z "$MYSQL_DB" ]
then
    echo "$COMMENT_PREFIX Cannot find MYSQL_DB in $PROPERTY_FILE"
    echo "$COMMENT_PREFIX EXITED"
    exit 1
fi

################################################################################
## Confirm user wants to rollback
################################################################################
echo $COMMENT_PREFIX "$ENV mode.  Are you sure you wish to continue? ( yes / no )"
read answer

if [ "$answer" != "yes" ]
then
    echo "$COMMENT_PREFIX EXITED"
    exit 1
else
    echo "$COMMENT_PREFIX Executing scripts on DB"
    sleep 1
fi

################################################################################
## Execute SQL scripts
################################################################################
echo $COMMENT_PREFIX "Executing  0002_standing_data_rollback.sql"
PGPASSWORD=$MYSQL_PASSWORD MYSQL --host=$MYSQL_HOST  --port=$MYSQL_PORT -d $MYSQL_DB -U $MYSQL_USER -f 0002_insert_standing_data_rollback.sql

echo $COMMENT_PREFIX "Executing 0001_create_db_rollback.sql"
PGPASSWORD=$MYSQL_PASSWORD MYSQL --host=$MYSQL_HOST  --port=$MYSQL_PORT -d $MYSQL_DB -U $MYSQL_USER -f 0001_create_tables_rollback.sql

echo $COMMENT_PREFIX "Finished executing rollback SQL for release"

-- uweee/releases/version/1.0/db/0001_create_tables.sql

BEGIN WORK;



-- =================================================================================================
-- Start types =====================================================================================

CREATE TABLE `address_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `art_file_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `first_name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `art_template_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cc_inbox_message_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_experience_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `gd_inbox_message_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- End type
-- =================================================================================================

-- =================================================================================================
-- Start leaves ====================================================================================

CREATE TABLE `art_folders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `path` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `campaign_frequency_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `configurable_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `email_activation_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `entity_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `mailout_addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `campaign_list` tinyblob,
  `first_line` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `second_name` varchar(100) NOT NULL,
  `second_line` varchar(100) NOT NULL,
  `town_city` varchar(100) NOT NULL,
  `zip_postcode` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `recruitment_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(500) NOT NULL,
  `domain_organisation` tinyblob,
  `end` datetime NOT NULL,
  `name` varchar(30) NOT NULL,
  `start` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `states` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(50) NOT NULL,
  `postal_abbreviation` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_nau09mwrvhjj0n0a6gfo5xmp3` (`name`),
  UNIQUE KEY `UK_hi234a65wywc4blnvvckkcc5m` (`postal_abbreviation`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- End leaves ======================================================================================
-- =================================================================================================

CREATE TABLE `addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `first_line` varchar(100) NOT NULL,
  `second_line` varchar(100) NOT NULL,
  `town_city` varchar(100) NOT NULL,
  `zip_postcode` varchar(100) NOT NULL,
  `fk_address_types` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjtcibtel1ikjm8sl0gbtguu2c` (`fk_address_types`),
  CONSTRAINT `FKjtcibtel1ikjm8sl0gbtguu2c` FOREIGN KEY (`fk_address_types`) REFERENCES `address_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `domain_organisations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `domain` varchar(254) NOT NULL,
  `name` varchar(30) NOT NULL,
  `fk_address` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8i924t9pcmlfa7d23c3kaisk3` (`fk_address`),
  CONSTRAINT `FK8i924t9pcmlfa7d23c3kaisk3` FOREIGN KEY (`fk_address`) REFERENCES `addresses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `password_hash` varchar(256) NOT NULL,
  `fk_domain_organisation` int(10) unsigned NOT NULL,
  `fk_email_activation_code` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`),
  KEY `FKc702mx8s3uxrsxe13nsw38qtj` (`fk_domain_organisation`),
  KEY `FK9edxegpo3urtmmqsgtuuugl5i` (`fk_email_activation_code`),
  CONSTRAINT `FK9edxegpo3urtmmqsgtuuugl5i` FOREIGN KEY (`fk_email_activation_code`) REFERENCES `email_activation_codes` (`id`),
  CONSTRAINT `FKc702mx8s3uxrsxe13nsw38qtj` FOREIGN KEY (`fk_domain_organisation`) REFERENCES `domain_organisations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `art_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `path` varchar(1024) NOT NULL,
  `fk_arts` int(10) unsigned NOT NULL,
  `fk_art_file_types` int(10) unsigned NOT NULL,
  `fk_art_folders` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKadxx9un1elwsl77gnojx0s2ux` (`fk_arts`),
  KEY `FK5l2yxao61wcddwc2xj8t88ho1` (`fk_art_file_types`),
  KEY `FKr4tmne13oh368v2lwpwiejlti` (`fk_art_folders`),
  CONSTRAINT `FK5l2yxao61wcddwc2xj8t88ho1` FOREIGN KEY (`fk_art_file_types`) REFERENCES `art_file_types` (`id`),
  CONSTRAINT `FKadxx9un1elwsl77gnojx0s2ux` FOREIGN KEY (`fk_arts`) REFERENCES `arts` (`id`),
  CONSTRAINT `FKr4tmne13oh368v2lwpwiejlti` FOREIGN KEY (`fk_art_folders`) REFERENCES `art_folders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `art_folder_mappings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fk_campaign_clients` int(10) unsigned NOT NULL,
  `fk_art_folders_child` int(10) unsigned NOT NULL,
  `fk_art_folders_parent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKiy7mnjrp1uq9qfdwruxualx8l` (`fk_campaign_clients`),
  KEY `FK9jivi41cpy6k44b4j97ec5rmq` (`fk_art_folders_child`),
  KEY `FKq52xg69xa1obo9pqoj5v12a7p` (`fk_art_folders_parent`),
  CONSTRAINT `FK9jivi41cpy6k44b4j97ec5rmq` FOREIGN KEY (`fk_art_folders_child`) REFERENCES `art_folders` (`id`),
  CONSTRAINT `FKiy7mnjrp1uq9qfdwruxualx8l` FOREIGN KEY (`fk_campaign_clients`) REFERENCES `campaign_clients` (`id`),
  CONSTRAINT `FKq52xg69xa1obo9pqoj5v12a7p` FOREIGN KEY (`fk_art_folders_parent`) REFERENCES `art_folders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `art_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `fk_arts` int(10) unsigned NOT NULL,
  `fk_art_template_types` int(10) unsigned NOT NULL,
  `fk_domain_organisations` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKd4ep330ee5whbv13vf87kwbof` (`fk_arts`),
  KEY `FK3iyhjhwmw5c9vjurelnb408yd` (`fk_art_template_types`),
  KEY `FKko2gc1xxwei441idddgsw0b3f` (`fk_domain_organisations`),
  CONSTRAINT `FK3iyhjhwmw5c9vjurelnb408yd` FOREIGN KEY (`fk_art_template_types`) REFERENCES `art_template_types` (`id`),
  CONSTRAINT `FKd4ep330ee5whbv13vf87kwbof` FOREIGN KEY (`fk_arts`) REFERENCES `arts` (`id`),
  CONSTRAINT `FKko2gc1xxwei441idddgsw0b3f` FOREIGN KEY (`fk_domain_organisations`) REFERENCES `domain_organisations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `edits_locked` bit(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `note` varchar(200) NOT NULL,
  `number_edits` int(11) DEFAULT NULL,
  `fk_campaign_clients` int(10) unsigned NOT NULL,
  `fk_graphic_designers` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4xugjstayxoe9owjmh45d0x5k` (`fk_campaign_clients`),
  KEY `FK82xt47mdku3ij7xw5d0sn01c` (`fk_graphic_designers`),
  CONSTRAINT `FK4xugjstayxoe9owjmh45d0x5k` FOREIGN KEY (`fk_campaign_clients`) REFERENCES `campaign_clients` (`id`),
  CONSTRAINT `FK82xt47mdku3ij7xw5d0sn01c` FOREIGN KEY (`fk_graphic_designers`) REFERENCES `graphic_designers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `campaign` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(30) NOT NULL,
  `fk_campaign_clients` int(10) unsigned NOT NULL,
  `fk_campaign_frequency_types` int(10) unsigned NOT NULL,
  `fk_campaign_lists` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ktyf1tkuo57qs1vaevr3thf19` (`name`),
  KEY `FKky04gw1no5mqpoq8xlw5q5ooi` (`fk_campaign_clients`),
  KEY `FK2i957kysdsfcat3t64s1b1ubb` (`fk_campaign_frequency_types`),
  KEY `FK9gs9c75v3jhby0s3t11s9cs8v` (`fk_campaign_lists`),
  CONSTRAINT `FK2i957kysdsfcat3t64s1b1ubb` FOREIGN KEY (`fk_campaign_frequency_types`) REFERENCES `campaign_frequency_types` (`id`),
  CONSTRAINT `FK9gs9c75v3jhby0s3t11s9cs8v` FOREIGN KEY (`fk_campaign_lists`) REFERENCES `campaign_lists` (`id`),
  CONSTRAINT `FKky04gw1no5mqpoq8xlw5q5ooi` FOREIGN KEY (`fk_campaign_clients`) REFERENCES `campaign_clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `campaign_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `company_name` varchar(100) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `fk_addresses` int(10) unsigned NOT NULL,
  `fk_users` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKicybdqmewtyynfbevl36w5qfr` (`fk_addresses`),
  KEY `FKh5skykrrejct39l1pd2cux11q` (`fk_users`),
  CONSTRAINT `FKh5skykrrejct39l1pd2cux11q` FOREIGN KEY (`fk_users`) REFERENCES `users` (`id`),
  CONSTRAINT `FKicybdqmewtyynfbevl36w5qfr` FOREIGN KEY (`fk_addresses`) REFERENCES `addresses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci

CREATE TABLE `campaign_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(200) NOT NULL,
  `name` varchar(30) NOT NULL,
  `fk_campaign_clients` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6e16o06n7qwggvf8im9xs92xt` (`fk_campaign_clients`),
  CONSTRAINT `FK6e16o06n7qwggvf8im9xs92xt` FOREIGN KEY (`fk_campaign_clients`) REFERENCES `campaign_clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `campaign_months` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mail_out_date` datetime NOT NULL,
  `fk_arts` int(10) unsigned DEFAULT NULL,
  `fk_campaigns` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKll3mpu837fmbjdg3owxt1yx6g` (`fk_arts`),
  KEY `FKnj7gqlxv70s3rhtfgovc5nwe2` (`fk_campaigns`),
  CONSTRAINT `FKll3mpu837fmbjdg3owxt1yx6g` FOREIGN KEY (`fk_arts`) REFERENCES `arts` (`id`),
  CONSTRAINT `FKnj7gqlxv70s3rhtfgovc5nwe2` FOREIGN KEY (`fk_campaigns`) REFERENCES `campaign` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `campaignclients_graphicdesigners` (
  `campaignclients_id` int(10) unsigned NOT NULL,
  `graphicdesigners_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`campaignclients_id`,`graphicdesigners_id`),
  KEY `FKfpg4yoomw73djymnheaepdidd` (`graphicdesigners_id`),
  CONSTRAINT `FKfpg4yoomw73djymnheaepdidd` FOREIGN KEY (`graphicdesigners_id`) REFERENCES `graphic_designers` (`id`),
  CONSTRAINT `FKhl5qe488fquwtmfmu4g3d88dx` FOREIGN KEY (`campaignclients_id`) REFERENCES `campaign_clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cc_entry_refs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `primary_key` bigint(20) DEFAULT NULL,
  `fk_cc_inbox_messages` int(10) unsigned NOT NULL,
  `fk_entity_tables` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb1lwoy6q8cg4wm1ndt7fd7yoh` (`fk_cc_inbox_messages`),
  KEY `FKfbm7frxwfnohvha4j7bl3g445` (`fk_entity_tables`),
  CONSTRAINT `FKb1lwoy6q8cg4wm1ndt7fd7yoh` FOREIGN KEY (`fk_cc_inbox_messages`) REFERENCES `cc_inbox_messages` (`id`),
  CONSTRAINT `FKfbm7frxwfnohvha4j7bl3g445` FOREIGN KEY (`fk_entity_tables`) REFERENCES `entity_tables` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cc_inbox_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `messages` varchar(500) NOT NULL,
  `web_action_urls` varchar(200) NOT NULL,
  `fk_cc_inboxs` int(10) unsigned NOT NULL,
  `fk_cc_inbox_message_types` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlxdxyjs3vscg2tek86mah6y2c` (`fk_cc_inboxs`),
  KEY `FKr341ybtan9goroota53o9xuxu` (`fk_cc_inbox_message_types`),
  CONSTRAINT `FKlxdxyjs3vscg2tek86mah6y2c` FOREIGN KEY (`fk_cc_inboxs`) REFERENCES `cc_inboxs` (`id`),
  CONSTRAINT `FKr341ybtan9goroota53o9xuxu` FOREIGN KEY (`fk_cc_inbox_message_types`) REFERENCES `cc_inbox_message_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `cc_inboxs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `needs_notification` bit(1) NOT NULL,
  `fk_campaign_client` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgmbs25vake5bj8wtfqlp09fbn` (`fk_campaign_client`),
  CONSTRAINT `FKgmbs25vake5bj8wtfqlp09fbn` FOREIGN KEY (`fk_campaign_client`) REFERENCES `campaign_clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `cc_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message` varchar(500) NOT NULL,
  `readz` bit(1) NOT NULL,
  `fk_gd_messages` int(10) unsigned DEFAULT NULL,
  `fk_message_threads` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlkhyi7a6hrs37inrfpwq39dcb` (`fk_gd_messages`),
  KEY `FKtqwo4fn050grs6os8pcqhp151` (`fk_message_threads`),
  CONSTRAINT `FKlkhyi7a6hrs37inrfpwq39dcb` FOREIGN KEY (`fk_gd_messages`) REFERENCES `gd_messages` (`id`),
  CONSTRAINT `FKtqwo4fn050grs6os8pcqhp151` FOREIGN KEY (`fk_message_threads`) REFERENCES `message_threads` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `ccmessages_artfiles` (
  `ccmessage_id` int(10) unsigned NOT NULL,
  `artfiles_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ccmessage_id`,`artfiles_id`),
  KEY `FK4ooby09fdfy2wy0q35nlwmpw4` (`artfiles_id`),
  CONSTRAINT `FK4ooby09fdfy2wy0q35nlwmpw4` FOREIGN KEY (`artfiles_id`) REFERENCES `art_files` (`id`),
  CONSTRAINT `FK8nh9cpxyyuavhh213p3qckwar` FOREIGN KEY (`ccmessage_id`) REFERENCES `cc_messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `configurables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mail_out_day_of_month` int(11) DEFAULT NULL,
  `max_number_art_edits` int(11) DEFAULT NULL,
  `fk_configurable_group` int(10) unsigned NOT NULL,
  `fk_domain_organisation` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb4c04dfhtvmwu6y20fke5ayvn` (`fk_configurable_group`),
  KEY `FKekfgafuns21le1w77ye6s6gru` (`fk_domain_organisation`),
  CONSTRAINT `FKb4c04dfhtvmwu6y20fke5ayvn` FOREIGN KEY (`fk_configurable_group`) REFERENCES `configurable_groups` (`id`),
  CONSTRAINT `FKekfgafuns21le1w77ye6s6gru` FOREIGN KEY (`fk_domain_organisation`) REFERENCES `domain_organisations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `gd_entity_refs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `primary_key` bigint(20) DEFAULT NULL,
  `fk_entity_tables` int(10) unsigned NOT NULL,
  `fk_gd_invox_messages` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbc5ukan6os0sujhu1dkpqqdhg` (`fk_entity_tables`),
  KEY `FKr169pt94ni7ji7w740djyoi6s` (`fk_gd_invox_messages`),
  CONSTRAINT `FKbc5ukan6os0sujhu1dkpqqdhg` FOREIGN KEY (`fk_entity_tables`) REFERENCES `entity_tables` (`id`),
  CONSTRAINT `FKr169pt94ni7ji7w740djyoi6s` FOREIGN KEY (`fk_gd_invox_messages`) REFERENCES `gd_inbox_messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `gd_experiences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(500) NOT NULL,
  `end` datetime NOT NULL,
  `organisation` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `start` datetime NOT NULL,
  `fk_gd_experience_types` int(10) unsigned NOT NULL,
  `fk_gd_profiles` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKho97gixb3uq5g5apkw1kw75ue` (`fk_gd_experience_types`),
  KEY `FKmef77l7v8oqvuiwt08hliml26` (`fk_gd_profiles`),
  CONSTRAINT `FKho97gixb3uq5g5apkw1kw75ue` FOREIGN KEY (`fk_gd_experience_types`) REFERENCES `gd_experience_types` (`id`),
  CONSTRAINT `FKmef77l7v8oqvuiwt08hliml26` FOREIGN KEY (`fk_gd_profiles`) REFERENCES `gd_profiles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_inbox_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `messages` varchar(500) NOT NULL,
  `web_action_urls` varchar(200) NOT NULL,
  `fk_gd_inboxs` int(10) unsigned NOT NULL,
  `fk_gd_inbox_message_types` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqwk7u1o20br6agy3ev8y31xj0` (`fk_gd_inboxs`),
  KEY `FKtiqdpfud7bbmngvsqsecwqnnt` (`fk_gd_inbox_message_types`),
  CONSTRAINT `FKqwk7u1o20br6agy3ev8y31xj0` FOREIGN KEY (`fk_gd_inboxs`) REFERENCES `gd_inboxs` (`id`),
  CONSTRAINT `FKtiqdpfud7bbmngvsqsecwqnnt` FOREIGN KEY (`fk_gd_inbox_message_types`) REFERENCES `gd_inbox_message_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `gd_inboxs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `needs_notification` bit(1) NOT NULL,
  `fk_graphic_designers` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKd1hkkp3rsixa2rq6n3y3t1xfo` (`fk_graphic_designers`),
  CONSTRAINT `FKd1hkkp3rsixa2rq6n3y3t1xfo` FOREIGN KEY (`fk_graphic_designers`) REFERENCES `graphic_designers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message` varchar(500) DEFAULT NULL,
  `readz` tinyint(4) NOT NULL,
  `fk_cc_messages` int(10) unsigned DEFAULT NULL,
  `fk_message_threads` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6qwyyf9smrm25j59xna8n4jai` (`fk_cc_messages`),
  KEY `FK3sckjtu40rvtmgs6xfxwpl4ck` (`fk_message_threads`),
  CONSTRAINT `FK3sckjtu40rvtmgs6xfxwpl4ck` FOREIGN KEY (`fk_message_threads`) REFERENCES `message_threads` (`id`),
  CONSTRAINT `FK6qwyyf9smrm25j59xna8n4jai` FOREIGN KEY (`fk_cc_messages`) REFERENCES `cc_messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message` varchar(500) DEFAULT NULL,
  `readz` tinyint(4) NOT NULL,
  `fk_cc_messages` int(10) unsigned DEFAULT NULL,
  `fk_message_threads` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6qwyyf9smrm25j59xna8n4jai` (`fk_cc_messages`),
  KEY `FK3sckjtu40rvtmgs6xfxwpl4ck` (`fk_message_threads`),
  CONSTRAINT `FK3sckjtu40rvtmgs6xfxwpl4ck` FOREIGN KEY (`fk_message_threads`) REFERENCES `message_threads` (`id`),
  CONSTRAINT `FK6qwyyf9smrm25j59xna8n4jai` FOREIGN KEY (`fk_cc_messages`) REFERENCES `cc_messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `abstract_text` varchar(1024) NOT NULL,
  `fk_graphic_designers` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjit8jhko3wekxg5wvcl5s6wuw` (`fk_graphic_designers`),
  CONSTRAINT `FKjit8jhko3wekxg5wvcl5s6wuw` FOREIGN KEY (`fk_graphic_designers`) REFERENCES `graphic_designers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gd_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `examiner_note` varchar(1024) NOT NULL,
  `score` int(11) DEFAULT NULL,
  `fk_recruitment_run` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9jim1pb14r08hqajq1gqhybn6` (`fk_recruitment_run`),
  CONSTRAINT `FK9jim1pb14r08hqajq1gqhybn6` FOREIGN KEY (`fk_recruitment_run`) REFERENCES `recruitment_runs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `graphic_designers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `enabled` bit(1) NOT NULL,
  `passed_test` bit(1) NOT NULL,
  `fk_users` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKips7vys3f8hdgmbfogtolr7kl` (`fk_users`),
  CONSTRAINT `FKips7vys3f8hdgmbfogtolr7kl` FOREIGN KEY (`fk_users`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `gdmessages_artfiles` (
  `gdmessage_id` int(10) unsigned NOT NULL,
  `artfiles_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`gdmessage_id`,`artfiles_id`),
  KEY `FKr7cbdm9lnct9gmwqkymqbyplk` (`artfiles_id`),
  CONSTRAINT `FK67a7342hl43nvvfd8i0xv70x3` FOREIGN KEY (`gdmessage_id`) REFERENCES `gd_messages` (`id`),
  CONSTRAINT `FKr7cbdm9lnct9gmwqkymqbyplk` FOREIGN KEY (`artfiles_id`) REFERENCES `art_files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `gdprofiles_gdskills` (
  `gdprofiles_id` int(10) unsigned NOT NULL,
  `gdskills_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`gdprofiles_id`,`gdskills_id`),
  KEY `FK26oehlmflo8f2at3abt80vufg` (`gdskills_id`),
  CONSTRAINT `FK26oehlmflo8f2at3abt80vufg` FOREIGN KEY (`gdskills_id`) REFERENCES `gd_skills` (`id`),
  CONSTRAINT `FKme9r7wycnaexq930ygty3hijg` FOREIGN KEY (`gdprofiles_id`) REFERENCES `gd_profiles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `message_threads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fk_arts` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnogix7fheaolqd40onqk9n468` (`fk_arts`),
  CONSTRAINT `FKnogix7fheaolqd40onqk9n468` FOREIGN KEY (`fk_arts`) REFERENCES `arts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `roles_permissions` (
  `roles_id` int(10) unsigned NOT NULL,
  `permissions_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`roles_id`,`permissions_id`),
  KEY `FKk2kolv9g3n4hpk8i0i9ygf7w2` (`permissions_id`),
  CONSTRAINT `FKk2kolv9g3n4hpk8i0i9ygf7w2` FOREIGN KEY (`permissions_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `FKlfrs5jthiq0nvnp0uvfexbb5y` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `test_art_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `path` varchar(1024) NOT NULL,
  `score` int(11) DEFAULT NULL,
  `fk_test_art_templates` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhmaadxl7p4qkap794rsi4gf72` (`fk_test_art_templates`),
  CONSTRAINT `FKhmaadxl7p4qkap794rsi4gf72` FOREIGN KEY (`fk_test_art_templates`) REFERENCES `test_art_templates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `test_art_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(20) NOT NULL,
  `path_back` varchar(1024) NOT NULL,
  `path_front` varchar(1024) NOT NULL,
  `question` varchar(1024) NOT NULL,
  `fk_domain_organisation` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKj57scvek1i0uvc6xot0e01eil` (`fk_domain_organisation`),
  CONSTRAINT `FKj57scvek1i0uvc6xot0e01eil` FOREIGN KEY (`fk_domain_organisation`) REFERENCES `domain_organisations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `users_permissions` (
  `user_id` int(10) unsigned NOT NULL,
  `permissions_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`permissions_id`),
  KEY `FKbehn7jld0v03jhyjntnwsn8r7` (`permissions_id`),
  CONSTRAINT `FK69cfatgplsb0u6rxkfn14fv5b` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKbehn7jld0v03jhyjntnwsn8r7` FOREIGN KEY (`permissions_id`) REFERENCES `permissions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `forgotten_password` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` bit(1) NOT NULL,
  `code` varchar(255) NOT NULL,
  `fk_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbsowef8nr2wvuorqk2ejyh9ye` (`fk_user`),
  CONSTRAINT `FKbsowef8nr2wvuorqk2ejyh9ye` FOREIGN KEY (`fk_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci

COMMIT;
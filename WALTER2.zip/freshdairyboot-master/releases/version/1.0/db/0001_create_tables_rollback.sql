-- uweee/releases/version/1.0/db/0001_create_tables_rollback.sql

BEGIN WORK;

-- =====================

DROP TABLE rolegroup_role CASCADE;



-- =====================
  
COMMIT;
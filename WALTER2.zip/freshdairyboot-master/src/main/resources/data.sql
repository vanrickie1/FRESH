-- Start Sequence ==================================================================================
-- DROP Sequence uweee_sequence;
-- CREATE Sequence uweee_sequence START 10001;

-- End Sequence ====================================================================================
-- =================================================================================================

-- =================================================================================================
-- Start Fixed Standing Data =======================================================================

-- Domain Organisation -----------------------------------------------------------------------------
INSERT INTO domain_organisations (id, organisation_name, domain)
VALUES (1, 'Fresh_Dairy', 'ec2-3-84-83-205.compute-1.amazonaws.com');

-- ConfigurableGroup -------------------------------------------------------------------------------
INSERT INTO configurable_groups (id, name) VALUES (1, 'IMAGE');
INSERT INTO configurable_groups (id, name) VALUES (2, 'SECURITY');


-- Configurable ------------------------------------------------------------------------------------
INSERT INTO configurables (id, name, value, fk_configurable_groups, fk_domain_organisations) 
VALUES (1, 'image_minWidthArtInPixels', '1782', 1, 1);

INSERT INTO configurables (id, name, value, fk_configurable_groups, fk_domain_organisations) 
VALUES (2, 'image_maxWidthArtInPixels', '2175', 1, 1);

INSERT INTO configurables (id, name, value, fk_configurable_groups, fk_domain_organisations) 
VALUES (3, 'image_minHeightArtInPixels', '1282', 1, 1);

INSERT INTO configurables (id, name, value, fk_configurable_groups, fk_domain_organisations) 
VALUES (4, 'image_maxHeightArtInPixels', '1538', 1, 1);

INSERT INTO configurables (id, name, value, fk_configurable_groups, fk_domain_organisations) 
VALUES (5, 'security_minPasswordLength', '4', 2, 1);

INSERT INTO configurables (id, name, value, fk_configurable_groups, fk_domain_organisations) 
VALUES (6, 'security_maxPasswordLength', '10',  2, 1);


-- Role --------------------------------------------------------------------------------------------
INSERT INTO roles (id, name) VALUES (1, 'ADMIN');
INSERT INTO roles (id, name) VALUES (2, 'CLIENT');

-- Permission --------------------------------------------------------------------------------------
INSERT INTO permissions (id, name) VALUES (1, 'EMAIL_VALIDATED');
INSERT INTO permissions (id, name) VALUES (2, 'ADMIN');
INSERT INTO permissions (id, name) VALUES (3, 'CLIENT');

-- roles_permissions -------------------------------------------------------------------------------
-- Admin has EMAIL_VALIDATED
INSERT INTO roles_permissions (roles_id, permissions_id ) VALUES (1, 1);

-- Admin has ADMIN
INSERT INTO roles_permissions (roles_id, permissions_id ) VALUES (1, 2);

-- Client has Client
INSERT INTO roles_permissions (roles_id, permissions_id) VALUES (2, 3);


-- address_types -----------------------------------------------------------------------------------
INSERT INTO address_types (id, name) VALUES (1, 'Domain Organisation');
INSERT INTO address_types (id, name) VALUES (2, 'Client');

-- states ------------------------------------------------------------------------------------------
INSERT INTO states (id, name, postal_abbreviation) VALUES (1, 'Alabama', 'AL');
INSERT INTO states (id, name, postal_abbreviation) VALUES (2, 'Alaska', 'AK');
INSERT INTO states (id, name, postal_abbreviation) VALUES (3, 'Arizona', 'AZ');
INSERT INTO states (id, name, postal_abbreviation) VALUES (4, 'Arkansas', 'AR');
INSERT INTO states (id, name, postal_abbreviation) VALUES (5, 'California', 'CA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (6, 'Colorado', 'CO' );
INSERT INTO states (id, name, postal_abbreviation) VALUES (7, 'Connecticut', 'CT');
INSERT INTO states (id, name, postal_abbreviation) VALUES (8, 'Delaware', 'DE');
INSERT INTO states (id, name, postal_abbreviation) VALUES (9, 'Florida', 'FL');
INSERT INTO states (id, name, postal_abbreviation) VALUES (10, 'Georgia', 'GA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (11, 'Hawaii', 'HI');
INSERT INTO states (id, name, postal_abbreviation) VALUES (12, 'Idaho', 'ID');
INSERT INTO states (id, name, postal_abbreviation) VALUES (13, 'Illinoio', 'IL');
INSERT INTO states (id, name, postal_abbreviation) VALUES (14, 'Indiana', 'IN');
INSERT INTO states (id, name, postal_abbreviation) VALUES (15, 'Iowa', 'IA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (16, 'Kansas', 'KS');
INSERT INTO states (id, name, postal_abbreviation) VALUES (17, 'Kentucky', 'KY');
INSERT INTO states (id, name, postal_abbreviation) VALUES (18, 'Louisiana', 'LA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (19, 'Maine', 'ME');
INSERT INTO states (id, name, postal_abbreviation) VALUES (20, 'Maryland', 'MD');
INSERT INTO states (id, name, postal_abbreviation) VALUES (21, 'Massachusetts', 'MA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (22, 'Michigan', 'MI');
INSERT INTO states (id, name, postal_abbreviation) VALUES (23, 'Minnesota', 'MN');
INSERT INTO states (id, name, postal_abbreviation) VALUES (24, 'Mississippi', 'MS');
INSERT INTO states (id, name, postal_abbreviation) VALUES (25, 'Missouri', 'MO');
INSERT INTO states (id, name, postal_abbreviation) VALUES (26, 'Montana', 'MT');
INSERT INTO states (id, name, postal_abbreviation) VALUES (27, 'Nebraska', 'NE');
INSERT INTO states (id, name, postal_abbreviation) VALUES (28, 'Nevada', 'NV');
INSERT INTO states (id, name, postal_abbreviation) VALUES (29, 'New Hampshire', 'NH');
INSERT INTO states (id, name, postal_abbreviation) VALUES (30, 'New Jersey', 'NJ');
INSERT INTO states (id, name, postal_abbreviation) VALUES (31, 'New Mexico', 'NM');
INSERT INTO states (id, name, postal_abbreviation) VALUES (32, 'New York', 'NY');
INSERT INTO states (id, name, postal_abbreviation) VALUES (33, 'North Carolina', 'NC');
INSERT INTO states (id, name, postal_abbreviation) VALUES (34, 'North Dakota', 'ND');
INSERT INTO states (id, name, postal_abbreviation) VALUES (35, 'Ohio', 'OH');
INSERT INTO states (id, name, postal_abbreviation) VALUES (36, 'Oklahoma', 'OK');
INSERT INTO states (id, name, postal_abbreviation) VALUES (37, 'Oregon', 'OR');
INSERT INTO states (id, name, postal_abbreviation) VALUES (38, 'Pennsylvania', 'PA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (39, 'Rhode Island', 'RI');
INSERT INTO states (id, name, postal_abbreviation) VALUES (40, 'South Carolina', 'SC');
INSERT INTO states (id, name, postal_abbreviation) VALUES (41, 'South Dakota', 'SD');
INSERT INTO states (id, name, postal_abbreviation) VALUES (42, 'Tennessee', 'TN');
INSERT INTO states (id, name, postal_abbreviation) VALUES (43, 'Texas', 'TX');
INSERT INTO states (id, name, postal_abbreviation) VALUES (44, 'Utah', 'UT');
INSERT INTO states (id, name, postal_abbreviation) VALUES (45, 'Vermont', 'VT');
INSERT INTO states (id, name, postal_abbreviation) VALUES (46, 'Virginia', 'VA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (47, 'Washington', 'WA');
INSERT INTO states (id, name, postal_abbreviation) VALUES (48, 'West Virginia', 'WV');
INSERT INTO states (id, name, postal_abbreviation) VALUES (49, 'Wisconsin', 'WI');
INSERT INTO states (id, name, postal_abbreviation) VALUES (50, 'Wyoming', 'WY');

INSERT INTO art_file_types (id, name) VALUES (1, 'Front Art');
INSERT INTO art_file_types (id, name) VALUES (2, 'Back Art');


-- End Fixed Standing data
-- =================================================================================================

-- =================================================================================================
-- Start Dynamic Standing Data =====================================================================


-- End Dynamic Standing Data =======================================================================            
-- =================================================================================================

-- =================================================================================================
-- Start Not Used at moment ========================================================================



-- End Not Used at moment ==========================================================================
-- =================================================================================================


-- =================================================================================================
-- Start Test Standing Data =======================================================================
INSERT INTO email_activation_codes (id, created_at, updated_at, code) 
VALUES(1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '123456789');

INSERT INTO users (id, created_at, updated_at, email, enabled, first_name, last_name, password_hash, 
fk_domain_organisations, fk_email_activation_codes)
VALUES(1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'test@gmail.com', true, 
'FreshDairy', 'FreshDairy', '$2a$10$YRC673AMWLNmmLYjOHnUReIf/zWq6pWqNZYyXN.UKrh5YL8HwcLSW', 1, 1);

INSERT INTO users (id, created_at, updated_at, email, enabled, first_name, last_name, password_hash, 
fk_domain_organisations, fk_email_activation_codes)
VALUES(2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'gruenbergmark@gmail.com', true, 
'test', 'test', '$2a$10$o1Um9kTZGmOaCoS07RUZleFTuOaiXpP4pd85riKgK4058WLSFySbO', 1, 1);

INSERT INTO users (id, created_at, updated_at, email, enabled, first_name, last_name, password_hash, 
fk_domain_organisations, fk_email_activation_codes)
VALUES(3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'jorge@mantaproductions.com', true, 
'Jorge', 'Pease', '$2a$10$N8cXiwZU21sKabxT3bxJWu/kCfzHwZvi1Bkuh9ahgct64E7kqUpXG', 1, 1);

INSERT INTO addresses
(id, created_at, updated_at, apartment_suite, city, street_address, zip, fk_address_types, fk_states)
VALUES(1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'None', 'Newyork', '101', 10005, 2, 1);

INSERT INTO campaign_clients(id, created_at, updated_at, company_name, enabled, fk_addresses, fk_users)
VALUES(1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'Apptech', true, 1, 1);

INSERT INTO users_permissions (user_id, permissions_id ) VALUES (1, 1);
INSERT INTO users_permissions (user_id, permissions_id ) VALUES (1, 3);

INSERT INTO campaign_frequency_types (id, name ) VALUES (1, 'Single');
INSERT INTO campaign_frequency_types (id, name ) VALUES (2, 'Monthly');
INSERT INTO campaign_frequency_types (id, name ) VALUES (3, 'Quarterly');

-- End Test Standing Data =======================================================================


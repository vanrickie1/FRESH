/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.inbox.cc;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "cc_inboxs" )
public class CCInbox extends AbstractPersistentEntity {

    private static final long serialVersionUID = -374027473081837078L;

    @Column( name = "needs_notification", nullable = false,
            columnDefinition = "boolean default false" )
    private Boolean needsNotification;

    @OneToOne( )
    @JoinColumn( name = "fk_campaign_clients",
            foreignKey = @ForeignKey( name = "fk_campaignclients_ccinboxs" ),
            nullable = false )
    private CampaignClient campaignClient;


    public Boolean getNeedsNotification() {

        return needsNotification;
    }


    public void setNeedsNotification( Boolean needsNotification ) {

        this.needsNotification = needsNotification;
    }


    public CampaignClient getCampaignClient() {

        return campaignClient;
    }


    public void setCampaignClient( CampaignClient campaignClient ) {

        this.campaignClient = campaignClient;
    }
}

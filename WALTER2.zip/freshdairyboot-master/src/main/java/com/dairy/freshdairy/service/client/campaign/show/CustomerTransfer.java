/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.show;

/**
 * @author John Dickerson
 * @date 27 Oct 2019
 */
public class CustomerTransfer {

	private Long id;
	private String firstName;
	private String lastName;
	private String outlet;
	private String location;
	private String phoneNumber;
	private String productScanned;
	private String receiptNumber;

	public CustomerTransfer() {

	}

	public CustomerTransfer(Long id, String firstName, String lastName, String outlet, String location,
			String phoneNumber, String productScanned, String receiptNumber) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.outlet = outlet;
		this.location = location;
		this.phoneNumber = phoneNumber;
		this.productScanned = productScanned;
		this.receiptNumber = receiptNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOutlet() {
		return outlet;
	}

	public void setOutlet(String outlet) {
		this.outlet = outlet;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getProductScanned() {
		return productScanned;
	}

	public void setProductScanned(String productScanned) {
		this.productScanned = productScanned;
	}

	public String getReceiptNumber() {
		return receiptNumber;
	}

	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}

}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.filetype;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.dairy.freshdairy.service.client.campaign.art.FileTypeEnum;
import com.dairy.freshdairy.service.client.campaign.art.FileTypeTransfer;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
@Component
public class FileTypeHelperImpl implements FileTypeHelper {

    private List<FileTypeTransfer> createFileTypeTransfer( FileTypeEnum fileTypeEnum ) {

        String[] variants = fileTypeEnum.getVariants();

        List<FileTypeTransfer> fileTypeTransfers = new ArrayList<>();

        for ( String variant : variants ) {

            fileTypeTransfers.add( new FileTypeTransfer( fileTypeEnum.getId(), variant ) );
        }

        return fileTypeTransfers;
    }


    public FileTypeTransfer[] createFileTypeTransfers() {

        List<FileTypeTransfer> fileTypeTransfers = new ArrayList<>();

        FileTypeEnum[] fileTypeEnums = FileTypeEnum.values();

        for ( FileTypeEnum fileTypeEnum : fileTypeEnums ) {

            fileTypeTransfers.addAll( createFileTypeTransfer( fileTypeEnum ) );
        }

        return fileTypeTransfers.toArray( new FileTypeTransfer[fileTypeTransfers.size()] );
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.create;

/**
 * @author John Dickerson
 * @date   27 Oct 2019
 */
public class ClientCreateCampaignInitialData {

    private CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers;


    public ClientCreateCampaignInitialData() {

    }


    public ClientCreateCampaignInitialData(
            CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers ) {

        super();
        this.campaignFrequencyTypeTransfers = campaignFrequencyTypeTransfers;
    }


    public CampaignFrequencyTypeTransfer[] getCampaignFrequencyTypeTransfers() {

        return campaignFrequencyTypeTransfers;
    }


    public void setCampaignFrequencyTypeTransfers(
            CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers ) {

        this.campaignFrequencyTypeTransfers = campaignFrequencyTypeTransfers;
    }
}

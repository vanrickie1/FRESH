/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.campaignclient.campaign;

import java.util.HashMap;
import java.util.Map;

/**
 * @author John Dickerson
 * @date   13 Nov 2019
 */
public enum CampaignFrequencyTypeEnum {

    QUARTERLY( 1l ),
    MONTH( 2l ),
    SINGLE( 3l );

    private Long id;

    static Map<Long, CampaignFrequencyTypeEnum> campaignFrequencyTypeEnumById = new HashMap<>();

    static {

        for ( CampaignFrequencyTypeEnum campaignFrequencyTypeEnum : CampaignFrequencyTypeEnum
                .values() ) {

            campaignFrequencyTypeEnumById.put( campaignFrequencyTypeEnum.getId(),
                    campaignFrequencyTypeEnum );
        }
    }


    public static CampaignFrequencyTypeEnum getById( Long id ) {

        return campaignFrequencyTypeEnumById.get( id );
    }


    private CampaignFrequencyTypeEnum( Long id ) {

        this.id = id;
    }


    public Long getId() {

        return id;
    }


    public void setId( Long id ) {

        this.id = id;
    }
}

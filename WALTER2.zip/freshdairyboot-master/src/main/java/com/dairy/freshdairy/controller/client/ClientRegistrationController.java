/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dairy.freshdairy.service.client.registration.ClientRegistrationService;
import com.dairy.freshdairy.service.client.registration.DrawRequest;
import com.dairy.freshdairy.service.client.registration.DrawSaveResponse;
import com.dairy.freshdairy.service.client.registration.RegistrationInitialData;
import com.dairy.freshdairy.service.client.registration.RegistrationRequest;
import com.dairy.freshdairy.service.client.registration.RegistrationSaveResponse;
import com.dairy.freshdairy.threads.ThreadLocals;

/**
 * @author John Dickerson
 * @date 15 Oct 2019
 */
@RestController
@RequestMapping("/freshdairy/client/registration")
public class ClientRegistrationController {

	@Autowired
	private ClientRegistrationService clientRegistrationService;

	@RequestMapping(value = "/initialdata", method = RequestMethod.POST)
	public ResponseEntity<RegistrationInitialData> getInitialData() {

		RegistrationInitialData initialData = clientRegistrationService.getInitialData();
		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<RegistrationSaveResponse> save(@RequestBody RegistrationRequest request) {

		String domain = ThreadLocals.domainThreadLocal.get();
		Integer serverPort = ThreadLocals.portThreadLocal.get();
		String protocol = ThreadLocals.protocolThreadLocal.get();

		RegistrationSaveResponse saveResponse = clientRegistrationService.saveRegistrationRequest(request, domain,
				serverPort, protocol);

		return ResponseEntity.status(HttpStatus.OK).body(saveResponse);
	}

	@RequestMapping(value = "/draw/save", method = RequestMethod.POST)
	public ResponseEntity<DrawSaveResponse> saveDraw(@RequestBody DrawRequest request) {

		String domain = ThreadLocals.domainThreadLocal.get();
		Integer serverPort = ThreadLocals.portThreadLocal.get();
		String protocol = ThreadLocals.protocolThreadLocal.get();

		DrawSaveResponse saveResponse = clientRegistrationService.saveDrawRequest(request, domain, serverPort,
				protocol);

		return ResponseEntity.status(HttpStatus.OK).body(saveResponse);
	}
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.mailoutaddresscsv;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.QuoteMode;
import org.springframework.stereotype.Component;

/**
 * @author John Dickerson
 * @date   25 Oct 2019
 */
@Component
public class MailOutAddressCsvHelperImpl implements MailOutAddressCsvHelper {

    private void print( Appendable appendable, CSVFormat csvFormat,
            MailoutAddressTransfer[] mailOutAddressTransfers ) throws IOException {

        try ( CSVPrinter csvPrinter = new CSVPrinter( appendable, csvFormat )) {

            for ( MailoutAddressTransfer mailoutAddressTransfer : mailOutAddressTransfers ) {

                csvPrinter.printRecord(
                        mailoutAddressTransfer.getFullName(),
                        mailoutAddressTransfer.getStreetAddress(),
                        mailoutAddressTransfer.getApartmentSuite(),
                        mailoutAddressTransfer.getCity(),
                        mailoutAddressTransfer.getZip(),
                        mailoutAddressTransfer.getState() );
            }
        }
    }


    private MailoutAddressTransfer createMailoutAddressTransfer( CSVRecord record ) {

        String fullName = record.get( MailOutAddressCsvHelper.full_name );
        String streetAddress = record.get( MailOutAddressCsvHelper.street_address );
        String city = record.get( MailOutAddressCsvHelper.city );
        String state = record.get( MailOutAddressCsvHelper.state );
        String zip = record.get( MailOutAddressCsvHelper.zip );
        String apartmentSuite = record.get( MailOutAddressCsvHelper.apartment_suite );

        return new MailoutAddressTransfer( fullName, streetAddress, apartmentSuite,
                city, zip, state );
    }


    private MailoutAddressCsvHelperException createMailoutAddressCsvHelperException(
            IllegalArgumentException e ) {

        MailoutAddressCsvHelperException mailoutAddressCsvHelperException =
                new MailoutAddressCsvHelperException(
                        "Failed to parse CSV File because it was the wrong format", e );

        mailoutAddressCsvHelperException.setIncorrectFormatFile( true );

        if ( e.getCause() != null ) {

            mailoutAddressCsvHelperException.setFormatError( e.getCause().getMessage() );
        }

        return mailoutAddressCsvHelperException;
    }


    @Override
    public String createCsv( MailoutAddressTransfer[] mailOutAddressTransfers,
            String quote ) throws MailoutAddressCsvHelperException {

        try {
            StringWriter appendable = new StringWriter();
            CSVFormat csvFormat = CSVFormat.DEFAULT;
            csvFormat = csvFormat.withHeader( MailOutAddressCsvHelper.mailOutAddressHeaders );

            if ( quote != null && quote.length() > 0 ) {

                csvFormat = csvFormat.withQuote( quote.charAt( 0 ) );
                csvFormat = csvFormat.withQuoteMode( QuoteMode.ALL );
            }

            csvFormat = csvFormat.withDelimiter( ',' );
            csvFormat = csvFormat.withRecordSeparator( '\n' );
            csvFormat = csvFormat.withEscape( '\\' );
            print( appendable, csvFormat, mailOutAddressTransfers );
            return appendable.toString();
        }
        catch ( IOException e ) {

            throw new MailoutAddressCsvHelperException( "Failed to create CSV String", e );
        }
    }


    @Override
    public MailoutAddressTransfer[] createMailoutAddressTransfers( String csvString, String quote )
            throws MailoutAddressCsvHelperException {

        try {
            StringReader reader = new StringReader( csvString );
            CSVFormat csvFormat = CSVFormat.DEFAULT;
            csvFormat = csvFormat.withHeader( MailOutAddressCsvHelper.mailOutAddressHeaders );
            csvFormat = csvFormat.withFirstRecordAsHeader();

            if ( quote != null && quote.length() > 0 ) {

                csvFormat = csvFormat.withQuote( quote.charAt( 0 ) );
                csvFormat = csvFormat.withQuoteMode( QuoteMode.ALL );
            }

            csvFormat = csvFormat.withDelimiter( ',' );
            csvFormat = csvFormat.withRecordSeparator( '\n' );
            csvFormat = csvFormat.withEscape( '\\' );
            Iterable<CSVRecord> records = csvFormat.parse( reader );
            List<MailoutAddressTransfer> mailoutAddressTransfers = new ArrayList<>();

            for ( CSVRecord record : records ) {

                mailoutAddressTransfers.add( createMailoutAddressTransfer( record ) );
            }

            return mailoutAddressTransfers.toArray(
                    new MailoutAddressTransfer[mailoutAddressTransfers.size()] );
        }
        catch ( IllegalArgumentException e ) {

            throw createMailoutAddressCsvHelperException( e );
        }
        catch ( IOException e ) {
            throw new MailoutAddressCsvHelperException(
                    "Failed to parse CSV File", e );
        }
    }
}

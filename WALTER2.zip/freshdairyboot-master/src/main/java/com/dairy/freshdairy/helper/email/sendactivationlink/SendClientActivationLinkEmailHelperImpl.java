/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.email.sendactivationlink;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.mail.MailPreparationException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.email.AbstractEmailHelper;
import com.dairy.freshdairy.helper.email.EmailSentResponse;

import freemarker.template.Template;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
@Component
public class SendClientActivationLinkEmailHelperImpl extends AbstractEmailHelper implements
        SendClientActivationLinkEmailHelper {

    public SendClientActivationLinkEmailHelperImpl(
            FreeMarkerConfigurationFactoryBean freeMarkerConfigurationFactoryBean,
            SimpleMailMessage doNotReplyTemplateMessage ) {

        super( freeMarkerConfigurationFactoryBean, doNotReplyTemplateMessage );
    }


    private String createSubject( Locale locale, String messageyTpe ) {

        String subject = null;

        if ( messageyTpe.equals( SEND_CLIENT_ACTIVATION_LINK ) ) {

            subject = resourceBundleMessageSource.getMessage(
                    "SendClientActivationLinkEmailHelperImpl.subject",
                    new Object[] {}, locale );
        }

        return subject;

    }


    private void createSubjectModel( Map<String, Object> model,
            DomainOrganisation domainOrganisation, Locale locale, String messageType ) {

        String subject = createSubject( locale, messageType );

        String formattedSubject = MessageFormat.format( subject, domainOrganisation
                .getOrganisationName() );

        model.put( "subject", formattedSubject );
    }


    private String createBody( Locale locale, String messageType ) {

        String body = null;

        if ( messageType.equals( SEND_CLIENT_ACTIVATION_LINK ) ) {

            body = resourceBundleMessageSource.getMessage(
                    "SendClientActivationLinkEmailHelperImpl.body",
                    new Object[] {}, locale );
        }

        return body;

    }


    private void createBodyModel( Map<String, Object> model,
            DomainOrganisation organisation, Locale locale, User user, String messageType ) {

        String dear = resourceBundleMessageSource.getMessage(
                "SendClientActivationLinkEmailHelperImpl.dear", new Object[] {},
                locale );

        model.put( "dear", dear );
        model.put( "name", user.getFirstName() );
        String body = createBody( locale, messageType );
        String formattedBody = MessageFormat.format( body, organisation.getOrganisationName() );
        model.put( "body", formattedBody );
    }


    private String getFormattedProtocol( String protocol ) {

        StringBuilder link = new StringBuilder();
        link.append( protocol );
        link.append( "//" );
        return link.toString();
    }


    private void createActivateAccountLinkModel( Map<String, Object> model,
            String emailActivationCode, String domain, int serverPort,
            String protocol ) {

        String link = getFormattedProtocol( protocol ) + domain + ":"
                + serverPort + "/client/registration/activate?code=" + emailActivationCode;

        model.put( "link", link );
    }


    @Override
    public EmailSentResponse sendClientEmailActivationLink( DomainOrganisation domainOrganisation,
            User user, String emailTo, Locale locale, String domain, int serverPort,
            String protocol ) {

        String messageType = SEND_CLIENT_ACTIVATION_LINK;
        String templateName = "sendClientActivationLink.tfl";
        EmailSentResponse emailSentResponse;

        try {
            Template freeMarkerTemplate = this.configuration.getTemplate(
                    templateName );

            Map<String, Object> model = new HashMap<String, Object>();
            // createDateModel( model, locale );
            createSubjectModel( model, domainOrganisation, locale, messageType );
            createBodyModel( model, domainOrganisation, locale, user, messageType );

            createActivateAccountLinkModel( model, user.getEmailActivationCode().getCode(), domain,
                    serverPort, protocol );

            createFooterModel( model, domainOrganisation, locale );
            doNotReplyTemplateMessage.setTo( emailTo );
            // File emailLogoFile = getOrganisationLogo( organisation );
            File emailLogoFile = null;

            sendMessageInThread( doNotReplyTemplateMessage, model,
                    freeMarkerTemplate, emailLogoFile );

            emailSentResponse = new EmailSentResponse( Boolean.TRUE, "" );
        }
        catch ( IOException e ) {

            emailSentResponse = new EmailSentResponse( Boolean.FALSE, e
                    .getMessage() );

            throw new MailPreparationException(
                    "An I/O error occurred during composition " + "of email", e );
        }
        return emailSentResponse;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.email;

import java.util.Locale;

import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.email.EmailActivationResponse;
import com.dairy.freshdairy.helper.email.EmailSentResponse;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public interface EmailService {

    EmailSentResponse sendActivationEmail( DomainOrganisation organisation, User user,
            String email, Locale locale, String domain, int serverPort,
            String protocol );


    EmailActivationResponse activateUserEmail( String emailActivationCode );


    EmailSentResponse sendForgottenPasswordEmail(
            ForgottenPasswordRequest request, String domain, int serverPort,
            String protocol );
}

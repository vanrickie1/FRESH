/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.link;

/**
 * @author John Dickerson
 * @date   12 Nov 2019
 */
public class CampaignLinkInitialData {

    private String campaignName;
    private String campaignFrequencyType;
    private Long campaignId;
    private ArtTransfer[] arts;
    private ListTransfer[] lists;
    private CampaignMonthTransfer[] campaignMonths;


    public CampaignLinkInitialData() {

    }


    public CampaignLinkInitialData( String campaignName, String campaignFrequencyType,
            Long campaignId, ArtTransfer[] arts, ListTransfer[] lists,
            CampaignMonthTransfer[] campaignMonths ) {

        super();
        this.campaignName = campaignName;
        this.campaignFrequencyType = campaignFrequencyType;
        this.campaignId = campaignId;
        this.arts = arts;
        this.lists = lists;
        this.campaignMonths = campaignMonths;
    }


    public String getCampaignName() {

        return campaignName;
    }


    public void setCampaignName( String campaignName ) {

        this.campaignName = campaignName;
    }


    public String getCampaignFrequencyType() {

        return campaignFrequencyType;
    }


    public void setCampaignFrequencyType( String campaignFrequencyType ) {

        this.campaignFrequencyType = campaignFrequencyType;
    }


    public Long getCampaignId() {

        return campaignId;
    }


    public void setCampaignId( Long campaignId ) {

        this.campaignId = campaignId;
    }


    public ArtTransfer[] getArts() {

        return arts;
    }


    public void setArts( ArtTransfer[] arts ) {

        this.arts = arts;
    }


    public ListTransfer[] getLists() {

        return lists;
    }


    public void setLists( ListTransfer[] lists ) {

        this.lists = lists;
    }


    public CampaignMonthTransfer[] getCampaignMonths() {

        return campaignMonths;
    }


    public void setCampaignMonths( CampaignMonthTransfer[] campaignMonths ) {

        this.campaignMonths = campaignMonths;
    }
}

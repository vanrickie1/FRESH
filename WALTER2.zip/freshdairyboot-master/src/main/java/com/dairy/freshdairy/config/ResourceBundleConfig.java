/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.config;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * @author John Dickerson
 * @date   30th Sept 2019
 */
@Configuration
public class ResourceBundleConfig {

    @Bean
    public MessageSource resourceBundleMessageSource() {

        ResourceBundleMessageSource resourceBundleMessageSource =
                new ResourceBundleMessageSource();

        resourceBundleMessageSource.setBasenames( "email" );
        return resourceBundleMessageSource;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.repository.inbox.cc;

import org.springframework.data.repository.CrudRepository;

import com.dairy.freshdairy.domain.inbox.cc.CCInboxMessage;

/**
 * @author John Dickerson
 * @date   8 Oct 2019
 */
public interface CCInboxMessageRepository extends CrudRepository<CCInboxMessage, Long> {

}

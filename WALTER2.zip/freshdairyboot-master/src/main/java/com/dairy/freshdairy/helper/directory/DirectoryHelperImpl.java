/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.directory;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.dairy.freshdairy.helper.hash.HashHelper;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
public class DirectoryHelperImpl implements DirectoryHelper {

    @Autowired
    private HashHelper hashHelper;


    @Override
    public File createTempDirectory() throws IOException {

        String javaIOTempPath = System.getProperty( "java.io.tmpdir" );
        File tempDirectoryFile = new File( javaIOTempPath );
        File tempDir = new File( tempDirectoryFile, "enigma_" + hashHelper.getRandomHash() );
        boolean created = tempDir.mkdir();

        if ( !created ) {

            throw new IOException( "Could not create directory: " + tempDir );
        }

        return tempDir;
    }

}

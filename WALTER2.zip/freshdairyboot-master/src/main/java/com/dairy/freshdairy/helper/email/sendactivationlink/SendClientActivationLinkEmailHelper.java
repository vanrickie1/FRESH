/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.email.sendactivationlink;

import java.util.Locale;

import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.email.EmailSentResponse;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public interface SendClientActivationLinkEmailHelper {

    String SEND_CLIENT_ACTIVATION_LINK = "SEND_CLIENT_ACTIVATION_LINK";


    EmailSentResponse sendClientEmailActivationLink( DomainOrganisation domainOrganisation,
            User user, String emailTo, Locale locale, String domain,
            int serverPort, String protocol );
}

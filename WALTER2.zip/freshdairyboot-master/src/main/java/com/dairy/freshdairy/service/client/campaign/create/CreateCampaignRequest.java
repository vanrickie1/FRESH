/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.create;

/**
 * @author John Dickerson
 * @date   27 Oct 2019
 */
public class CreateCampaignRequest {

    private Long campaignFrequencyTypeId;
    private String campaignName;


    public CreateCampaignRequest() {

    }


    public CreateCampaignRequest( Long campaignFrequencyTypeId, String campaignName ) {

        super();
        this.campaignFrequencyTypeId = campaignFrequencyTypeId;
        this.campaignName = campaignName;
    }


    public Long getCampaignFrequencyTypeId() {

        return campaignFrequencyTypeId;
    }


    public void setCampaignFrequencyTypeId( Long campaignFrequencyTypeId ) {

        this.campaignFrequencyTypeId = campaignFrequencyTypeId;
    }


    public String getCampaignName() {

        return campaignName;
    }


    public void setCampaignName( String campaignName ) {

        this.campaignName = campaignName;
    }
}

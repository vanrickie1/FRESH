/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.client;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.zxing.WriterException;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.loggingin.LoggedInCredentialsHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.repository.domain.DomainOrganisationRepository;
import com.dairy.freshdairy.service.client.campaign.art.SaveArtResponse;
import com.dairy.freshdairy.service.client.campaign.art.create.ClientCreateArtInitialData;
import com.dairy.freshdairy.service.client.campaign.art.create.ClientCreateArtRequest;
import com.dairy.freshdairy.service.client.campaign.art.create.ClientCreateArtService;
import com.dairy.freshdairy.service.client.campaign.art.edit.ClientEditArtInitialData;
import com.dairy.freshdairy.service.client.campaign.art.edit.ClientEditArtRequest;
import com.dairy.freshdairy.service.client.campaign.art.edit.ClientEditArtService;
import com.dairy.freshdairy.service.client.campaign.art.show.ClientShowArtsService;
import com.dairy.freshdairy.service.client.campaign.art.show.ClientShowsArtInitialData;
import com.dairy.freshdairy.service.shared.transfer.DeleteResponse;
import com.dairy.freshdairy.threads.ThreadLocals;

/**
 * @author John Dickerson
 * @date 28 Oct 2019
 */
@RestController
@RequestMapping("/freshdairy/client/art")
public class ClientCampaignArtController {

	@Autowired
	private LoggedInCredentialsHelper loggedInCredentialsHelper;

	@Autowired
	private CampaignClientRepository campaignClientRepository;

	@Autowired
	private ClientCreateArtService clientCreateArtService;

	@Autowired
	private ClientEditArtService clientEditArtService;

	@Autowired
	private ClientShowArtsService clientShowArtsService;

	@Autowired
	private DomainOrganisationRepository domainOrganisationRepository;

	@RequestMapping(value = "/show/publicinitialdata", method = RequestMethod.POST)
	public ResponseEntity<ClientShowsArtInitialData> showArtToPublic() {

		User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();

		ClientShowsArtInitialData initialData = clientShowArtsService.getPublicInitialData();

		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/show/initialdata", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('CLIENT')")
	public ResponseEntity<ClientShowsArtInitialData> showArt() {

		User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();

		CampaignClient campaignClient = campaignClientRepository.findByUserId(loggedInUser.getId());

		ClientShowsArtInitialData initialData = clientShowArtsService.getInitialData(campaignClient.getId());

		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/create/initialdata", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('CLIENT')")
	public ResponseEntity<ClientCreateArtInitialData> getClientCreateArtInitialData() {

		ClientCreateArtInitialData initialData = clientCreateArtService.getInitialData();
		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/create/save", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('CLIENT')")
	public ResponseEntity<SaveArtResponse> saveArt(
			@RequestPart(name = "clientUploadArtRequest", required = true) ClientCreateArtRequest request,
			@RequestPart(name = "frontArt", required = true) MultipartFile frontMultipartFile) throws WriterException {

		User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();

		CampaignClient campaignClient = campaignClientRepository.findByUserId(loggedInUser.getId());

		String domain = ThreadLocals.domainThreadLocal.get();
		DomainOrganisation domainOrganisation = domainOrganisationRepository.findByDomain(domain);
		Long domainOrganisationId = domainOrganisation.getId();

		try {
			SaveArtResponse response = clientCreateArtService.save(domainOrganisationId, request, frontMultipartFile,
					campaignClient.getId());

			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (IOException e) {

			throw new RuntimeException("Error uploading art", e);
		}
	}

	@RequestMapping(value = "/edit/initialdata", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('CLIENT')")
	public ResponseEntity<ClientEditArtInitialData> getInitialData() {

		ClientEditArtInitialData initialData = clientEditArtService.getInitialData();
		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/edit/save", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('CLIENT')")
	public ResponseEntity<SaveArtResponse> saveArt(
			@RequestPart(name = "clientUploadArtRequest", required = true) ClientEditArtRequest request,
			@RequestPart(name = "backArt", required = true) MultipartFile backArtMultipartFile,
			@RequestPart(name = "frontArt", required = true) MultipartFile frontMultipartFile) {

		String domain = ThreadLocals.domainThreadLocal.get();
		DomainOrganisation domainOrganisation = domainOrganisationRepository.findByDomain(domain);
		Long domainOrganisationId = domainOrganisation.getId();

		try {
			SaveArtResponse response = clientEditArtService.save(domainOrganisationId, request, backArtMultipartFile,
					frontMultipartFile);

			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (IOException e) {

			throw new RuntimeException("Error uploading art", e);
		}
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	@PreAuthorize("hasAuthority('CLIENT')")
	public ResponseEntity<DeleteResponse> delete(@RequestBody Long artId) {

		return null;
	}
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.system.configurable;

/**
 * @author John Dickerson
 * @date   18 Oct 2019
 */
public enum ConfigurableEnum {

    image_minWidthArtInPixels,
    image_maxWidthArtInPixels,
    image_minHeightArtInPixels,
    image_maxHeightArtInPixels,

    security_minPasswordLength,
    security_maxPasswordLength;
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.edit;

import com.dairy.freshdairy.service.client.campaign.create.CampaignFrequencyTypeTransfer;

/**
 * @author John Dickerson
 * @date   30 Oct 2019
 */
public class ClientEditCampaignInitialData {

    private Long campaignId;
    private Long campaignFrequencyTypeId;
    private String campaignName;
    private CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers;


    public ClientEditCampaignInitialData() {

    }


    public ClientEditCampaignInitialData( Long campaignId, Long campaignFrequencyTypeId,
            String campaignName, CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers ) {

        super();
        this.campaignId = campaignId;
        this.campaignFrequencyTypeId = campaignFrequencyTypeId;
        this.campaignName = campaignName;
        this.campaignFrequencyTypeTransfers = campaignFrequencyTypeTransfers;
    }


    public Long getCampaignId() {

        return campaignId;
    }


    public void setCampaignId( Long campaignId ) {

        this.campaignId = campaignId;
    }


    public Long getCampaignFrequencyTypeId() {

        return campaignFrequencyTypeId;
    }


    public void setCampaignFrequencyTypeId( Long campaignFrequencyTypeId ) {

        this.campaignFrequencyTypeId = campaignFrequencyTypeId;
    }


    public String getCampaignName() {

        return campaignName;
    }


    public void setCampaignName( String campaignName ) {

        this.campaignName = campaignName;
    }


    public CampaignFrequencyTypeTransfer[] getCampaignFrequencyTypeTransfers() {

        return campaignFrequencyTypeTransfers;
    }


    public void setCampaignFrequencyTypeTransfers(
            CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers ) {

        this.campaignFrequencyTypeTransfers = campaignFrequencyTypeTransfers;
    }
}

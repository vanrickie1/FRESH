/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.forgottenpassword.reset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.user.ForgottenPassword;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.hash.HashHelper;
import com.dairy.freshdairy.repository.user.ForgottenPasswordRepository;
import com.dairy.freshdairy.repository.user.UserRepository;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;

/**
 * @author John Dickerson
 * @date   18 Oct 2019
 */
@Service
public class ResetUserForgottenPasswordServiceImpl implements ResetUserForgottenPasswordService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ForgottenPasswordRepository forgottenPasswordRepository;

    @Autowired
    private HashHelper hashHelper;


    @Override
    public SaveResponse resetUserForgottenPassword(
            UserResetForgottenPasswordRequest userResetForgottenPasswordRequest ) {

        SaveResponse saveUserResponse = null;

        User user = userRepository.findOne( userResetForgottenPasswordRequest
                .getUserId() );

        ForgottenPassword forgottenPassword = forgottenPasswordRepository
                .findByUserAndCode( user, userResetForgottenPasswordRequest
                        .getCode() );

        if ( forgottenPassword != null ) {

            if ( !forgottenPassword.getActive() ) {

                user.setPasswordHash( hashHelper.getPasswordHashWithBcrypt(
                        userResetForgottenPasswordRequest.getPassword() ) );

                userRepository.save( user );

                forgottenPassword.setActive( Boolean.TRUE );
                forgottenPasswordRepository.save( forgottenPassword );
                saveUserResponse = new SaveResponse( Boolean.TRUE, null );
            }
            else {
                saveUserResponse = new SaveResponse( Boolean.FALSE,
                        "The code has already been used. Please send "
                                + "another email to reset your password" );
            }

        }
        else {

            saveUserResponse = new SaveResponse( Boolean.FALSE,
                    "Invalid forgotten password reset link" );
        }

        return saveUserResponse;
    }


    @Override
    public VerificationResponse verifyForgottenPasswordResetCode(
            UserVerifyForgottenPasswordCodeRequest userVerifyForgottenPasswordCodeRequest ) {

        VerificationResponse verificationResponse = null;

        User user = userRepository.findOne(
                userVerifyForgottenPasswordCodeRequest.getUserId() );

        ForgottenPassword forgottenPassword = forgottenPasswordRepository
                .findByUserAndCode( user, userVerifyForgottenPasswordCodeRequest
                        .getCode() );

        if ( forgottenPassword != null ) {

            if ( forgottenPassword.getActive() ) {

                verificationResponse = new VerificationResponse( Boolean.TRUE,
                        userVerifyForgottenPasswordCodeRequest.getCode()
                                + " has already been used" );
            }
            else {

                verificationResponse = new VerificationResponse( Boolean.FALSE,
                        "Link is valid" );
            }

        }
        else {

            verificationResponse = new VerificationResponse( Boolean.FALSE,
                    null );
        }
        return verificationResponse;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.repository.user;

import org.springframework.data.repository.CrudRepository;

import com.dairy.freshdairy.domain.user.ForgottenPassword;
import com.dairy.freshdairy.domain.user.User;

/**
 * @author John Dickerson
 * @date   17 Oct 2019
 */
public interface ForgottenPasswordRepository extends CrudRepository<ForgottenPassword, Long> {

    ForgottenPassword findByUserEmail( String email );


    ForgottenPassword findByUserAndCode( User user, String code );
}

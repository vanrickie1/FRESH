/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.loggingin.LoggedInCredentialsHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.service.client.campaign.list.create.ClientCreateCampaignListInitialData;
import com.dairy.freshdairy.service.client.campaign.list.create.ClientCreateCampaignListRequest;
import com.dairy.freshdairy.service.client.campaign.list.create.ClientCreateCampaignListService;
import com.dairy.freshdairy.service.client.campaign.list.create.SaveMailAddressResponse;
import com.dairy.freshdairy.service.client.campaign.list.show.ClientShowListInitialData;
import com.dairy.freshdairy.service.client.campaign.list.show.ClientShowListService;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
@RestController
@RequestMapping( "/freshdairy/client/campaign/list" )
public class ClientCampaignListController {

    @Autowired
    private ClientCreateCampaignListService clientCreateCampaignListService;

    @Autowired
    private ClientShowListService clientShowListService;

    @Autowired
    private LoggedInCredentialsHelper loggedInCredentialsHelper;

    @Autowired
    private CampaignClientRepository campaignClientRepository;


    @RequestMapping( value = "/show/initialdata", method = RequestMethod.POST )
    @PreAuthorize( "hasAuthority('CLIENT')" )
    public ResponseEntity<ClientShowListInitialData> showLists() {

        User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();

        CampaignClient campaignClient =
                campaignClientRepository.findByUserId( loggedInUser.getId() );

        ClientShowListInitialData initialData =
                clientShowListService.getInitialData( campaignClient.getId() );

        return ResponseEntity.status( HttpStatus.OK ).body( initialData );
    }


    @RequestMapping( value = "/initialdata", method = RequestMethod.POST )
    @PreAuthorize( "hasAuthority('CLIENT')" )
    public ResponseEntity<ClientCreateCampaignListInitialData> getInitialData() {

        User user = loggedInCredentialsHelper.getLoggedInUser();
        CampaignClient campaignClient = campaignClientRepository.findByUserId( user.getId() );

        ClientCreateCampaignListInitialData initialData =
                clientCreateCampaignListService.getInitialData( campaignClient.getId() );

        return ResponseEntity.status( HttpStatus.OK ).body( initialData );
    }


    @RequestMapping( value = "/upload/csv", method = RequestMethod.POST )
    @PreAuthorize( "hasAuthority('CLIENT')" )
    public ResponseEntity<SaveMailAddressResponse> saveMailAddressList(
            @RequestPart( name = "clientCreateCampaignListRequest",
                    required = true ) ClientCreateCampaignListRequest request,
            @RequestPart( name = "mailAddressCsvFile",
                    required = true ) MultipartFile mailAddressCsvMultipartFile ) {

        User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();

        CampaignClient campaignClient =
                campaignClientRepository.findByUserId( loggedInUser.getId() );

        SaveMailAddressResponse response =
                clientCreateCampaignListService.save(
                        request, mailAddressCsvMultipartFile, campaignClient.getId() );

        return ResponseEntity.status( HttpStatus.OK ).body( response );
    }
}

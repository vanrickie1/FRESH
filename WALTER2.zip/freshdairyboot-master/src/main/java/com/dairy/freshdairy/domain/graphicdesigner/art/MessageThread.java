/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.art;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "message_threads" )
public class MessageThread extends AbstractPersistentEntity {

    private static final long serialVersionUID = 4797799773495280601L;

    @OneToOne( )
    @JoinColumn( name = "fk_arts",
            foreignKey = @ForeignKey( name = "fk_arts_messagethreads" ),
            nullable = false )
    private Art art;


    public Art getArt() {

        return art;
    }


    public void setArt( Art art ) {

        this.art = art;
    }
}

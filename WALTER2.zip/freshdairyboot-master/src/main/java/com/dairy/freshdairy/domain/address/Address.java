/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.address;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "addresses" )
public class Address extends AbstractPersistentEntity {

    private static final long serialVersionUID = 1232831972280207745L;

    @Column( name = "street_address", nullable = false, unique = false,
            length = 100 )
    private String streetAddress;

    @Column( name = "apartment_suite", nullable = true, unique = false,
            length = 100 )
    private String apartmentSuite;

    @Column( name = "city", nullable = false, unique = false,
            length = 100 )
    private String city;

    @Column( name = "zip", nullable = false, unique = false,
            length = 10 )
    private String zip;

    // fk_childtable_parenttable
    @ManyToOne( )
    @JoinColumn( name = "fk_address_types",
            foreignKey = @ForeignKey( name = "fk_addresstypes_addresses" ),
            nullable = false )
    private AddressType addressType;

    // fk_childtable_parenttable
    @ManyToOne( )
    @JoinColumn( name = "fk_states",
            foreignKey = @ForeignKey( name = "fk_states_addresses" ),
            nullable = false )
    private State state;


    public String getStreetAddress() {

        return streetAddress;
    }


    public void setStreetAddress( String streetAddress ) {

        this.streetAddress = streetAddress;
    }


    public String getApartmentSuite() {

        return apartmentSuite;
    }


    public void setApartmentSuite( String apartmentSuite ) {

        this.apartmentSuite = apartmentSuite;
    }


    public String getCity() {

        return city;
    }


    public void setCity( String city ) {

        this.city = city;
    }


    public String getZip() {

        return zip;
    }


    public void setZip( String zip ) {

        this.zip = zip;
    }


    public AddressType getAddressType() {

        return addressType;
    }


    public void setAddressType( AddressType addressType ) {

        this.addressType = addressType;
    }


    public State getState() {

        return state;
    }


    public void setState( State state ) {

        this.state = state;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.customer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;

/**
 * @author Ronald Kasaija
 * @date 6 Oct 2019
 */
@Entity
@Table(name = "customer")
public class Customer extends AbstractPersistentEntity {

	private static final long serialVersionUID = -8595477367479331631L;

	@Column(name = "first_name", nullable = false, unique = false, length = 100)
	private String firstName;

	@Column(name = "last_name", nullable = false, unique = false, length = 100)
	private String lastName;

	@Column(name = "outlet", nullable = false, unique = false, length = 100)
	private String outlet;

	@Column(name = "location", nullable = false, unique = false, length = 100)
	private String location;

	@Column(name = "phone_number", nullable = false, unique = false, length = 100)
	private String phoneNumber;

	@Column(name = "receipt_number", nullable = false, unique = true, length = 255)
	private String receiptNumber;

	@ManyToOne()
	@JoinColumn(name = "fk_arts", foreignKey = @ForeignKey(name = "fk_arts_artfiles"), nullable = false)
	private Art art;

	@OneToOne()
	@JoinColumn(name = "fk_domain_organisations", foreignKey = @ForeignKey(name = "fk_domainorganisations_users"), nullable = false)
	private DomainOrganisation domainOrganisation;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOutlet() {
		return outlet;
	}

	public void setOutlet(String outlet) {
		this.outlet = outlet;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getReceiptNumber() {
		return receiptNumber;
	}

	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}

	public Art getArt() {
		return art;
	}

	public void setArt(Art art) {
		this.art = art;
	}

	public DomainOrganisation getDomainOrganisation() {
		return domainOrganisation;
	}

	public void setDomainOrganisation(DomainOrganisation domainOrganisation) {
		this.domainOrganisation = domainOrganisation;
	}
}

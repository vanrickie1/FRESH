/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.user;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "email_activation_codes" )
public class EmailActivationCode extends AbstractPersistentEntity {
    
    private static final long serialVersionUID = 3316706146190799016L;
    
    private String code;
    
    public String getCode() {
    
        return code;
    }

    
    public void setCode( String code ) {
    
        this.code = code;
    }
}

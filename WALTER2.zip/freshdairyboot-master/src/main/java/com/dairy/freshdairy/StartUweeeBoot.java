/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy;

import java.util.Locale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

/**
 * @author John Dickerson
 * @date   30th Sept 2019
 */
@EntityScan( basePackages = { "com.dairy.freshdairy.domain" } )
@SpringBootApplication
public class StartUweeeBoot {

	public static void main( String[] args ) {

        Locale.setDefault( Locale.ENGLISH );
        SpringApplication.run( StartUweeeBoot.class, args );
    }
}

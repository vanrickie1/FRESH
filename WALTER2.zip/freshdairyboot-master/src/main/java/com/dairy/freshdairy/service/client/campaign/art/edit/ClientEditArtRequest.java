/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.edit;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
public class ClientEditArtRequest {

    private Long artId;;
    private String name;
    private String note;


    public ClientEditArtRequest() {

    }


    public ClientEditArtRequest( Long artId, String name, String note ) {

        super();
        this.artId = artId;
        this.name = name;
        this.note = note;
    }


    public Long getArtId() {

        return artId;
    }


    public void setArtId( Long artId ) {

        this.artId = artId;
    }


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getNote() {

        return note;
    }


    public void setNote( String note ) {

        this.note = note;
    }
}

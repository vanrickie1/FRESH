/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.customer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   17th October 2019
 */
@Entity
@Table( name = "forgotten_passwords" )
public class ForgottenPassword extends AbstractPersistentEntity {

    private static final long serialVersionUID = 82179788180707780L;

    @Column( name = "code", nullable = false, unique = false, length = 255 )
    private String code;

    @Column( name = "active", nullable = false )
    private Boolean active;

    @OneToOne
    @JoinColumn( name = "fk_users",
            foreignKey = @ForeignKey( name = "fk_users_forgottenpasswords" ),
            nullable = false )
    private Customer user;


    public String getCode() {

        return code;
    }


    public void setCode( String code ) {

        this.code = code;
    }


    public Boolean getActive() {

        return active;
    }


    public void setActive( Boolean active ) {

        this.active = active;
    }


    public Customer getUser() {

        return user;
    }


    public void setUser( Customer user ) {

        this.user = user;
    }


    @Override
    public int hashCode() {

        return super.hashCode();
    }


    @Override
    public boolean equals( Object obj ) {

        return super.equals( obj );
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.artfile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFile;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFileType;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFileTypeEnum;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtFileRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtFileTypeRepository;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
@Component
public class ArtFileHelperImpl implements ArtFileHelper {

    @Autowired
    private ArtFileTypeRepository artFileTypeRepository;

    @Autowired
    private ArtFileRepository artFileRepository;


    public void saveBackArtFile( Art art, String backPath ) {

        ArtFile backArtFile = new ArtFile();
        backArtFile.setArt( art );
        backArtFile.setPath( backPath );

        ArtFileType backArtFileType =
                artFileTypeRepository.findOne( ArtFileTypeEnum.BACK.getArtFileTypeId() );

        backArtFile.setArtFileType( backArtFileType );
        artFileRepository.save( backArtFile );
    }


    public void saveFrontArtFile( Art art, String frontPath ) {

        ArtFile frontArtFile = new ArtFile();
        frontArtFile.setArt( art );
        frontArtFile.setPath( frontPath );

        ArtFileType frontArtFileType =
                artFileTypeRepository.findOne( ArtFileTypeEnum.FRONT.getArtFileTypeId() );

        frontArtFile.setArtFileType( frontArtFileType );
        artFileRepository.save( frontArtFile );
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.loggingin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.repository.user.UserRepository;

@Component
public class LoggedInCredentialsHelperImpl implements
        LoggedInCredentialsHelper {

    @Autowired
    private UserRepository userRepository;


    @Override
    public User getLoggedInUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if ( authentication == null ) {

            return null;
        }

        String email = authentication.getName();
        User user = userRepository.findByEmail( email );
        return user;
    }
}

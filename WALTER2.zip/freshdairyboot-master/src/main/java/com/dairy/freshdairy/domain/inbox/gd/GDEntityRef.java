/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.inbox.gd;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.inbox.EntityTable;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "gd_entity_refs" )
public class GDEntityRef extends AbstractPersistentEntity {

    private static final long serialVersionUID = 3428839385370257626L;

    @Column( name = "entity_primary_key", nullable = true, unique = false )
    private Long entityPrimaryKey;

    @OneToOne( )
    @JoinColumn( name = "fk_entity_tables",
            foreignKey = @ForeignKey( name = "fk_entitytables_gdentryrefs" ),
            nullable = false )
    private EntityTable entityTable;

    @OneToOne( )
    @JoinColumn( name = "fk_gd_inbox_messages",
            foreignKey = @ForeignKey( name = "fk_gdinboxmessages_gdentryrefs" ),
            nullable = false )
    private GDInboxMessage gdInboxMessage;


    public Long getEntityPrimaryKey() {

        return entityPrimaryKey;
    }


    public void setEntityPrimaryKey( Long entityPrimaryKey ) {

        this.entityPrimaryKey = entityPrimaryKey;
    }


    public EntityTable getEntityTable() {

        return entityTable;
    }


    public void setEntityTable( EntityTable entityTable ) {

        this.entityTable = entityTable;
    }


    public GDInboxMessage getGdInboxMessage() {

        return gdInboxMessage;
    }


    public void setGdInboxMessage( GDInboxMessage gdInboxMessage ) {

        this.gdInboxMessage = gdInboxMessage;
    }
}

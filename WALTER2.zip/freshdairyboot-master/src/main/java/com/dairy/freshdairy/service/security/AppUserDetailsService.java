/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.security;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.domain.user.Permission;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.repository.user.UserRepository;

/**
 * @author John Dickerson
 * @date   7 Oct 2019
 */
@Component
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

//    @Autowired
//    private LoginHistoryRepository loginHistoryRepository;
//
//
//    private void saveToUserLoginHistory( User user ) {
//
//        Authentication auth = SecurityContextHolder.getContext()
//                .getAuthentication();
//
//        WebAuthenticationDetails details = ( WebAuthenticationDetails )auth
//                .getDetails();
//
//        String ipAddress = details.getRemoteAddress();
//        LoginHistory loginHistory = new LoginHistory();
//        loginHistory.setIpAddress( ipAddress );
//        loginHistory.setLoginDate( Calendar.getInstance() );
//        loginHistory.setUser( user );
//        loginHistoryRepository.save( loginHistory );
//    }


    @Override
    public UserDetails loadUserByUsername( String email )
            throws UsernameNotFoundException {

        String emailLower = email.toLowerCase();
        User user = userRepository.findByEmail( email );

        if ( user == null ) {
            throw new UsernameNotFoundException( String.format(
                    "The email %s doesn't exist", emailLower ) );
        }

        Set<Permission> permissions;

        if ( user.getEnabled()  == false ) {

            permissions = new HashSet<>();
        }
        else {

            permissions = user.getPermissions();
        }

        List<GrantedAuthority> authorities = new ArrayList<>();

        for ( Permission permission : permissions ) {

            authorities.add( new SimpleGrantedAuthority( permission.getName() ) );

        }

        UserDetails userDetails =
                new org.springframework.security.core.userdetails.User(
                        emailLower, user.getPasswordHash(), authorities );

        // saveToUserLoginHistory( user );
        return userDetails;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.edit;

import com.dairy.freshdairy.service.client.campaign.art.FileTypeTransfer;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
public class ClientEditArtInitialData {

    private FileTypeTransfer[] fileTypeTransfers;


    public ClientEditArtInitialData() {

    }


    public ClientEditArtInitialData( FileTypeTransfer[] fileTypeTransfers ) {

        super();
        this.fileTypeTransfers = fileTypeTransfers;
    }


    public FileTypeTransfer[] getFileTypeTransfers() {

        return fileTypeTransfers;
    }


    public void setFileTypeTransfers( FileTypeTransfer[] fileTypeTransfers ) {

        this.fileTypeTransfers = fileTypeTransfers;
    }
}

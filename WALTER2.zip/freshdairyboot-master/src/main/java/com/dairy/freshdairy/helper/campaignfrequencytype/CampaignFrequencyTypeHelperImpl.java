/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.campaignfrequencytype;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignFrequencyType;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignFrequencyTypeRepository;
import com.dairy.freshdairy.service.client.campaign.create.CampaignFrequencyTypeTransfer;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
@Component
public class CampaignFrequencyTypeHelperImpl implements CampaignFrequencyTypeHelper {

    @Autowired
    private CampaignFrequencyTypeRepository campaignFrequencyTypeRepository;


    public CampaignFrequencyTypeTransfer[] createCampaignFrequencyTypeTransfers() {

        Iterable<CampaignFrequencyType> campaignFrequencyTypes =
                campaignFrequencyTypeRepository.findAll();

        List<CampaignFrequencyTypeTransfer> campaignFrequencyTypeTransfers = new ArrayList<>();

        for ( CampaignFrequencyType campaignFrequencyType : campaignFrequencyTypes ) {

            campaignFrequencyTypeTransfers.add(
                    new CampaignFrequencyTypeTransfer(
                            campaignFrequencyType.getId(), campaignFrequencyType.getName() ) );
        }

        return campaignFrequencyTypeTransfers.toArray(
                new CampaignFrequencyTypeTransfer[campaignFrequencyTypeTransfers.size()] );
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.create;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.google.zxing.WriterException;
import com.dairy.freshdairy.service.client.campaign.art.SaveArtResponse;

/**
 * @author John Dickerson
 * @date 28 Oct 2019
 */
public interface ClientCreateArtService {

	String ART_NAMESPACE = "art";

	ClientCreateArtInitialData getInitialData();

	SaveArtResponse save(Long domainOrganisationId, ClientCreateArtRequest request, MultipartFile frontMultipartFile,
			Long campaignClientId) throws IOException, WriterException;
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.list.upload;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
@Service
public class ClientUploadAddressListServiceImpl implements ClientUploadAddressListService {

    private QuoteTypeTransfer createQuoteTypeTransfer( QuoteTypeEnum quoteTypeEnum ) {

        QuoteTypeTransfer transfer =
                new QuoteTypeTransfer( quoteTypeEnum.getQuoteId(),
                        quoteTypeEnum.getName() );

        return transfer;
    }


    private QuoteTypeTransfer[] createQuoteTransfers() {

        List<QuoteTypeTransfer> quoteTypeTransfers = new ArrayList<>();

        for ( QuoteTypeEnum quoteTypeEnum : QuoteTypeEnum.values() ) {

            quoteTypeTransfers.add( createQuoteTypeTransfer( quoteTypeEnum ) );
        }

        return quoteTypeTransfers.toArray( new QuoteTypeTransfer[quoteTypeTransfers.size()] );
    }


    @Override
    public ClientUploadAddressListInitialData getInitialData() {

        QuoteTypeTransfer[] quoteTransfers = createQuoteTransfers();

        ClientUploadAddressListInitialData initialData =
                new ClientUploadAddressListInitialData( quoteTransfers );

        return initialData;
    }

}

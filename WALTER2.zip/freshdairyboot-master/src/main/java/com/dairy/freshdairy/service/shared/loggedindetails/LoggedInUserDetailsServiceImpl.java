/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.loggedindetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.repository.user.UserRepository;

/**
 * @author John Dickerson
 * @date   18 Oct 2019
 */
@Service
public class LoggedInUserDetailsServiceImpl implements
        LoggedInUserDetailsService {

    @Autowired
    private UserRepository userRepository;


    @Override
    public LoggedInUserDetails getLoggedInUserDetails( Long userId ) {

        User user = userRepository.findOne( userId );

        LoggedInUserDetails loggedInDetails = new LoggedInUserDetails( user
                .getId(), user.getFirstName() );

        return loggedInDetails;
    }
}

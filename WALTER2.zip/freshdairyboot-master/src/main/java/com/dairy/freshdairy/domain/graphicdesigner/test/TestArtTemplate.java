/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "test_art_templates" )
public class TestArtTemplate extends AbstractPersistentEntity {

    private static final long serialVersionUID = -2802266690210815341L;

    @Column( name = "name", nullable = false, unique = false, length = 20 )
    private String name;

    @Column( name = "path_front", nullable = false, unique = false, length = 1024 )
    private String pathFront;

    @Column( name = "path_back", nullable = false, unique = false, length = 1024 )
    private String pathBack;

    @Column( name = "question", nullable = false, unique = false, length = 1024 )
    private String question;

    @ManyToOne( )
    @JoinColumn( name = "fk_domain_organisations",
            foreignKey = @ForeignKey( name = "fk_domainorganisations_testarttemplates" ),
            nullable = false )
    private DomainOrganisation domainOrganisation;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getPathFront() {

        return pathFront;
    }


    public void setPathFront( String pathFront ) {

        this.pathFront = pathFront;
    }


    public String getPathBack() {

        return pathBack;
    }


    public void setPathBack( String pathBack ) {

        this.pathBack = pathBack;
    }


    public String getQuestion() {

        return question;
    }


    public void setQuestion( String question ) {

        this.question = question;
    }


    public DomainOrganisation getDomainOrganisation() {

        return domainOrganisation;
    }


    public void setDomainOrganisation( DomainOrganisation domainOrganisation ) {

        this.domainOrganisation = domainOrganisation;
    }
}

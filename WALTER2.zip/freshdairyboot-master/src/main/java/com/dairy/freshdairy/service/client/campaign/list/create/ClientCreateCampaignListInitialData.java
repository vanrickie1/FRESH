/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.list.create;

import java.math.BigDecimal;

import com.dairy.freshdairy.service.client.campaign.list.upload.QuoteTypeTransfer;
import com.dairy.freshdairy.service.shared.transfer.StateTransfer;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
public class ClientCreateCampaignListInitialData {

    private StateTransfer stateTransfer;
    private ZipTransfer[] zipTransfers;
    private FilterTransfer filterTransfer;
    private QuoteTypeTransfer[] quoteTypeTransfers;
    private BigDecimal mailoutUnitCost;


    public ClientCreateCampaignListInitialData() {

    }


    public ClientCreateCampaignListInitialData( StateTransfer stateTransfer,
            ZipTransfer[] zipTransfers, FilterTransfer filterTransfer,
            QuoteTypeTransfer[] quoteTypeTransfers, BigDecimal mailoutUnitCost ) {

        super();
        this.stateTransfer = stateTransfer;
        this.zipTransfers = zipTransfers;
        this.filterTransfer = filterTransfer;
        this.quoteTypeTransfers = quoteTypeTransfers;
        this.mailoutUnitCost = mailoutUnitCost;
    }


    public StateTransfer getStateTransfer() {

        return stateTransfer;
    }


    public void setStateTransfer( StateTransfer stateTransfer ) {

        this.stateTransfer = stateTransfer;
    }


    public ZipTransfer[] getZipTransfers() {

        return zipTransfers;
    }


    public void setZipTransfers( ZipTransfer[] zipTransfers ) {

        this.zipTransfers = zipTransfers;
    }


    public FilterTransfer getFilterTransfer() {

        return filterTransfer;
    }


    public void setFilterTransfer( FilterTransfer filterTransfer ) {

        this.filterTransfer = filterTransfer;
    }


    public QuoteTypeTransfer[] getQuoteTypeTransfers() {

        return quoteTypeTransfers;
    }


    public void setQuoteTypeTransfers( QuoteTypeTransfer[] quoteTypeTransfers ) {

        this.quoteTypeTransfers = quoteTypeTransfers;
    }


    public BigDecimal getMailoutUnitCost() {

        return mailoutUnitCost;
    }


    public void setMailoutUnitCost( BigDecimal mailoutUnitCost ) {

        this.mailoutUnitCost = mailoutUnitCost;
    }
}

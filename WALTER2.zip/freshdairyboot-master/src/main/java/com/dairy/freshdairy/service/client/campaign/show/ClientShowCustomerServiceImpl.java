/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.show;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.customer.Customer;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.repository.customer.CustomerRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;

/**
 * @author John Dickerson
 * @date 27 Oct 2019
 */
@Service
public class ClientShowCustomerServiceImpl implements ClientShowCustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ArtRepository artRepository;

	private CustomerTransfer createCustomerTransfer(Customer customer) {

		Art art = artRepository.findOne(customer.getArt().getId());

		Long customerId = customer.getId();
		String firstName = customer.getFirstName();
		String lastName = customer.getLastName();
		String outlet = customer.getOutlet();
		String location = customer.getLocation();
		String phoneNumber = customer.getPhoneNumber();
		String receiptNumber = customer.getReceiptNumber();
		String artName = art.getName();

		CustomerTransfer customerTransfer = new CustomerTransfer(customerId, firstName, lastName, outlet, location,
				phoneNumber, artName, receiptNumber);

		return customerTransfer;

	}

	private CustomerTransfer[] createCustomerTransfers(Set<Customer> customers) {

		List<CustomerTransfer> customerTransfers = new ArrayList<>();

		for (Customer customer : customers) {

			customerTransfers.add(createCustomerTransfer(customer));
		}

		return customerTransfers.toArray(new CustomerTransfer[customerTransfers.size()]);
	}

	private CustomerTransfer[] createCustomerTransfers() {

		Set<Customer> customers = customerRepository.findAll();
		CustomerTransfer[] customerTransfers = createCustomerTransfers(customers);
		return customerTransfers;
	}

	@Override
	public ClientShowCustomerInitialData getInitialData() {

		CustomerTransfer[] customerTransfers = createCustomerTransfers();

		ClientShowCustomerInitialData initialData = new ClientShowCustomerInitialData(customerTransfers);

		return initialData;
	}
}

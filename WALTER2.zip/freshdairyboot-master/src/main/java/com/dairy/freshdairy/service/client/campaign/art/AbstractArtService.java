/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.beans.factory.annotation.Autowired;

import com.dairy.freshdairy.helper.image.ImageHelper;
import com.dairy.freshdairy.service.system.configurable.CacheImageGroup;
import com.dairy.freshdairy.service.system.configurable.ConfigurableService;

/**
 * @author John Dickerson
 * @date 10 Nov 2019
 */
public class AbstractArtService {

	@Autowired
	private ImageHelper imageHelper;

	@Autowired
	private ConfigurableService configurableService;

	private void checkBackDimensions(StringBuilder errorMessage, Integer actualWidthBackPixels,
			Integer actualHeightBackPixels, Integer allowedMinWidthPixels, Integer allowedMaxWidthPixels,
			Integer allowedMinHeightPixels, Integer allowedMaxHeightPixels, AtomicBoolean saved,
			AtomicBoolean incorrectDimensions) {

		if (actualWidthBackPixels.intValue() > allowedMaxWidthPixels.intValue()) {

			errorMessage.append("Back width should be less than ").append(allowedMaxWidthPixels);
			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		} else if (actualWidthBackPixels.intValue() < allowedMinWidthPixels.intValue()) {

			errorMessage.append("Back width should be more than ").append(allowedMaxWidthPixels);

			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		}

		if (actualHeightBackPixels.intValue() > allowedMaxHeightPixels.intValue()) {

			errorMessage.append("Back height should be less than ").append(allowedMaxHeightPixels);
			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		} else if (actualHeightBackPixels.intValue() < allowedMinHeightPixels.intValue()) {

			errorMessage.append("Back width should be more than ").append(allowedMaxWidthPixels);
			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		}
	}

	private void checkFrontDimensions(StringBuilder errorMessage, Integer actualWidthFrontPixels,
			Integer actualHeightFrontPixels, Integer allowedMinWidthPixels, Integer allowedMaxWidthPixels,
			Integer allowedMinHeightPixels, Integer allowedMaxHeightPixels, AtomicBoolean saved,
			AtomicBoolean incorrectDimensions) {

		if (actualWidthFrontPixels.intValue() > allowedMaxWidthPixels.intValue()) {

			errorMessage.append("Front width should be less than ").append(allowedMaxWidthPixels);

			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		} else if (actualWidthFrontPixels.intValue() < allowedMinWidthPixels.intValue()) {

			errorMessage.append("Front width should be more than ").append(allowedMaxWidthPixels);

			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		}

		if (actualHeightFrontPixels.intValue() > allowedMaxHeightPixels.intValue()) {

			errorMessage.append("Front height should be less than ").append(allowedMaxHeightPixels);

			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		} else if (actualHeightFrontPixels.intValue() < allowedMinHeightPixels.intValue()) {

			errorMessage.append("Front height should be more than ").append(allowedMaxWidthPixels);

			errorMessage.append("<br/>");
			saved.set(Boolean.FALSE);
			incorrectDimensions.set(Boolean.TRUE);
		}
	}

	protected SaveArtResponse checkDimensions(byte[] backBytes, byte[] frontBytes) throws IOException {

		BufferedImage backBufferedImage = imageHelper.getBufferedImage(backBytes);
		BufferedImage frontBufferedImage = imageHelper.getBufferedImage(frontBytes);
		Integer actualWidthBackPixels = backBufferedImage.getWidth();
		Integer actualHeightBackPixels = backBufferedImage.getHeight();
		Integer actualWidthFrontPixels = frontBufferedImage.getWidth();
		Integer actualHeightFrontPixels = frontBufferedImage.getHeight();
		CacheImageGroup cacheImageGroup = configurableService.getCacheImageGroup();
		Integer allowedMinWidthPixels = cacheImageGroup.getMinWidthArtInPixels();
		Integer allowedMaxWidthPixels = cacheImageGroup.getMaxWidthArtInPixels();
		Integer allowedMinHeightPixels = cacheImageGroup.getMinHeightArtInPixels();
		Integer allowedMaxHeightPixels = cacheImageGroup.getMaxHeightArtInPixels();
		AtomicBoolean saved = new AtomicBoolean(Boolean.TRUE);
		AtomicBoolean incorrectDimensions = new AtomicBoolean(Boolean.FALSE);
		StringBuilder errorMessage = new StringBuilder();

		checkBackDimensions(errorMessage, actualWidthBackPixels, actualHeightBackPixels, allowedMinWidthPixels,
				allowedMaxWidthPixels, allowedMinHeightPixels, allowedMaxHeightPixels, saved, incorrectDimensions);

		checkFrontDimensions(errorMessage, actualWidthFrontPixels, actualHeightFrontPixels, allowedMinWidthPixels,
				allowedMaxWidthPixels, allowedMinHeightPixels, allowedMaxHeightPixels, saved, incorrectDimensions);

		return new SaveArtResponse(saved.get(), "null");
	}
}

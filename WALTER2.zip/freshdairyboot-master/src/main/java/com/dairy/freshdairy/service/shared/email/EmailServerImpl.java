/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.email;

import java.util.Calendar;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.ForgottenPassword;
import com.dairy.freshdairy.domain.user.Permission;
import com.dairy.freshdairy.domain.user.PermissionEnum;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.email.EmailActivationResponse;
import com.dairy.freshdairy.helper.email.EmailSentResponse;
import com.dairy.freshdairy.helper.email.forgottenpassword.ForgottenPasswordEmailHelper;
import com.dairy.freshdairy.helper.email.sendactivationlink.SendClientActivationLinkEmailHelper;
import com.dairy.freshdairy.helper.hash.HashHelper;
import com.dairy.freshdairy.repository.domain.DomainOrganisationRepository;
import com.dairy.freshdairy.repository.user.ForgottenPasswordRepository;
import com.dairy.freshdairy.repository.user.PermissionRepository;
import com.dairy.freshdairy.repository.user.UserRepository;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
@Service
public class EmailServerImpl implements EmailService {

    @Autowired
    private SendClientActivationLinkEmailHelper sendClientActivationLinkEmailHelper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private DomainOrganisationRepository domainOrganisationRepository;

    @Autowired
    private ForgottenPasswordRepository forgottenPasswordRepository;

    @Autowired
    private HashHelper hashHelper;

    @Autowired
    private ForgottenPasswordEmailHelper forgottenPasswordEmailHelper;


    @Override
    public EmailSentResponse sendActivationEmail( DomainOrganisation organisation, User user,
            String email, Locale locale, String domain, int serverPort, String protocol ) {

        EmailSentResponse emailSentResponse =
                sendClientActivationLinkEmailHelper.sendClientEmailActivationLink( organisation,
                        user, email, locale, domain, serverPort, protocol );

        return emailSentResponse;
    }


    @Override
    public EmailActivationResponse activateUserEmail( String emailActivationCode ) {

        User user = userRepository.findByEmailActivationCodeCode( emailActivationCode );

        if ( user != null ) {

            user.setEmailActivationCode( null );

            Permission permission =
                    permissionRepository.findOne( PermissionEnum.EMAIL_VALIDATED.getId() );

            user.getPermissions().add( permission );
            user.setEnabled( Boolean.TRUE );
            userRepository.save( user );
            return new EmailActivationResponse( Boolean.TRUE, null );
        }

        return new EmailActivationResponse( Boolean.FALSE,
                "Cannot find user with code" );
    }


    @Override
    public EmailSentResponse sendForgottenPasswordEmail( ForgottenPasswordRequest request,
            String domain, int serverPort, String protocol ) {

        Locale locale = Locale.forLanguageTag( "en" );

        DomainOrganisation organisation = domainOrganisationRepository.findByDomain( domain );

        String email = request.getEmail();
        String emailtolower = email.toLowerCase();
        EmailSentResponse emailSentResponse;

        User user = userRepository.findByEmail( emailtolower );

        if ( user != null ) {

            ForgottenPassword forgottenPassword =
                    forgottenPasswordRepository.findByUserEmail( emailtolower );

            if ( forgottenPassword != null ) {

                forgottenPasswordRepository.delete( forgottenPassword );
            }

            forgottenPassword = new ForgottenPassword();
            forgottenPassword.setCode( hashHelper.getRandomHash() );
            forgottenPassword.setUser( user );
            forgottenPassword.setActive( Boolean.FALSE );
            Calendar now = Calendar.getInstance();
            forgottenPassword.setCreatedAt( now );
            forgottenPassword.setUpdatedAt( now );
            forgottenPasswordRepository.save( forgottenPassword );

            emailSentResponse = forgottenPasswordEmailHelper
                    .sendEmailForgottenPassword( organisation, user, locale,
                            "/user/resetforgottenpassword", domain, serverPort,
                            protocol );
        }
        else {

            emailSentResponse = new EmailSentResponse( Boolean.FALSE,
                    "Unknown user email" );
        }
        return emailSentResponse;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.user;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "users" )
public class User extends AbstractPersistentEntity {

    private static final long serialVersionUID = -8595477367479331631L;

    @Column( name = "first_name", nullable = false, unique = false, length = 100 )
    private String firstName;

    @Column( name = "last_name", nullable = false, unique = false, length = 100 )
    private String lastName;

    @Column( name = "email", nullable = false, unique = true, length = 255 )
    private String email;

    @Column( name = "password_hash", nullable = false, unique = false, length = 256 )
    @JsonIgnore
    private String passwordHash;

    @Column( name = "enabled", nullable = false, columnDefinition = "boolean default false" )
    private Boolean enabled;

    @ManyToMany( fetch = FetchType.EAGER )
    @JoinTable( name = "users_permissions", joinColumns = @JoinColumn(
            name = "user_id", referencedColumnName = "id" ),
            inverseJoinColumns = @JoinColumn( name = "permissions_id",
                    referencedColumnName = "id" ) )
    private Set<Permission> permissions = new HashSet<Permission>();

    @OneToOne( )
    @JoinColumn( name = "fk_domain_organisations",
            foreignKey = @ForeignKey( name = "fk_domainorganisations_users" ),
            nullable = false )
    private DomainOrganisation domainOrganisation;

    @OneToOne( )
    @JoinColumn( name = "fk_email_activation_codes",
            foreignKey = @ForeignKey( name = "fk_emailactivationcodes_users" ),
            nullable = true )
    private EmailActivationCode emailActivationCode;


    public String getFirstName() {

        return firstName;
    }


    public void setFirstName( String firstName ) {

        this.firstName = firstName;
    }


    public String getLastName() {

        return lastName;
    }


    public void setLastName( String lastName ) {

        this.lastName = lastName;
    }


    public String getEmail() {

        return email;
    }


    public void setEmail( String email ) {

        this.email = email;
    }


    public String getPasswordHash() {

        return passwordHash;
    }


    public void setPasswordHash( String passwordHash ) {

        this.passwordHash = passwordHash;
    }


    public Boolean getEnabled() {

        return enabled;
    }


    public void setEnabled( Boolean enabled ) {

        this.enabled = enabled;
    }


    public Set<Permission> getPermissions() {

        return permissions;
    }


    public void setPermissions( Set<Permission> permissions ) {

        this.permissions = permissions;
    }


    public DomainOrganisation getDomainOrganisation() {

        return domainOrganisation;
    }


    public void setDomainOrganisation( DomainOrganisation domainOrganisation ) {

        this.domainOrganisation = domainOrganisation;
    }


    public EmailActivationCode getEmailActivationCode() {

        return emailActivationCode;
    }


    public void setEmailActivationCode( EmailActivationCode emailActivationCode ) {

        this.emailActivationCode = emailActivationCode;
    }
}

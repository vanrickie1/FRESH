/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.list.upload;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
public class QuoteTypeTransfer {

    private Long id;
    private String quote;


    public QuoteTypeTransfer() {

    }


    public QuoteTypeTransfer( Long id, String quote ) {

        super();
        this.id = id;
        this.quote = quote;
    }


    public Long getId() {

        return id;
    }


    public void setQuoteId( Long id ) {

        this.id = id;
    }


    public String getQuote() {

        return quote;
    }


    public void setQuote( String quote ) {

        this.quote = quote;
    }
}

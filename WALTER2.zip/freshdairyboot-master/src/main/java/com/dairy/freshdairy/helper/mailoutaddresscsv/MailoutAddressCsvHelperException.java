package com.dairy.freshdairy.helper.mailoutaddresscsv;

public class MailoutAddressCsvHelperException extends Exception {

    private static final long serialVersionUID = -2997122012875674635L;

    private boolean incorrectFormatFile = false;
    private String formatError;


    public MailoutAddressCsvHelperException() {

    }


    public MailoutAddressCsvHelperException( String message ) {

        super( message );
    }


    public MailoutAddressCsvHelperException( Throwable cause ) {

        super( cause );
    }


    public MailoutAddressCsvHelperException( String message, Throwable cause ) {

        super( message, cause );
    }


    public MailoutAddressCsvHelperException( String message, Throwable cause,
            boolean enableSuppression,
            boolean writableStackTrace ) {

        super( message, cause, enableSuppression, writableStackTrace );
    }


    public boolean isIncorrectFormatFile() {

        return incorrectFormatFile;
    }


    public void setIncorrectFormatFile( boolean incorrectFormatFile ) {

        this.incorrectFormatFile = incorrectFormatFile;
    }


    public String getFormatError() {

        return formatError;
    }


    public void setFormatError( String formatError ) {

        this.formatError = formatError;
    }
}

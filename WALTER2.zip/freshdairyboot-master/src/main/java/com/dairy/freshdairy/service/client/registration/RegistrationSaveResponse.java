/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.registration;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public class RegistrationSaveResponse {

    private boolean saved;
    private boolean emailExistsAlready;
    private boolean passwordTooShort;
    private int minPasswordLength;
    private int maxPasswordLength;


    public RegistrationSaveResponse() {

    }


    public RegistrationSaveResponse( boolean saved, boolean emailExistsAlready,
            boolean passwordTooShort, int minPasswordLength, int maxPasswordLength ) {

        super();
        this.saved = saved;
        this.emailExistsAlready = emailExistsAlready;
        this.passwordTooShort = passwordTooShort;
        this.minPasswordLength = minPasswordLength;
        this.maxPasswordLength = maxPasswordLength;
    }


    public boolean isSaved() {

        return saved;
    }


    public void setSaved( boolean saved ) {

        this.saved = saved;
    }


    public boolean isEmailExistsAlready() {

        return emailExistsAlready;
    }


    public void setEmailExistsAlready( boolean emailExistsAlready ) {

        this.emailExistsAlready = emailExistsAlready;
    }


    public boolean isPasswordTooShort() {

        return passwordTooShort;
    }


    public void setPasswordTooShort( boolean passwordTooShort ) {

        this.passwordTooShort = passwordTooShort;
    }


    public int getMinPasswordLength() {

        return minPasswordLength;
    }


    public void setMinPasswordLength( int minPasswordLength ) {

        this.minPasswordLength = minPasswordLength;
    }


    public int getMaxPasswordLength() {

        return maxPasswordLength;
    }


    public void setMaxPasswordLength( int maxPasswordLength ) {

        this.maxPasswordLength = maxPasswordLength;
    }
}

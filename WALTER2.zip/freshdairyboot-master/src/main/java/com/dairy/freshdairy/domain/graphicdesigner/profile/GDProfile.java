/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.profile;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.graphicdesigner.GraphicDesigner;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "gd_profiles" )
public class GDProfile extends AbstractPersistentEntity {

    private static final long serialVersionUID = -169113182159503926L;

    @Column( name = "abstract_text", nullable = false, unique = false, length = 1024 )
    private String abstractText;

    @OneToOne( )
    @JoinColumn( name = "fk_graphic_designers",
            foreignKey = @ForeignKey( name = "fk_graphicdesigners_gdprofiles" ),
            nullable = false )
    private GraphicDesigner graphicDesigner;

    @ManyToMany( fetch = FetchType.EAGER )
    @JoinTable( name = "gdprofiles_gdskills", joinColumns = @JoinColumn(
            name = "gdprofiles_id", referencedColumnName = "id" ),
            inverseJoinColumns = @JoinColumn( name = "gdskills_id",
                    referencedColumnName = "id" ) )
    private Set<GDSkill> gdSkills;


    public String getAbstractText() {

        return abstractText;
    }


    public void setAbstractText( String abstractText ) {

        this.abstractText = abstractText;
    }


    public GraphicDesigner getGraphicDesigner() {

        return graphicDesigner;
    }


    public void setGraphicDesigner( GraphicDesigner graphicDesigner ) {

        this.graphicDesigner = graphicDesigner;
    }


    public Set<GDSkill> getGdSkills() {

        return gdSkills;
    }


    public void setGdSkills( Set<GDSkill> gdSkills ) {

        this.gdSkills = gdSkills;
    }
}

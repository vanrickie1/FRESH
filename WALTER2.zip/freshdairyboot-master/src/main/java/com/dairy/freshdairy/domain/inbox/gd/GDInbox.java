/*
    =======================================================================================
w    This code is part of the Uweee project.

    Uweee is software owned by Uweee. Inc.

    The Uweee software has a proprietary license. Please look at or request
    uweee_license.txt for further details.

    Copyright (C) 2019 Uweee. Inc.

    Email:  jorge@mantaproductions.com

    ========================================================================================
    Author : Jorge Pease
    ========================================================================================
*/
package com.dairy.freshdairy.domain.inbox.gd;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.graphicdesigner.GraphicDesigner;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "gd_inboxs" )
public class GDInbox extends AbstractPersistentEntity {

    private static final long serialVersionUID = -8999889867078285231L;

    @Column( name = "needs_notification", nullable = false,
            columnDefinition = "boolean default false" )
    private Boolean needsNotification;

    @OneToOne( )
    @JoinColumn( name = "fk_graphic_designers",
            foreignKey = @ForeignKey( name = "fk_graphicdesigners_gdinboxes" ),
            nullable = false )
    private GraphicDesigner graphicDesigner;


    public Boolean getNeedsNotification() {

        return needsNotification;
    }


    public void setNeedsNotification( Boolean needsNotification ) {

        this.needsNotification = needsNotification;
    }


    public GraphicDesigner getGraphicDesigner() {

        return graphicDesigner;
    }


    public void setGraphicDesigner( GraphicDesigner graphicDesigner ) {

        this.graphicDesigner = graphicDesigner;
    }
}

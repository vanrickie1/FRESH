/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dairy.freshdairy.domain.campaignclient.campaign.Campaign;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignList;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.loggingin.LoggedInCredentialsHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignListRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;
import com.dairy.freshdairy.service.client.campaign.link.CampaignArtRequest;
import com.dairy.freshdairy.service.client.campaign.link.CampaignLinkInitialData;
import com.dairy.freshdairy.service.client.campaign.link.CampaignLinkRequest;
import com.dairy.freshdairy.service.client.campaign.link.CampaignLinkService;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;

/**
 * @author John Dickerson
 * @date   13 Nov 2019
 */
@RestController
@RequestMapping( "/freshdairy/client/campaign/link" )
public class ClientCampaignLinkController {

    @Autowired
    private CampaignLinkService campaignLinkService;

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private LoggedInCredentialsHelper loggedInCredentialsHelper;

    @Autowired
    private ArtRepository artRepository;

    @Autowired
    private CampaignListRepository campaignListRepository;


    private void checkMaliciousLink( Long campaignId, User loggedInUser ) {

        Campaign campaign = campaignRepository.findOne( campaignId );
        User user = campaign.getCampaignClient().getUser();

        if ( !loggedInUser.equals( user ) ) {

            StringBuilder sb = new StringBuilder( "MALICIOUS: " );
            sb.append( loggedInUser.getFirstName() );
            sb.append( " " );
            sb.append( loggedInUser.getLastName() );
            sb.append( " email: " );
            sb.append( user.getEmail() );
            sb.append( " tried to link a campaign to art and lists they do not own. " );
            sb.append( "campaignId = " );
            sb.append( campaignId );
            String message = sb.toString();
            throw new RuntimeException( message );
        }
    }


    private void checkMaliciousLink( CampaignArtRequest campaignArtRequest, User loggedInUser ) {

        Long artId = campaignArtRequest.getArtId();
        Art art = artRepository.findOne( artId );
        User user = art.getCampaignClient().getUser();

        if ( !loggedInUser.equals( user ) ) {

            StringBuilder sb = new StringBuilder( "MALICIOUS: " );
            sb.append( loggedInUser.getFirstName() );
            sb.append( " " );
            sb.append( loggedInUser.getLastName() );
            sb.append( " email: " );
            sb.append( user.getEmail() );
            sb.append( " tried to link a campaign to art they do not own. " );
            sb.append( "artId = " );
            sb.append( art.getId() );
            String message = sb.toString();
            throw new RuntimeException( message );
        }
    }


    private void checkMaliciousLinkList( Long campaignListId, User loggedInUser ) {

        CampaignList campaignList = campaignListRepository.findOne( campaignListId );
        User user = campaignList.getCampaignClient().getUser();

        if ( !loggedInUser.equals( user ) ) {

            StringBuilder sb = new StringBuilder( "MALICIOUS: " );
            sb.append( loggedInUser.getFirstName() );
            sb.append( " " );
            sb.append( loggedInUser.getLastName() );
            sb.append( " email: " );
            sb.append( user.getEmail() );
            sb.append( " tried to link a campaign to a list they do not own. " );
            sb.append( "campaignListId = " );
            sb.append( campaignList.getId() );
            String message = sb.toString();
            throw new RuntimeException( message );
        }
    }


    private void checkMaliciousLink( CampaignLinkRequest request, User loggedInUser ) {

        checkMaliciousLink( request.getCampaignId(), loggedInUser );

        for ( CampaignArtRequest campaignArtRequest : request.getCampaignArtRequests() ) {

            checkMaliciousLink( campaignArtRequest, loggedInUser );
        }

        checkMaliciousLinkList( request.getCampaignListId(), loggedInUser );
    }


    @RequestMapping( value = "/initialdata", method = RequestMethod.POST )
    @PreAuthorize( "hasAuthority('CLIENT')" )
    public ResponseEntity<CampaignLinkInitialData> getInitialData( @RequestBody Long campaignId ) {

        User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();
        checkMaliciousLink( campaignId, loggedInUser );
        CampaignLinkInitialData initialData = campaignLinkService.getInitialData( campaignId );
        return ResponseEntity.status( HttpStatus.OK ).body( initialData );
    }


    @RequestMapping( value = "/save", method = RequestMethod.POST )
    @PreAuthorize( "hasAuthority('CLIENT')" )
    public ResponseEntity<SaveResponse> save( @RequestBody CampaignLinkRequest request ) {

        User loggedInUser = loggedInCredentialsHelper.getLoggedInUser();
        checkMaliciousLink( request, loggedInUser );
        SaveResponse saveResponse = campaignLinkService.save( request );
        return ResponseEntity.status( HttpStatus.OK ).body( saveResponse );
    }
}

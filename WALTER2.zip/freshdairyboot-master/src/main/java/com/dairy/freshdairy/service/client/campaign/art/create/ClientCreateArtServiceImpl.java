/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.create;

import java.io.File;
import java.io.IOException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.zxing.WriterException;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.helper.art.ArtHelper;
import com.dairy.freshdairy.helper.artfile.ArtFileHelper;
import com.dairy.freshdairy.helper.file.FileHelper;
import com.dairy.freshdairy.helper.filetype.FileTypeHelper;
import com.dairy.freshdairy.helper.qrcode.FileType;
import com.dairy.freshdairy.helper.qrcode.QrCodeHelper;
import com.dairy.freshdairy.service.client.campaign.art.AbstractArtService;
import com.dairy.freshdairy.service.client.campaign.art.FileTypeTransfer;
import com.dairy.freshdairy.service.client.campaign.art.SaveArtResponse;
import com.dairy.freshdairy.service.system.configurable.CacheImageGroup;
import com.dairy.freshdairy.service.system.configurable.ConfigurableService;

/**
 * @author John Dickerson
 * @date 28 Oct 2019
 */
@Service
public class ClientCreateArtServiceImpl extends AbstractArtService implements ClientCreateArtService {

	@Autowired
	private FileHelper fileHelper;

	@Autowired
	private ConfigurableService configurableService;

	@Autowired
	private FileTypeHelper fileTypeHelper;

	@Autowired
	private ArtHelper artHelper;

	@Autowired
	private ArtFileHelper artFileHelper;

	@Autowired
	private QrCodeHelper qrCodeHelper;

	@Override
	public ClientCreateArtInitialData getInitialData() {

		FileTypeTransfer[] fileTypeTransfers = fileTypeHelper.createFileTypeTransfers();
		CacheImageGroup cacheImageGroup = configurableService.getCacheImageGroup();
		Integer allowedWidthPixels = cacheImageGroup.getMaxWidthArtInPixels();
		Integer allowedHeightPixels = cacheImageGroup.getMaxHeightArtInPixels();

		ClientCreateArtInitialData initialData = new ClientCreateArtInitialData(fileTypeTransfers, allowedWidthPixels,
				allowedHeightPixels);

		return initialData;
	}

	@Override
	@Transactional
	public SaveArtResponse save(Long domainOrganisationId, ClientCreateArtRequest request,
			MultipartFile frontArtMultipartFile, Long campaignClientId) throws IOException, WriterException {

		String frontPath = fileHelper.saveFile(domainOrganisationId, ART_NAMESPACE, frontArtMultipartFile.getBytes(),
				frontArtMultipartFile.getOriginalFilename());

		Art art = artHelper.saveArt(campaignClientId, request);
		artFileHelper.saveFrontArtFile(art, frontPath);

		String regexTarget = "(png)$";
		String qrcodePath = frontPath.replaceAll(regexTarget, "qrcode.png");

		qrCodeHelper.generateQrCode("http://ec2-3-84-83-205.compute-1.amazonaws.com/enterdraw/" + art.getId(), FileType.PNG,
				new File(qrcodePath), 250);

		artFileHelper.saveBackArtFile(art, qrcodePath);

		return new SaveArtResponse(Boolean.TRUE, "Saved");
	}
}

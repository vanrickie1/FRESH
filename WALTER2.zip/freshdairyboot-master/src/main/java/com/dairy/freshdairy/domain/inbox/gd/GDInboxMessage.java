/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.inbox.gd;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "gd_inbox_messages" )
public class GDInboxMessage extends AbstractPersistentEntity {

    private static final long serialVersionUID = -3468479103393056891L;

    @Column( name = "messages", nullable = false, unique = false, length = 500 )
    private String message;

    @Column( name = "web_action_urls", nullable = false, unique = false, length = 200 )
    private String webActionUrl;

    @OneToOne( )
    @JoinColumn( name = "fk_gd_inboxs",
            foreignKey = @ForeignKey( name = "fk_gdinboxs_gdinboxmessages" ),
            nullable = false )
    private GDInbox gdInbox;

    @OneToOne( )
    @JoinColumn( name = "fk_gd_inbox_message_types",
            foreignKey = @ForeignKey( name = "fk_gdinboxmessagetypes_gdinboxmessages" ),
            nullable = false )
    private GDInboxMessageType gdInboxMessageType;


    public String getMessage() {

        return message;
    }


    public void setMessage( String message ) {

        this.message = message;
    }


    public String getWebActionUrl() {

        return webActionUrl;
    }


    public void setWebActionUrl( String webActionUrl ) {

        this.webActionUrl = webActionUrl;
    }


    public GDInbox getGdInbox() {

        return gdInbox;
    }


    public void setGdInbox( GDInbox gdInbox ) {

        this.gdInbox = gdInbox;
    }


    public GDInboxMessageType getGdInboxMessageType() {

        return gdInboxMessageType;
    }


    public void setGdInboxMessageType( GDInboxMessageType gdInboxMessageType ) {

        this.gdInboxMessageType = gdInboxMessageType;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.show;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFile;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFileTypeEnum;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtFileRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;

/**
 * @author John Dickerson
 * @date 29 Oct 2019
 */
@Service
public class ClientShowArtsServiceImpl implements ClientShowArtsService {

	@Autowired
	private ArtRepository artRepository;

	@Autowired
	private ArtFileRepository artFileRepository;

	private ArtTransfer createArtTransfer(Art art) {

		ArtFile frontArtFile = artFileRepository.findByArtIdAndArtFileTypeId(art.getId(),
				ArtFileTypeEnum.FRONT.getArtFileTypeId());

		ArtFile qrcodeFile = artFileRepository.findByArtIdAndArtFileTypeId(art.getId(),
				ArtFileTypeEnum.BACK.getArtFileTypeId());

		ArtTransfer transfer = new ArtTransfer(art.getId(), art.getName(), art.getNote(), frontArtFile.getArt().getId(),
				qrcodeFile.getArt().getId());

		return transfer;
	}

	private ArtTransfer[] createArtTransfers(Set<Art> arts) {

		List<ArtTransfer> artTransfers = new ArrayList<>();

		for (Art art : arts) {

			artTransfers.add(createArtTransfer(art));
		}

		return artTransfers.toArray(new ArtTransfer[artTransfers.size()]);
	}

	@Override
	public ClientShowsArtInitialData getInitialData(Long campaignClientId) {

		Set<Art> arts = artRepository.findByCampaignClientId(campaignClientId);
		ArtTransfer[] artTransfers = createArtTransfers(arts);

		ClientShowsArtInitialData initialData = new ClientShowsArtInitialData(artTransfers);

		return initialData;
	}

	@Override
	public ClientShowsArtInitialData getPublicInitialData() {

		Set<Art> arts = artRepository.findAll();
		ArtTransfer[] artTransfers = createArtTransfers(arts);

		ClientShowsArtInitialData initialData = new ClientShowsArtInitialData(artTransfers);

		return initialData;
	}
}

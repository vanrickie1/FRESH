/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.image;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dairy.freshdairy.service.image.ImageService;

/**
 * @author John Dickerson
 * @date 13 Nov 2019
 */
@RestController
@RequestMapping("/freshdairy/image/art")
public class ImageController {

	@Autowired
	private ImageService imageService;

	@RequestMapping(method = RequestMethod.GET, value = "/front", produces = { MediaType.IMAGE_JPEG_VALUE,
			MediaType.IMAGE_PNG_VALUE, MediaType.IMAGE_GIF_VALUE })
	public ResponseEntity<InputStreamResource> downloadFrontArt(@RequestParam("artId") Long artId) {

		return imageService.downloadFrontArt(artId);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/back", produces = { MediaType.IMAGE_JPEG_VALUE,
			MediaType.IMAGE_PNG_VALUE, MediaType.IMAGE_GIF_VALUE })
	public ResponseEntity<InputStreamResource> downloadBackArt(@RequestParam("artId") Long artId) {

		return imageService.downloadBackArt(artId);
	}
}

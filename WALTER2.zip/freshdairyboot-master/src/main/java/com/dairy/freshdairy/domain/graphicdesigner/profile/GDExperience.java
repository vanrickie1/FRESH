/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.profile;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "gd_experiences" )
public class GDExperience extends AbstractPersistentEntity {

    private static final long serialVersionUID = 6384351082686859739L;

    @Column( name = "position", nullable = false, unique = false, length = 20 )
    private String position;

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "start", nullable = false, unique = false )
    private Date start;

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "end", nullable = false, unique = false )
    private Date end;

    @Column( name = "description", nullable = false, unique = false, length = 500 )
    private String description;

    @Column( name = "organisation", nullable = false, unique = false, length = 20 )
    private String organisation;

    @OneToOne( )
    @JoinColumn( name = "fk_gd_profiles",
            foreignKey = @ForeignKey( name = "fk_gdprofiles_gdexperiences" ),
            nullable = false )
    private GDProfile gdProfile;

    @OneToOne( )
    @JoinColumn( name = "fk_gd_experience_types",
            foreignKey = @ForeignKey( name = "fk_gdexperiencetypes_gdexperiences" ),
            nullable = false )
    private GDExperienceType gdExperienceType;


    public String getPosition() {

        return position;
    }


    public void setPosition( String position ) {

        this.position = position;
    }


    public Date getStart() {

        return start;
    }


    public void setStart( Date start ) {

        this.start = start;
    }


    public Date getEnd() {

        return end;
    }


    public void setEnd( Date end ) {

        this.end = end;
    }


    public String getDescription() {

        return description;
    }


    public void setDescription( String description ) {

        this.description = description;
    }


    public String getOrganisation() {

        return organisation;
    }


    public void setOrganisation( String organisation ) {

        this.organisation = organisation;
    }


    public GDProfile getGdProfile() {

        return gdProfile;
    }


    public void setGdProfile( GDProfile gdProfile ) {

        this.gdProfile = gdProfile;
    }


    public GDExperienceType getGdExperienceType() {

        return gdExperienceType;
    }


    public void setGdExperienceType( GDExperienceType gdExperienceType ) {

        this.gdExperienceType = gdExperienceType;
    }
}

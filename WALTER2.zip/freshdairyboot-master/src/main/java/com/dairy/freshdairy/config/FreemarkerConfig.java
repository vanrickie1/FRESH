/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

/**
 * @author John Dickerson
 * @date   30th Sept 2019
 */
@Configuration
public class FreemarkerConfig {

    @Bean
    public FreeMarkerConfigurationFactoryBean
            freeMarkerConfigurationFactoryBean() {

        FreeMarkerConfigurationFactoryBean freeMarkerConfigurationFactoryBean =
                new FreeMarkerConfigurationFactoryBean();

        freeMarkerConfigurationFactoryBean.setTemplateLoaderPaths(
                "classpath:com/freshdairy/freshdairy/helper/email" );

        return freeMarkerConfigurationFactoryBean;
    }
}

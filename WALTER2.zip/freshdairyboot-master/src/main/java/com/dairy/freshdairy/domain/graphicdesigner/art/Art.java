/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.art;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.graphicdesigner.GraphicDesigner;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "arts" )
public class Art extends AbstractPersistentEntity {

    private static final long serialVersionUID = 1233144561399934450L;

    @Column( name = "name", nullable = false, unique = false, length = 30 )
    private String name;

    @Column( name = "note", nullable = true, unique = false, length = 200 )
    private String note;

    @Column( name = "number_edits", nullable = true, unique = false )
    private Integer numberEdits;

    @Column( name = "edits_locked", nullable = false, columnDefinition = "boolean default false" )
    private Boolean editsLocked;

    @ManyToOne( )
    @JoinColumn( name = "fk_campaign_clients",
            foreignKey = @ForeignKey( name = "fk_campaignclients_arts" ),
            nullable = false )
    private CampaignClient campaignClient;

    @ManyToOne( )
    @JoinColumn( name = "fk_graphic_designers",
            foreignKey = @ForeignKey( name = "fk_graphicdesigners_arts" ),
            nullable = true )
    private GraphicDesigner graphicDesigner;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getNote() {

        return note;
    }


    public void setNote( String note ) {

        this.note = note;
    }


    public Integer getNumberEdits() {

        return numberEdits;
    }


    public void setNumberEdits( Integer numberEdits ) {

        this.numberEdits = numberEdits;
    }


    public Boolean getEditsLocked() {

        return editsLocked;
    }


    public void setEditsLocked( Boolean editsLocked ) {

        this.editsLocked = editsLocked;
    }


    public CampaignClient getCampaignClient() {

        return campaignClient;
    }


    public void setCampaignClient( CampaignClient campaignClient ) {

        this.campaignClient = campaignClient;
    }


    public GraphicDesigner getGraphicDesigner() {

        return graphicDesigner;
    }


    public void setGraphicDesigner( GraphicDesigner graphicDesigner ) {

        this.graphicDesigner = graphicDesigner;
    }
}

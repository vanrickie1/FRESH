/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.registration;

/**
 * @author John Dickerson
 * @date 15 Oct 2019
 */
public class DrawSaveResponse {

	private boolean saved;
	private boolean receiptExistsAlready;

	public DrawSaveResponse() {

	}

	public DrawSaveResponse(boolean saved, boolean receiptExistsAlready) {

		super();
		this.saved = saved;
		this.receiptExistsAlready = receiptExistsAlready;
	}

	public boolean isSaved() {

		return saved;
	}

	public void setSaved(boolean saved) {

		this.saved = saved;
	}

	public boolean isReceiptExistsAlready() {
		return receiptExistsAlready;
	}

	public void setReceiptExistsAlready(boolean receiptExistsAlready) {
		this.receiptExistsAlready = receiptExistsAlready;
	}

}

/*
    =======================================================================================
    This code is part of the Uweee project.

    Uweee is software owned by Uweee. Inc.

    The Uweee software has a proprietary license. Please look at or request
    uweee_license.txt for further details.

    Copyright (C) 2019 Uweee. Inc.

    Email:  jorge@mantaproductions.com
 
    ========================================================================================
    Author : Jorge Pease
    ========================================================================================
*/
package com.dairy.freshdairy.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * See http://www.baeldung.com/properties-with-spring
 *
 * See
 * https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html
 *
 * Note we probably do not need this file as there is already an
 * application.properties
 *
 * To access a property from application.properties
 *
 * @Value("${name}") private String name;
 *
 * Note this config is for an additional property file called uweee.properties
 *
 * @author John Dickerson
 * @date   9 July 2019
 */
@Configuration
@PropertySource( "classpath:uweee.properties" )
public class PropertiesConfig {

    @Bean
    public static PropertySourcesPlaceholderConfigurer
            propertySourcesPlaceholderConfigurer() {

        return new PropertySourcesPlaceholderConfigurer();
    }
}

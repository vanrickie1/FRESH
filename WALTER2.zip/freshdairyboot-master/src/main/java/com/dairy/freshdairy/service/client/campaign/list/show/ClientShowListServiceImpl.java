/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.list.show;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignList;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;

/**
 * @author John Dickerson
 * @date   30 Oct 2019
 */
@Service
public class ClientShowListServiceImpl implements ClientShowListService {

    @Autowired
    private CampaignClientRepository campaignClientRepository;


    private ListTransfer createListTransfer( CampaignList campaignList ) {

        return new ListTransfer( campaignList.getId(), campaignList.getName(), campaignList
                .getDescription() );
    }


    private ListTransfer[] createListTransfers( Long campaignClientId ) {

        CampaignClient campaignClient = campaignClientRepository.findOne( campaignClientId );
        Set<CampaignList> campaignLists = campaignClient.getCampaignLists();
        List<ListTransfer> listTransfers = new ArrayList<>();

        for ( CampaignList campaignList : campaignLists ) {

            listTransfers.add( createListTransfer( campaignList ) );
        }

        return listTransfers.toArray( new ListTransfer[listTransfers.size()] );
    }


    @Override
    public ClientShowListInitialData getInitialData( Long campaignClientId ) {

        ListTransfer[] listTransfers = createListTransfers( campaignClientId );
        ClientShowListInitialData initialData = new ClientShowListInitialData( listTransfers );
        return initialData;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.edit;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.icu.util.Calendar;
import com.dairy.freshdairy.domain.campaignclient.campaign.Campaign;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignFrequencyType;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignMonth;
import com.dairy.freshdairy.helper.campaignfrequencytype.CampaignFrequencyTypeHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignFrequencyTypeRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignMonthRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignRepository;
import com.dairy.freshdairy.service.client.campaign.create.CampaignFrequencyTypeTransfer;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;

/**
 * @author John Dickerson
 * @date   30 Oct 2019
 */
@Service
public class ClientEditCampaignServiceImpl implements ClientEditCampaignService {

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private CampaignFrequencyTypeHelper campaignFrequencyTypeHelper;

    @Autowired
    private CampaignFrequencyTypeRepository campaignFrequencyTypeRepository;

    @Autowired
    private CampaignMonthRepository campaignMonthRepository;


    private boolean inTheFuture( CampaignMonth campaignMonth ) {

        if ( campaignMonth.getMailOutDate().getTime() > Calendar.getInstance().getTime()
                .getTime() ) {

            return true;
        }

        return false;
    }


    private void removeCampaignMonthsInTheFuture( Campaign campaign ) {

        Set<CampaignMonth> campaignMonths = campaign.getCampaignMonths();

        for ( CampaignMonth campaignMonth : campaignMonths ) {

            if ( inTheFuture( campaignMonth ) ) {

                campaignMonthRepository.delete( campaignMonth );
            }
        }
    }


    @Override
    public ClientEditCampaignInitialData getInitialData( Long campaignId ) {

        Campaign campaign = campaignRepository.findOne( campaignId );
        CampaignFrequencyType campaignFrequencyType = campaign.getCampaignFrequencyType();
        Long campaignFrequencyTypeId = campaignFrequencyType.getId();
        String campaignName = campaign.getName();

        CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers =
                campaignFrequencyTypeHelper.createCampaignFrequencyTypeTransfers();

        ClientEditCampaignInitialData initialData =
                new ClientEditCampaignInitialData( campaign.getId(), campaignFrequencyTypeId,
                        campaignName, campaignFrequencyTypeTransfers );

        return initialData;
    }


    @Override
    public SaveResponse save( EditCampaignRequest request ) {

        Campaign campaign = campaignRepository.findOne( request.getCampaignId() );
        CampaignFrequencyType existingCampaignFrequencyType = campaign.getCampaignFrequencyType();

        CampaignFrequencyType requestCampaignFrequencyType =
                campaignFrequencyTypeRepository.findOne( request.getCampaignFrequencyTypeId() );

        if ( existingCampaignFrequencyType.getId().intValue() != requestCampaignFrequencyType
                .getId().intValue() ) {

            removeCampaignMonthsInTheFuture( campaign );
        }

        campaign.setCampaignFrequencyType( requestCampaignFrequencyType );
        campaign.setName( request.getCampaignName() );
        campaign.setActivated( Boolean.FALSE );
        campaignRepository.save( campaign );
        return new SaveResponse( Boolean.TRUE, null );
    }
}

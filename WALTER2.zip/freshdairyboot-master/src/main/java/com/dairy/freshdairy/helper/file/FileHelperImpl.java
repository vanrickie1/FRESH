/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.file;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
@Component
public class FileHelperImpl implements FileHelper {

    @Autowired
    private HomeDirectoryFileSystemProvider homeDirectoryFileSystemProvider;

    @Autowired
    private S3FileSystemProvider s3FileSystemProvider;


    private Boolean amProd() {

        return false;
    }


    public HomeDirectoryFileSystemProvider getHomeDirectoryFileSystemProvider() {

        return homeDirectoryFileSystemProvider;
    }


    public void setHomeDirectoryFileSystemProvider(
            HomeDirectoryFileSystemProvider homeDirectoryFileSystemProvider ) {

        this.homeDirectoryFileSystemProvider = homeDirectoryFileSystemProvider;
    }


    public S3FileSystemProvider getS3FileSystemProvider() {

        return s3FileSystemProvider;
    }


    public void setS3FileSystemProvider( S3FileSystemProvider s3FileSystemProvider ) {

        this.s3FileSystemProvider = s3FileSystemProvider;
    }


    @Override
    public String saveFile( Long domainOrganisationId, String namespace, byte[] bytes,
            String orignalFileName ) throws IOException {

        String path;

        if ( amProd() ) {

            path = s3FileSystemProvider.saveFile( domainOrganisationId, namespace, bytes,
                    orignalFileName );
        }
        else {

            path = homeDirectoryFileSystemProvider.saveFile( domainOrganisationId, namespace,
                    bytes, orignalFileName );
        }

        return path;
    }


    @Override
    public void deleteFile( String path ) {

        if ( amProd() ) {

            s3FileSystemProvider.deleteFile( path );
        }
        else {

            homeDirectoryFileSystemProvider.deleteFile( path );
        }

    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.inbox.cc;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.inbox.EntityTable;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "cc_entry_refs" )
public class CCEntryRef extends AbstractPersistentEntity {

    private static final long serialVersionUID = -1992378820061589992L;

    @Column( name = "entity_primary_key", nullable = true, unique = false )
    private Long entityPrimaryKey;

    @ManyToOne( )
    @JoinColumn( name = "fk_entity_tables",
            foreignKey = @ForeignKey( name = "fk_entitytables_ccentryrefs" ),
            nullable = false )
    private EntityTable entityTable;

    @ManyToOne( )
    @JoinColumn( name = "fk_cc_inbox_messages",
            foreignKey = @ForeignKey( name = "fk_ccinboxmessages_ccentryrefs" ),
            nullable = false )
    private CCInboxMessage ccInboxMessage;


    public Long getEntityPrimaryKey() {

        return entityPrimaryKey;
    }


    public void setEntityPrimaryKey( Long entityPrimaryKey ) {

        this.entityPrimaryKey = entityPrimaryKey;
    }


    public EntityTable getEntityTable() {

        return entityTable;
    }


    public void setEntityTable( EntityTable entityTable ) {

        this.entityTable = entityTable;
    }


    public CCInboxMessage getCcInboxMessage() {

        return ccInboxMessage;
    }


    public void setCcInboxMessage( CCInboxMessage ccInboxMessage ) {

        this.ccInboxMessage = ccInboxMessage;
    }
}

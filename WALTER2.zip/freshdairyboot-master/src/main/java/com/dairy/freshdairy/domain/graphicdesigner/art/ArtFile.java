/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.art;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "art_files" )
public class ArtFile extends AbstractPersistentEntity {

    private static final long serialVersionUID = -466270406294267472L;

    @Column( name = "path", nullable = false, unique = false, length = 1024 )
    private String path;

    @ManyToOne( )
    @JoinColumn( name = "fk_arts",
            foreignKey = @ForeignKey( name = "fk_arts_artfiles" ),
            nullable = false )
    private Art art;

    @ManyToOne( )
    @JoinColumn( name = "fk_art_file_types",
            foreignKey = @ForeignKey( name = "fk_artfiletypes_artfiles" ),
            nullable = false )
    private ArtFileType artFileType;

    @ManyToOne( )
    @JoinColumn( name = "fk_art_folders",
            foreignKey = @ForeignKey( name = "fk_art_folders_artfiles" ),
            nullable = true )
    private ArtFolder artFolder;


    public String getPath() {

        return path;
    }


    public void setPath( String path ) {

        this.path = path;
    }


    public Art getArt() {

        return art;
    }


    public void setArt( Art art ) {

        this.art = art;
    }


    public ArtFileType getArtFileType() {

        return artFileType;
    }


    public void setArtFileType( ArtFileType artFileType ) {

        this.artFileType = artFileType;
    }


    public ArtFolder getArtFolder() {

        return artFolder;
    }


    public void setArtFolder( ArtFolder artFolder ) {

        this.artFolder = artFolder;
    }
}

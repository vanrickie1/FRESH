/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.list.create;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
public class ZipTransfer {

    private String zip;
    private Long id;


    public ZipTransfer() {

    }


    public ZipTransfer( String zip, Long id ) {

        super();
        this.zip = zip;
        this.id = id;
    }


    public String getZip() {

        return zip;
    }


    public void setZip( String zip, Long id ) {

        this.zip = zip;
        this.id = id;
    }


    public Long getId() {

        return id;
    }


    public void setId( Long id ) {

        this.id = id;
    }
}

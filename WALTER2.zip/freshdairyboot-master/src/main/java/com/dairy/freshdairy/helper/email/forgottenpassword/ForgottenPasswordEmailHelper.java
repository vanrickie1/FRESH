/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.email.forgottenpassword;

import java.util.Locale;

import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.email.EmailSentResponse;

/**
 * @author John Dickerson
 * @date   17 Oct 2019
 */
public interface ForgottenPasswordEmailHelper {

    EmailSentResponse sendEmailForgottenPassword( DomainOrganisation domainOrganisation,
            User user, Locale locale, String contextPath, String domain,
            int serverPort, String protocol );
}

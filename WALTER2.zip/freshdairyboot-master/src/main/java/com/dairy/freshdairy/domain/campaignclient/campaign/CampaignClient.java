/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.campaignclient.campaign;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.address.Address;
import com.dairy.freshdairy.domain.graphicdesigner.GraphicDesigner;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.user.User;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "campaign_clients" )
public class CampaignClient extends AbstractPersistentEntity {

    private static final long serialVersionUID = -2300871892933861045L;

    @Column( name = "company_name", nullable = true, unique = false, length = 100 )
    private String companyName;

    @Column( name = "enabled", nullable = false, columnDefinition = "boolean default false" )
    private Boolean enabled;

    @ManyToOne( )
    @JoinColumn( name = "fk_addresses",
            foreignKey = @ForeignKey( name = "fk_addresses_campaignclients" ),
            nullable = false )
    private Address address;

    @ManyToMany( fetch = FetchType.EAGER, targetEntity = GraphicDesigner.class, cascade = {
            CascadeType.PERSIST, CascadeType.MERGE } )
    @JoinTable( name = "campaignclients_graphicdesigners", joinColumns = { @JoinColumn(
            name = "campaignclients_id", referencedColumnName = "id" ) },
            inverseJoinColumns = { @JoinColumn( name = "graphicdesigners_id",
                    referencedColumnName = "id" ) } )
    private Set<GraphicDesigner> graphicDesigners;

    @ManyToOne( )
    @JoinColumn( name = "fk_users",
            foreignKey = @ForeignKey( name = "fk_users_campaignclients" ),
            nullable = false )
    private User user;

    @OneToMany( mappedBy = "campaignClient" )
    private Set<Campaign> campaigns;

    @OneToMany( mappedBy = "campaignClient" )
    private Set<CampaignList> campaignLists;

    @OneToMany( mappedBy = "campaignClient" )
    private Set<Art> arts;


    public String getCompanyName() {

        return companyName;
    }


    public void setCompanyName( String companyName ) {

        this.companyName = companyName;
    }


    public Boolean getEnabled() {

        return enabled;
    }


    public void setEnabled( Boolean enabled ) {

        this.enabled = enabled;
    }


    public Address getAddress() {

        return address;
    }


    public void setAddress( Address address ) {

        this.address = address;
    }


    public Set<GraphicDesigner> getGraphicDesigners() {

        return graphicDesigners;
    }


    public void setGraphicDesigners( Set<GraphicDesigner> graphicDesigners ) {

        this.graphicDesigners = graphicDesigners;
    }


    public User getUser() {

        return user;
    }


    public void setUser( User user ) {

        this.user = user;
    }


    public Set<Campaign> getCampaigns() {

        return campaigns;
    }


    public void setCampaigns( Set<Campaign> campaigns ) {

        this.campaigns = campaigns;
    }


    public Set<CampaignList> getCampaignLists() {

        return campaignLists;
    }


    public void setCampaignLists( Set<CampaignList> campaignLists ) {

        this.campaignLists = campaignLists;
    }


    public Set<Art> getArts() {

        return arts;
    }


    public void setArts( Set<Art> arts ) {

        this.arts = arts;
    }
}

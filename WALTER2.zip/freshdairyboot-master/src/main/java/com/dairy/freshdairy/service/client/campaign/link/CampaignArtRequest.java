/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.link;

/**
 * @author John Dickerson
 * @date   13 Nov 2019
 */
public class CampaignArtRequest {

    private Long artId;
    private Integer monthIndex;


    public CampaignArtRequest() {

    }


    public CampaignArtRequest( Long artId, Integer monthIndex ) {

        super();
        this.artId = artId;
        this.monthIndex = monthIndex;
    }


    public Long getArtId() {

        return artId;
    }


    public void setArtId( Long artId ) {

        this.artId = artId;
    }


    public Integer getMonthIndex() {

        return monthIndex;
    }


    public void setMonthIndex( Integer monthIndex ) {

        this.monthIndex = monthIndex;
    }
}

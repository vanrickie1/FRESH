/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.system.configurable;

/**
 * @author John Dickerson
 * @date   30 Oct 2019
 */
public class CacheImageGroup extends CacheConfigurableGroup {

    private Integer minWidthArtInPixels;
    private Integer maxWidthArtInPixels;
    private Integer minHeightArtInPixels;
    private Integer maxHeightArtInPixels;


    public CacheImageGroup(
            Integer minWidthArtInPixels, Integer maxWidthArtInPixels,
            Integer minHeightArtInPixels, Integer maxHeightArtInPixels ) {

        super();
        this.minWidthArtInPixels = minWidthArtInPixels;
        this.maxWidthArtInPixels = maxWidthArtInPixels;
        this.minHeightArtInPixels = minHeightArtInPixels;
        this.maxHeightArtInPixels = maxHeightArtInPixels;
    }


    public Integer getMinWidthArtInPixels() {

        return minWidthArtInPixels;
    }


    public void setMinWidthArtInPixels( Integer minWidthArtInPixels ) {

        this.minWidthArtInPixels = minWidthArtInPixels;
    }


    public Integer getMaxWidthArtInPixels() {

        return maxWidthArtInPixels;
    }


    public void setMaxWidthArtInPixels( Integer maxWidthArtInPixels ) {

        this.maxWidthArtInPixels = maxWidthArtInPixels;
    }


    public Integer getMinHeightArtInPixels() {

        return minHeightArtInPixels;
    }


    public void setMinHeightArtInPixels( Integer minHeightArtInPixels ) {

        this.minHeightArtInPixels = minHeightArtInPixels;
    }


    public Integer getMaxHeightArtInPixels() {

        return maxHeightArtInPixels;
    }


    public void setMaxHeightArtInPixels( Integer maxHeightArtInPixels ) {

        this.maxHeightArtInPixels = maxHeightArtInPixels;
    }
}

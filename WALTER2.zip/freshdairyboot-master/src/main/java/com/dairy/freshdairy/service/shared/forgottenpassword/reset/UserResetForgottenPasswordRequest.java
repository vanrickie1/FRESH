/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.forgottenpassword.reset;

/**
 * @author John Dickerson
 * @date   18 Oct 2019
 */
public class UserResetForgottenPasswordRequest {

    private long userId;
    private String code;
    private String password;


    public UserResetForgottenPasswordRequest( long userId, String code,
            String password ) {

        this.userId = userId;
        this.code = code;
        this.password = password;
    }


    public UserResetForgottenPasswordRequest() {

        super();
    }


    public long getUserId() {

        return userId;
    }


    public void setUserId( long userId ) {

        this.userId = userId;
    }


    public String getCode() {

        return code;
    }


    public void setCode( String code ) {

        this.code = code;
    }


    public String getPassword() {

        return password;
    }


    public void setPassword( String password ) {

        this.password = password;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.state;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.domain.address.State;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.repository.address.StateRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.service.shared.transfer.StateTransfer;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
@Component
public class StateHelperImpl implements StateHelper {

    @Autowired
    private StateRepository stateRepository;

    @Autowired
    private CampaignClientRepository campaignClientRepository;


    private StateTransfer createStateTransfer( State state ) {

        return new StateTransfer( state.getId(), state.getName() );
    }


    @Override
    public StateTransfer[] getStateTransfers() {

        Iterable<State> states = stateRepository.findAll();
        List<StateTransfer> stateTransfers = new ArrayList<>();

        for ( State state : states ) {
            stateTransfers.add( createStateTransfer( state ) );
        }

        return stateTransfers.toArray( new StateTransfer[stateTransfers
                .size()] );
    }


    @Override
    public StateTransfer getClientRegisteredState( Long campaignClientId ) {

        CampaignClient campaignClient = campaignClientRepository.findOne( campaignClientId );
        State state = campaignClient.getAddress().getState();
        return createStateTransfer( state );
    }

}

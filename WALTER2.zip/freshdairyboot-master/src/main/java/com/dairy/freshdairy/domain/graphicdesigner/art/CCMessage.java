/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.art;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "cc_messages" )
public class CCMessage extends AbstractPersistentEntity {

    private static final long serialVersionUID = 8833979292935546086L;

    @Column( name = "message", nullable = false, unique = false, length = 500 )
    private String message;

    @Column( name = "read_message", nullable = false, columnDefinition = "boolean default false" )
    private Boolean readMessage;

    // For Sending files
    @ManyToMany( fetch = FetchType.EAGER )
    @JoinTable( name = "ccmessages_artfiles", joinColumns = @JoinColumn(
            name = "ccmessage_id", referencedColumnName = "id" ),
            inverseJoinColumns = @JoinColumn( name = "artfiles_id",
                    referencedColumnName = "id" ) )
    private Set<ArtFile> artFiles;

    @OneToOne( )
    @JoinColumn( name = "fk_message_threads",
            foreignKey = @ForeignKey( name = "fk_messagethreads_ccmessages" ),
            nullable = false )
    private MessageThread messageThread;

    // Nullable FK
    @OneToOne( )
    @JoinColumn( name = "fk_gd_messages",
            foreignKey = @ForeignKey( name = "fk_gdmessages_ccmessages" ),
            nullable = true )
    private GDMessage gdMessage;


    public String getMessage() {

        return message;
    }


    public void setMessage( String message ) {

        this.message = message;
    }


    public Boolean getReadMessage() {

        return readMessage;
    }


    public void setReadMessage( Boolean readMessage ) {

        this.readMessage = readMessage;
    }


    public Set<ArtFile> getArtFiles() {

        return artFiles;
    }


    public void setArtFiles( Set<ArtFile> artFiles ) {

        this.artFiles = artFiles;
    }


    public MessageThread getMessageThread() {

        return messageThread;
    }


    public void setMessageThread( MessageThread messageThread ) {

        this.messageThread = messageThread;
    }


    public GDMessage getGdMessage() {

        return gdMessage;
    }


    public void setGdMessage( GDMessage gdMessage ) {

        this.gdMessage = gdMessage;
    }
}

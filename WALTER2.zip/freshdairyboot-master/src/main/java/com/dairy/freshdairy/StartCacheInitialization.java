/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.service.system.configurable.ConfigurableService;

/**
 * @author John Dickerson
 * @date   17 Oct 2019
 */
@Component
public class StartCacheInitialization {

    @Autowired
    private ConfigurableService configurableService;


    private void initializeCaches() {

        configurableService.reinitializeCache();
    }


    @EventListener( ApplicationReadyEvent.class )
    public void started() {

        initializeCaches();
    }
}

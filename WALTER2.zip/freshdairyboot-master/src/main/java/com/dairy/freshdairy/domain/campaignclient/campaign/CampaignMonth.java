/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.campaignclient.campaign;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "campaign_months" )
public class CampaignMonth extends AbstractPersistentEntity {

    private static final long serialVersionUID = 2022926233620212412L;

    @Column( name = "month_index", unique = false, nullable = false )
    private Integer monthIndex;

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "mail_out_date", nullable = true, unique = false )
    private Date mailOutDate;

    @ManyToOne( )
    @JoinColumn( name = "fk_campaigns",
            foreignKey = @ForeignKey( name = "fk_campaigns_campaignmonths" ),
            nullable = false )
    private Campaign campaign;

    @ManyToOne( )
    @JoinColumn( name = "fk_arts",
            foreignKey = @ForeignKey( name = "fk_arts_campaignmonths" ),
            nullable = true )
    private Art art;


    public Integer getMonthIndex() {

        return monthIndex;
    }


    public void setMonthIndex( Integer monthIndex ) {

        this.monthIndex = monthIndex;
    }


    public Date getMailOutDate() {

        return mailOutDate;
    }


    public void setMailOutDate( Date mailOutDate ) {

        this.mailOutDate = mailOutDate;
    }


    public Campaign getCampaign() {

        return campaign;
    }


    public void setCampaign( Campaign campaign ) {

        this.campaign = campaign;
    }


    public Art getArt() {

        return art;
    }


    public void setArt( Art art ) {

        this.art = art;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.system.configurable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "configurables" )
public class Configurable extends AbstractPersistentEntity {

    private static final long serialVersionUID = -3431531719902982562L;

    @Column( name = "name", nullable = false, unique = false, length = 100 )
    private String name;

    @Column( name = "value", nullable = false, unique = false, length = 100 )
    private String value;

    @OneToOne( )
    @JoinColumn( name = "fk_domain_organisations",
            foreignKey = @ForeignKey( name = "fk_domainorganisations_configurables" ),
            nullable = false )
    private DomainOrganisation domainOrganisation;

    @OneToOne( )
    @JoinColumn( name = "fk_configurable_groups",
            foreignKey = @ForeignKey( name = "fk_configurablegroups_configurables" ),
            nullable = false )
    private ConfigurableGroup configurableGroup;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getValue() {

        return value;
    }


    public void setValue( String value ) {

        this.value = value;
    }


    public DomainOrganisation getDomainOrganisation() {

        return domainOrganisation;
    }


    public void setDomainOrganisation( DomainOrganisation domainOrganisation ) {

        this.domainOrganisation = domainOrganisation;
    }


    public ConfigurableGroup getConfigurableGroup() {

        return configurableGroup;
    }


    public void setConfigurableGroup( ConfigurableGroup configurableGroup ) {

        this.configurableGroup = configurableGroup;
    }
}

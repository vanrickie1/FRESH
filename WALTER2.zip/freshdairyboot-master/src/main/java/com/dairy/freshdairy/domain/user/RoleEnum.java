/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.user;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public enum RoleEnum {

    ADMIN( 1l ),
    CLIENT( 2l );

    private Long id;


    private RoleEnum( Long id ) {

        this.id = id;
    }


    public Long getId() {

        return id;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.art;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "gd_messages" )
public class GDMessage extends AbstractPersistentEntity {

    private static final long serialVersionUID = 1026879526727174218L;

    @Column( name = "message", unique = false, length = 500 )
    private String message;

    @Column( name = "readz", nullable = false, columnDefinition = "TINYINT", length = 1 )
    private Boolean read;

    // For Sending files
    @ManyToMany( fetch = FetchType.EAGER )
    @JoinTable( name = "gdmessages_artfiles", joinColumns = @JoinColumn(
            name = "gdmessage_id", referencedColumnName = "id" ),
            inverseJoinColumns = @JoinColumn( name = "artfiles_id",
                    referencedColumnName = "id" ) )
    private Set<ArtFile> artFiles;

    @OneToOne( )
    @JoinColumn( name = "fk_message_threads",
            foreignKey = @ForeignKey( name = "fk_messagethreads_gdmessages" ),
            nullable = false )
    private MessageThread messageThread;

    // Nullable FK
    @OneToOne( )
    @JoinColumn( name = "fk_cc_messages",
            foreignKey = @ForeignKey( name = "fk_ccmessages_gdmessages" ),
            nullable = true )
    private CCMessage ccMessage;


    public String getMessage() {

        return message;
    }


    public void setMessage( String message ) {

        this.message = message;
    }


    public Boolean getRead() {

        return read;
    }


    public void setRead( Boolean read ) {

        this.read = read;
    }


    public Set<ArtFile> getArtFiles() {

        return artFiles;
    }


    public void setArtFiles( Set<ArtFile> artFiles ) {

        this.artFiles = artFiles;
    }


    public MessageThread getMessageThread() {

        return messageThread;
    }


    public void setMessageThread( MessageThread messageThread ) {

        this.messageThread = messageThread;
    }


    public CCMessage getCcMessage() {

        return ccMessage;
    }


    public void setCcMessage( CCMessage ccMessage ) {

        this.ccMessage = ccMessage;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.forgottenpassword;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.user.ForgottenPassword;
import com.dairy.freshdairy.repository.user.ForgottenPasswordRepository;
import com.dairy.freshdairy.service.system.configurable.ConfigurableService;

/**
 * @author John Dickerson
 * @date   17 Oct 2019
 */
@Service
public class ForgottenPasswordServiceImpl implements ForgottenPasswordService {

    @Autowired
    private ForgottenPasswordRepository forgottenPasswordRepository;

    @Autowired
    private ConfigurableService configurableService;


    @Override
    public ForgottenPassword getForgottenPasswordByEmail( String email ) {

        return forgottenPasswordRepository.findByUserEmail( email.toLowerCase() );
    }


    @Override
    public void save( ForgottenPassword forgottenPassword ) {

        forgottenPasswordRepository.save( forgottenPassword );
    }


    @Override
    public ForgottenPasswordInitialData getInitialData() {

        Integer maxPasswordLength =
                configurableService.getCacheSecurityGroup().getMaxPasswordLength();

        Integer minPasswordLength =
                configurableService.getCacheSecurityGroup().getMinPasswordLength();

        ForgottenPasswordInitialData initialData =
                new ForgottenPasswordInitialData(
                        maxPasswordLength, minPasswordLength );

        return initialData;
    }
}

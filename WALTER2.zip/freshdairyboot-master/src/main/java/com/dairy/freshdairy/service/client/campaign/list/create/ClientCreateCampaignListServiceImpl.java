/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.list.create;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignList;
import com.dairy.freshdairy.domain.campaignclient.campaign.MailoutAddress;
import com.dairy.freshdairy.helper.mailoutaddresscsv.MailOutAddressCsvHelper;
import com.dairy.freshdairy.helper.mailoutaddresscsv.MailoutAddressCsvHelperException;
import com.dairy.freshdairy.helper.mailoutaddresscsv.MailoutAddressTransfer;
import com.dairy.freshdairy.helper.state.StateHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignListRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.MailoutAddressRepository;
import com.dairy.freshdairy.service.client.campaign.list.upload.QuoteTypeEnum;
import com.dairy.freshdairy.service.client.campaign.list.upload.QuoteTypeTransfer;
import com.dairy.freshdairy.service.shared.transfer.StateTransfer;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
@Service
public class ClientCreateCampaignListServiceImpl implements ClientCreateCampaignListService {

    @Autowired
    private StateHelper stateHelper;

    @Autowired
    private MailOutAddressCsvHelper mailOutAddressCsvHelper;

    @Autowired
    private MailoutAddressRepository mailoutAddressRepository;

    @Autowired
    private CampaignListRepository campaignListRepository;

    @Autowired
    private CampaignClientRepository campaignClientRepository;


    // currently hard coded
    private ZipTransfer[] getZipTransfers( Long statusId ) {

        ZipTransfer[] zipTransfers = new ZipTransfer[10];
        zipTransfers[0] = new ZipTransfer( "111 123", statusId );
        zipTransfers[1] = new ZipTransfer( "111 124", statusId );
        zipTransfers[2] = new ZipTransfer( "111 125", statusId );
        zipTransfers[3] = new ZipTransfer( "111 126", statusId );
        zipTransfers[4] = new ZipTransfer( "111 127", statusId );
        zipTransfers[5] = new ZipTransfer( "111 128", statusId );
        zipTransfers[6] = new ZipTransfer( "111 129", statusId );
        zipTransfers[7] = new ZipTransfer( "111 130", statusId );
        zipTransfers[8] = new ZipTransfer( "111 131", statusId );
        zipTransfers[9] = new ZipTransfer( "111 132", statusId );
        return zipTransfers;
    }


    private ZipTransfer[] getZipTransfers( StateTransfer stateTransfer ) {

        Long statusId = stateTransfer.getId();
        return getZipTransfers( statusId );
    }


    // Currently hardcoded
    private HouseholdSizeTransfer[] getHouseholdSizeTransfers() {

        HouseholdSizeTransfer[] householdSizeTransfers = new HouseholdSizeTransfer[4];
        householdSizeTransfers[0] = new HouseholdSizeTransfer( 1l, "Single" );
        householdSizeTransfers[1] = new HouseholdSizeTransfer( 1l, "Couple" );
        householdSizeTransfers[2] = new HouseholdSizeTransfer( 1l, "Family with 2 Kids" );
        householdSizeTransfers[3] = new HouseholdSizeTransfer( 1l, "Family with more Kids" );
        return householdSizeTransfers;
    }


    // Currently hardcoded
    private IncomeRangeTransfer[] getIncomeRangeTransfers() {

        IncomeRangeTransfer[] incomeRangeTransfers = new IncomeRangeTransfer[7];
        incomeRangeTransfers[0] = new IncomeRangeTransfer( 1l, "Unemployed" );
        incomeRangeTransfers[1] = new IncomeRangeTransfer( 2l, "< 10,000" );
        incomeRangeTransfers[2] = new IncomeRangeTransfer( 3l, "10,000 - 20,000" );
        incomeRangeTransfers[3] = new IncomeRangeTransfer( 4l, "20,001 - 40,000" );
        incomeRangeTransfers[4] = new IncomeRangeTransfer( 5l, "40,001 - 70,000" );
        incomeRangeTransfers[5] = new IncomeRangeTransfer( 6l, "70,000 - 120,000" );
        incomeRangeTransfers[6] = new IncomeRangeTransfer( 7l, "120,000+" );
        return incomeRangeTransfers;
    }


    private FilterTransfer getFilterTransfer() {

        HouseholdSizeTransfer[] householdSizeTransfers = getHouseholdSizeTransfers();
        IncomeRangeTransfer[] incomeRangeTransfers = getIncomeRangeTransfers();

        FilterTransfer filterTransfer =
                new FilterTransfer( householdSizeTransfers, incomeRangeTransfers );

        return filterTransfer;
    }


    // Currently hardcoded
    private BigDecimal getMailoutUnitCost() {

        return new BigDecimal( 0.20 );
    }


    private MailoutAddress createMailoutAddress( CampaignList campaignList,
            MailoutAddressTransfer mailoutAddressTransfer ) {

        MailoutAddress mailoutAddress = new MailoutAddress();
        mailoutAddress.setApartmentSuite( mailoutAddressTransfer.getApartmentSuite() );
        mailoutAddress.setCampaignList( campaignList );
        mailoutAddress.setCity( mailoutAddressTransfer.getCity() );
        mailoutAddress.setFullName( mailoutAddressTransfer.getFullName() );
        mailoutAddress.setState( mailoutAddressTransfer.getState() );
        mailoutAddress.setStreetAddress( mailoutAddressTransfer.getStreetAddress() );
        mailoutAddress.setZip( mailoutAddressTransfer.getZip() );
        return mailoutAddress;
    }


    private SaveMailAddressResponse save(
            CampaignList campaignList, MailoutAddressTransfer[] mailoutAddressTransfers ) {

        List<MailoutAddress> mailoutAddresses = new ArrayList<>();

        for ( MailoutAddressTransfer mailoutAddressTransfer : mailoutAddressTransfers ) {

            mailoutAddresses.add( createMailoutAddress( campaignList, mailoutAddressTransfer ) );
        }

        mailoutAddressRepository.save( mailoutAddresses );
        SaveMailAddressResponse response = new SaveMailAddressResponse( Boolean.TRUE, null );
        return response;
    }


    private CampaignList createCampaignList( ClientCreateCampaignListRequest request,
            CampaignClient campaignClient ) {

        CampaignList campaignList = new CampaignList();
        campaignList.setCampaignClient( campaignClient );
        campaignList.setDescription( request.getDescription() );
        campaignList.setName( request.getName() );
        CampaignList savedcampaignList = campaignListRepository.save( campaignList );
        return savedcampaignList;
    }


    private QuoteTypeTransfer createQuoteTypeTransfer( QuoteTypeEnum quoteTypeEnum ) {

        QuoteTypeTransfer transfer =
                new QuoteTypeTransfer( quoteTypeEnum.getQuoteId(),
                        quoteTypeEnum.getName() );

        return transfer;
    }


    private QuoteTypeTransfer[] getQuoteTypeTransfers() {

        List<QuoteTypeTransfer> quoteTypeTransfers = new ArrayList<>();

        for ( QuoteTypeEnum quoteTypeEnum : QuoteTypeEnum.values() ) {

            quoteTypeTransfers.add( createQuoteTypeTransfer( quoteTypeEnum ) );
        }

        return quoteTypeTransfers.toArray( new QuoteTypeTransfer[quoteTypeTransfers.size()] );
    }


    @Override
    public ClientCreateCampaignListInitialData getInitialData(
            Long campaignClientId ) {

        StateTransfer stateTransfer = stateHelper.getClientRegisteredState( campaignClientId );
        ZipTransfer[] zipTransfers = getZipTransfers( stateTransfer );
        FilterTransfer filterTransfer = getFilterTransfer();
        BigDecimal mailoutUnitCost = getMailoutUnitCost();
        QuoteTypeTransfer[] quoteTypeTransfers = getQuoteTypeTransfers();

        ClientCreateCampaignListInitialData initialData =
                new ClientCreateCampaignListInitialData( stateTransfer,
                        zipTransfers, filterTransfer, quoteTypeTransfers, mailoutUnitCost );

        return initialData;
    }


    @Override
    @Transactional
    public SaveMailAddressResponse save( ClientCreateCampaignListRequest request,
            MultipartFile csvFile, Long campaignClientId ) {

        SaveMailAddressResponse response;

        try {
            byte[] bytes = csvFile.getBytes();
            String csvString = new String( bytes );
            Long quoteId = request.getQuoteId();
            QuoteTypeEnum quoteTypeEnum = QuoteTypeEnum.findByQuoteId( quoteId );
            String quote = quoteTypeEnum.getQuote();

            MailoutAddressTransfer[] mailoutAddressTransfers =
                    mailOutAddressCsvHelper.createMailoutAddressTransfers( csvString, quote );

            CampaignClient campaignClient = campaignClientRepository.findOne( campaignClientId );
            CampaignList campaignList = createCampaignList( request, campaignClient );
            response = save( campaignList, mailoutAddressTransfers );
        }
        catch ( IOException e ) {

            throw new RuntimeException( "Error reading bytes from uploaded file", e );
        }
        catch ( MailoutAddressCsvHelperException e ) {

            Boolean saved = false;
            String formatError = e.getFormatError();
            response = new SaveMailAddressResponse( saved, formatError );
        }

        return response;
    }
}

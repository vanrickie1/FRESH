/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.edit;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFile;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFileTypeEnum;
import com.dairy.freshdairy.helper.art.ArtHelper;
import com.dairy.freshdairy.helper.artfile.ArtFileHelper;
import com.dairy.freshdairy.helper.file.FileHelper;
import com.dairy.freshdairy.helper.filetype.FileTypeHelper;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtFileRepository;
import com.dairy.freshdairy.service.client.campaign.art.AbstractArtService;
import com.dairy.freshdairy.service.client.campaign.art.FileTypeTransfer;
import com.dairy.freshdairy.service.client.campaign.art.SaveArtResponse;

/**
 * @author John Dickerson
 * @date 31 Oct 2019
 */
@Service
public class ClientEditArtServiceImpl extends AbstractArtService implements ClientEditArtService {

	@Autowired
	private FileTypeHelper fileTypeHelper;

	@Autowired
	private FileHelper fileHelper;

	@Autowired
	private ArtHelper artHelper;

	@Autowired
	private ArtFileHelper artFileHelper;

	@Autowired
	private ArtFileRepository artFileRepository;

	private void removeOldBackArtFile(Long artId) {

		ArtFile artFile = artFileRepository.findByArtIdAndArtFileTypeId(artId, ArtFileTypeEnum.BACK.getArtFileTypeId());

		String artPath = artFile.getPath();
		fileHelper.deleteFile(artPath);
		artFileRepository.delete(artFile);
	}

	private void removeOldFrontArtFile(Long artId) {

		ArtFile artFile = artFileRepository.findByArtIdAndArtFileTypeId(artId,
				ArtFileTypeEnum.FRONT.getArtFileTypeId());

		String artPath = artFile.getPath();
		fileHelper.deleteFile(artPath);
		artFileRepository.delete(artFile);
	}

	@Override
	public ClientEditArtInitialData getInitialData() {

		FileTypeTransfer[] fileTypeTransfers = fileTypeHelper.createFileTypeTransfers();
		ClientEditArtInitialData initialData = new ClientEditArtInitialData(fileTypeTransfers);
		return initialData;
	}

	@Override
	public SaveArtResponse save(Long domainOrganisationId, ClientEditArtRequest request,
			MultipartFile backArtMultipartFile, MultipartFile frontArtMultipartFile) throws IOException {

		byte[] backBytes = backArtMultipartFile.getBytes();
		byte[] frontBytes = frontArtMultipartFile.getBytes();

		SaveArtResponse response = checkDimensions(backBytes, frontBytes);

		Art art = artHelper.saveArt(request);

		if (backBytes != null) {

			removeOldBackArtFile(art.getId());

			String backPath = fileHelper.saveFile(domainOrganisationId, ART_NAMESPACE, backArtMultipartFile.getBytes(),
					backArtMultipartFile.getOriginalFilename());

			artFileHelper.saveBackArtFile(art, backPath);
		}

		if (frontBytes != null) {

			removeOldFrontArtFile(art.getId());

			String frontPath = fileHelper.saveFile(domainOrganisationId, ART_NAMESPACE,
					frontArtMultipartFile.getBytes(), frontArtMultipartFile.getOriginalFilename());

			artFileHelper.saveFrontArtFile(art, frontPath);
		}

		return response;
	}
}

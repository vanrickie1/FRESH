/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.create;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.campaignclient.campaign.Campaign;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignFrequencyType;
import com.dairy.freshdairy.helper.campaignfrequencytype.CampaignFrequencyTypeHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignFrequencyTypeRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignRepository;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;

/**
 * @author John Dickerson
 * @date   27 Oct 2019
 */
@Service
public class ClientCreateCampaignServiceImpl implements ClientCreateCampaignService {

    @Autowired
    private CampaignFrequencyTypeRepository campaignFrequencyTypeRepository;

    @Autowired
    private CampaignClientRepository campaignClientRepository;

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private CampaignFrequencyTypeHelper campaignFrequencyTypeHelper;


    public ClientCreateCampaignServiceImpl() {

    }


    @Override
    public ClientCreateCampaignInitialData getInitialData() {

        CampaignFrequencyTypeTransfer[] campaignFrequencyTypeTransfers =
                campaignFrequencyTypeHelper.createCampaignFrequencyTypeTransfers();

        ClientCreateCampaignInitialData initialData =
                new ClientCreateCampaignInitialData( campaignFrequencyTypeTransfers );

        return initialData;
    }


    @Override
    public SaveResponse save( CreateCampaignRequest request, Long campaignClientId ) {

        Campaign campaign = new Campaign();
        CampaignClient campaignClient = campaignClientRepository.findOne( campaignClientId );
        campaign.setCampaignClient( campaignClient );

        CampaignFrequencyType campaignFrequencyType =
                campaignFrequencyTypeRepository.findOne( request.getCampaignFrequencyTypeId() );

        campaign.setCampaignFrequencyType( campaignFrequencyType );
        campaign.setName( request.getCampaignName() );
        campaign.setActivated( Boolean.FALSE );
        campaignRepository.save( campaign );
        return new SaveResponse( Boolean.TRUE, null );
    }
}

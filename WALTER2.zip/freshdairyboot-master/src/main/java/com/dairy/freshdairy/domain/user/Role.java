/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.user;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "roles" )
public class Role extends AbstractPersistentEntity {

    private static final long serialVersionUID = -8972076679797077250L;

    @Column( name = "name", nullable = false, unique = false, length = 60 )
    private String name;

    @ManyToMany( fetch = FetchType.EAGER )
    @JoinTable( name = "roles_permissions", joinColumns = @JoinColumn(
            name = "roles_id", referencedColumnName = "id" ),
            inverseJoinColumns = @JoinColumn( name = "permissions_id",
                    referencedColumnName = "id" ) )
    private Set<Permission> permissions = new HashSet<Permission>();


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public Set<Permission> getPermissions() {

        return permissions;
    }


    public void setPermissions( Set<Permission> permissions ) {

        this.permissions = permissions;
    }
}

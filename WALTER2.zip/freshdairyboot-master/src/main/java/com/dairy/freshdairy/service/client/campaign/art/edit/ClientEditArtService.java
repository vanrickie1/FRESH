/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.edit;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.dairy.freshdairy.service.client.campaign.art.SaveArtResponse;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
public interface ClientEditArtService {

    String ART_NAMESPACE = "art";


    ClientEditArtInitialData getInitialData();


    SaveArtResponse save( Long domainOrganisationId, ClientEditArtRequest request,
            MultipartFile backArtMultipartFile,
            MultipartFile frontArtMultipartFile ) throws IOException;
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.address.Address;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "domain_organisations" )
public class DomainOrganisation extends AbstractPersistentEntity {

    private static final long serialVersionUID = 8464445691957161549L;

    @Column( name = "organisation_name", nullable = false, unique = false,
            length = 30 )
    private String organisationName;

    @Column( name = "domain", nullable = false, unique = false,
            length = 254 )
    private String domain;

    @ManyToOne( )
    @JoinColumn( name = "fk_address",
            foreignKey = @ForeignKey( name = "fk_address_domainorganisations" ),
            nullable = true )
    private Address address;


    public String getOrganisationName() {

        return organisationName;
    }


    public void setOrganisationName( String organisationName ) {

        this.organisationName = organisationName;
    }


    public String getDomain() {

        return domain;
    }


    public void setDomain( String domain ) {

        this.domain = domain;
    }


    public Address getAddress() {

        return address;
    }


    public void setAddress( Address address ) {

        this.address = address;
    }
}

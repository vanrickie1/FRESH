/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.show;

/**
 * @author John Dickerson
 * @date   27 Oct 2019
 */
public class CampaignTransfer {

    private Long id;
    private String campaignName;
    private Boolean campaignActivated;
    private Boolean campaignConfigured;
    private Boolean hasList;
    private Integer numberArt;
    private String campaignType;


    public CampaignTransfer() {

    }


    public CampaignTransfer( Long id, String campaignName, Boolean campaignActivated,
            Boolean campaignConfigured, Boolean hasList, Integer numberArt, String campaignType ) {

        super();
        this.id = id;
        this.campaignName = campaignName;
        this.campaignActivated = campaignActivated;
        this.campaignConfigured = campaignConfigured;
        this.hasList = hasList;
        this.numberArt = numberArt;
        this.campaignType = campaignType;
    }


    public Long getId() {

        return id;
    }


    public void setId( Long id ) {

        this.id = id;
    }


    public String getCampaignName() {

        return campaignName;
    }


    public void setCampaignName( String campaignName ) {

        this.campaignName = campaignName;
    }


    public Boolean getCampaignActivated() {

        return campaignActivated;
    }


    public void setCampaignActivated( Boolean campaignActivated ) {

        this.campaignActivated = campaignActivated;
    }


    public Boolean getCampaignConfigured() {

        return campaignConfigured;
    }


    public void setCampaignConfigured( Boolean campaignConfigured ) {

        this.campaignConfigured = campaignConfigured;
    }


    public Boolean getHasList() {

        return hasList;
    }


    public void setHasList( Boolean hasList ) {

        this.hasList = hasList;
    }


    public Integer getNumberArt() {

        return numberArt;
    }


    public void setNumberArt( Integer numberArt ) {

        this.numberArt = numberArt;
    }


    public String getCampaignType() {

        return campaignType;
    }


    public void setCampaignType( String campaignType ) {

        this.campaignType = campaignType;
    }
}

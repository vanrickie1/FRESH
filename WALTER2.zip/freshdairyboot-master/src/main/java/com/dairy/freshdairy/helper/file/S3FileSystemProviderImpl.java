/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.file;

import org.springframework.stereotype.Component;

/**
 * @author John Dickerson
 * @date   30 Oct 2019
 */
@Component
public class S3FileSystemProviderImpl implements S3FileSystemProvider {

    @Override
    public String saveFile( Long domainOrganisationId, String namespace, byte[] bytes,
            String orignalFileName ) {

        return null;
    }


    @Override
    public void deleteFile( String path ) {

    }
}

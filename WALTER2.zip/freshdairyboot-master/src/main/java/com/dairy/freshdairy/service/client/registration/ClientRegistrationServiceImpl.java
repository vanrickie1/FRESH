/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.registration;

import java.util.Locale;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.address.Address;
import com.dairy.freshdairy.domain.address.AddressType;
import com.dairy.freshdairy.domain.address.AddressTypeEnum;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.customer.Customer;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.user.EmailActivationCode;
import com.dairy.freshdairy.domain.user.Permission;
import com.dairy.freshdairy.domain.user.Role;
import com.dairy.freshdairy.domain.user.RoleEnum;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.hash.HashHelper;
import com.dairy.freshdairy.helper.state.StateHelper;
import com.dairy.freshdairy.helper.string.StringHelper;
import com.dairy.freshdairy.repository.address.AddressRepository;
import com.dairy.freshdairy.repository.address.AddressTypeRepository;
import com.dairy.freshdairy.repository.address.StateRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.repository.customer.CustomerRepository;
import com.dairy.freshdairy.repository.domain.DomainOrganisationRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;
import com.dairy.freshdairy.repository.user.EmailActivationCodeRepository;
import com.dairy.freshdairy.repository.user.RoleRepository;
import com.dairy.freshdairy.repository.user.UserRepository;
import com.dairy.freshdairy.service.shared.email.EmailService;
import com.dairy.freshdairy.service.shared.transfer.StateTransfer;
import com.dairy.freshdairy.service.system.configurable.ConfigurableService;

/**
 * @author John Dickerson
 * @date 15 Oct 2019
 */
@Service
public class ClientRegistrationServiceImpl implements ClientRegistrationService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailActivationCodeRepository emailActivationCodeRepository;

	@Autowired
	private StringHelper s;

	@Autowired
	private HashHelper hashHelper;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private DomainOrganisationRepository domainOrganisationRepository;

	@Autowired
	private AddressTypeRepository addressTypeRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private ArtRepository artRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CampaignClientRepository campaignClientRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	private ConfigurableService configurableService;

	@Autowired
	private StateHelper stateHelper;

	@Autowired
	private StateRepository stateRepository;

	private String createEmailActivationCode() {

		return hashHelper.getRandomHash();
	}

	private String getPasswordHash(String password) {

		return hashHelper.getPasswordHashWithBcrypt(password);
	}

	private Set<Permission> getPermissionsForClient() {

		Role role = roleRepository.findOne(RoleEnum.CLIENT.getId());
		return role.getPermissions();
	}

	private Customer saveCustomer(DomainOrganisation domainOrganisation, DrawRequest request) {

		Art art = artRepository.findOne(request.getArtId());
		Customer customer = new Customer();
		customer.setDomainOrganisation(domainOrganisation);
		customer.setFirstName(request.getFirstName());
		customer.setLastName(request.getLastName());
		customer.setOutlet(request.getOutlet());
		customer.setLocation(request.getLocation());
		customer.setPhoneNumber(request.getPhoneNumber());
		customer.setReceiptNumber(request.getReceiptNumber());
		customer.setArt(art);

		return customerRepository.save(customer);
	}

	private User saveUser(DomainOrganisation domainOrganisation, RegistrationRequest request) {

		User user = new User();
		user.setDomainOrganisation(domainOrganisation);
		user.setEmail(s.trim(request.getEmail()));
		user.setEnabled(Boolean.FALSE);
		user.setFirstName(s.trim(request.getFirstName()));
		user.setLastName(s.trim(request.getLastName()));

		String emailActivationCodeStr = createEmailActivationCode();
		EmailActivationCode emailActivationCode = new EmailActivationCode();
		emailActivationCode.setCode(emailActivationCodeStr);

		EmailActivationCode savedEmailActivationCode = emailActivationCodeRepository.save(emailActivationCode);

		user.setEmailActivationCode(savedEmailActivationCode);
		String passwordHash = getPasswordHash(request.getPassword());
		user.setPasswordHash(passwordHash);
		user.getPermissions().addAll(getPermissionsForClient());
		return userRepository.save(user);
	}

	private AddressType getClientAddressType() {

		return addressTypeRepository.findOne(AddressTypeEnum.CLIENT.getId());
	}

	private Address saveClientAddress(RegistrationRequest request) {

		Address address = new Address();
		address.setAddressType(getClientAddressType());
		address.setApartmentSuite(request.getApartmentSuite());
		address.setCity(request.getCity());
		address.setStreetAddress(request.getStreetAddress());
		address.setState(stateRepository.findOne(request.getStateId()));
		address.setZip(request.getZip());
		return addressRepository.save(address);
	}

	private void saveCampaignClient(User user, Address address, RegistrationRequest request) {

		CampaignClient campaignClient = new CampaignClient();
		campaignClient.setAddress(address);
		campaignClient.setCompanyName(s.trim(request.getCompanyName()));
		campaignClient.setEnabled(Boolean.FALSE);
		campaignClient.setUser(user);
		campaignClientRepository.save(campaignClient);
	}

	private void sendActivationEmail(DomainOrganisation domainOrganisation, Integer serverPort, String protocol,
			User user) {

		Locale locale = new Locale("en");
		String email = user.getEmail();
		String domain = domainOrganisation.getDomain();

		emailService.sendActivationEmail(domainOrganisation, user, email, locale, domain, serverPort, protocol);
	}

	@Override
	public RegistrationInitialData getInitialData() {

		StateTransfer[] states = stateHelper.getStateTransfers();

		Integer minPasswordLength = configurableService.getCacheSecurityGroup().getMinPasswordLength();

		Integer maxPasswordLength = configurableService.getCacheSecurityGroup().getMaxPasswordLength();

		RegistrationInitialData initialData = new RegistrationInitialData(states, minPasswordLength, maxPasswordLength);

		return initialData;
	}

	@Override
	@Transactional
	public RegistrationSaveResponse saveRegistrationRequest(RegistrationRequest request, String domain,
			Integer serverPort, String protocol) {

		Boolean saved = Boolean.FALSE;
		Boolean emailExistsAlready = Boolean.FALSE;
		Boolean passwordTooShort = Boolean.FALSE;
		Boolean passwordTooLong = Boolean.FALSE;
		String email = request.getEmail();
		User user = userRepository.findByEmail(email);

		Integer minPasswordLength = configurableService.getCacheSecurityGroup().getMinPasswordLength();

		Integer maxPasswordLength = configurableService.getCacheSecurityGroup().getMaxPasswordLength();

		String password = request.getPassword();
		Integer passwordLength = password.length();

		if (passwordLength < minPasswordLength) {

			passwordTooShort = Boolean.TRUE;
		} else if (passwordLength > maxPasswordLength) {

			passwordTooLong = Boolean.TRUE;
		}

		if (user != null) {

			emailExistsAlready = Boolean.TRUE;
		}

		if (!passwordTooShort && !passwordTooLong && !emailExistsAlready) {

			DomainOrganisation domainOrganisation = domainOrganisationRepository.findByDomain(domain);

			User savedUser = saveUser(domainOrganisation, request);
			Address savedAddress = saveClientAddress(request);
			saveCampaignClient(savedUser, savedAddress, request);
			sendActivationEmail(domainOrganisation, serverPort, protocol, savedUser);
			saved = Boolean.TRUE;
		} else {
			saved = Boolean.FALSE;
		}

		RegistrationSaveResponse response = new RegistrationSaveResponse(saved, emailExistsAlready, passwordTooShort,
				minPasswordLength, maxPasswordLength);

		return response;
	}

	@Override
	@Transactional
	public DrawSaveResponse saveDrawRequest(DrawRequest request, String domain, Integer serverPort, String protocol) {

		Boolean saved = Boolean.FALSE;
		Boolean receiptExistsAlready = Boolean.FALSE;

		DomainOrganisation domainOrganisation = domainOrganisationRepository.findByDomain(domain);

		Customer customer = customerRepository.findByReceiptNumber(request.getReceiptNumber());

		if (customer != null) {

			receiptExistsAlready = Boolean.TRUE;
		} else {
			saveCustomer(domainOrganisation, request);
			saved = Boolean.TRUE;
		}

		DrawSaveResponse response = new DrawSaveResponse(saved, receiptExistsAlready);
		return response;
	}
}

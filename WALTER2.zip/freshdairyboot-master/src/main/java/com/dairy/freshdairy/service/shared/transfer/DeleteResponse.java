/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.shared.transfer;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
public class DeleteResponse {

    private boolean deleted;
    private String error;


    public DeleteResponse() {

    }


    public DeleteResponse( boolean deleted, String error ) {

        super();
        this.deleted = deleted;
        this.error = error;
    }


    public boolean isDeleted() {

        return deleted;
    }


    public void setDeleted( boolean deleted ) {

        this.deleted = deleted;
    }


    public String getError() {

        return error;
    }


    public void setError( String error ) {

        this.error = error;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.link;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.campaignclient.campaign.Campaign;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignFrequencyType;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignFrequencyTypeEnum;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignList;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignMonth;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFile;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFileTypeEnum;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignListRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignMonthRepository;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtFileRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;

/**
 * @author John Dickerson
 * @date   12 Nov 2019
 */
@Service
public class CampaignLinkServiceImpl implements CampaignLinkService {

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private CampaignMonthRepository campaignMonthRepository;

    @Autowired
    private ArtRepository artRepository;

    @Autowired
    private ArtFileRepository artFileRepository;

    @Autowired
    private CampaignListRepository campaignListRepository;


    private ArtTransfer createArtTransfer( Art art ) {

        ArtFile frontArtFile =
                artFileRepository.findByArtIdAndArtFileTypeId( art.getId(), ArtFileTypeEnum.FRONT
                        .getArtFileTypeId() );

        ArtFile backArtFile =
                artFileRepository.findByArtIdAndArtFileTypeId( art.getId(), ArtFileTypeEnum.BACK
                        .getArtFileTypeId() );

        Long frontArtFileId = null;
        Long backArtFileId = null;

        if ( frontArtFile != null ) {

            frontArtFileId = frontArtFile.getId();
        }

        if ( backArtFile != null ) {

            backArtFileId = backArtFile.getId();
        }

        ArtTransfer artTransfer =
                new ArtTransfer( art.getId(), art.getName(), frontArtFileId, backArtFileId );

        return artTransfer;
    }


    private ArtTransfer[] createArtTransfers( CampaignClient campaignClient ) {

        Set<Art> arts = campaignClient.getArts();
        List<ArtTransfer> artTransfers = new ArrayList<>();

        for ( Art art : arts ) {

            artTransfers.add( createArtTransfer( art ) );
        }

        return artTransfers.toArray( new ArtTransfer[artTransfers.size()] );
    }


    private ListTransfer createListTransfer( CampaignList campaignList ) {

        ListTransfer listTransfer =
                new ListTransfer( campaignList.getId(), campaignList.getName() );

        return listTransfer;
    }


    private ListTransfer[] createListTransfers( CampaignClient campaignClient ) {

        Set<CampaignList> campaignClients = campaignClient.getCampaignLists();
        List<ListTransfer> listTransfers = new ArrayList<>();

        for ( CampaignList campaignList : campaignClients ) {

            listTransfers.add( createListTransfer( campaignList ) );
        }

        return listTransfers.toArray( new ListTransfer[listTransfers.size()] );
    }


    private CampaignMonthTransfer[] getCampaignMonthsMonthly() {

        CampaignMonthTransfer[] campaignMonthTransfers = new CampaignMonthTransfer[12];

        for ( int i = 0; i < 12; i++ ) {

            campaignMonthTransfers[i] = new CampaignMonthTransfer();
            campaignMonthTransfers[i].setMonthIndex( i + 1 );
        }

        return campaignMonthTransfers;
    }


    private CampaignMonthTransfer[] getCampaignMonthsQuarterly() {

        CampaignMonthTransfer[] campaignMonthTransfers = new CampaignMonthTransfer[4];
        campaignMonthTransfers[0] = new CampaignMonthTransfer();
        campaignMonthTransfers[0].setMonthIndex( 1 );
        campaignMonthTransfers[1] = new CampaignMonthTransfer();
        campaignMonthTransfers[1].setMonthIndex( 3 );
        campaignMonthTransfers[2] = new CampaignMonthTransfer();
        campaignMonthTransfers[2].setMonthIndex( 6 );
        campaignMonthTransfers[3] = new CampaignMonthTransfer();
        campaignMonthTransfers[3].setMonthIndex( 9 );
        return campaignMonthTransfers;
    }


    private CampaignMonthTransfer[] getCampaignMonthsSingle() {

        CampaignMonthTransfer[] campaignMonthTransfers = new CampaignMonthTransfer[1];
        campaignMonthTransfers[0] = new CampaignMonthTransfer();
        campaignMonthTransfers[0].setMonthIndex( 1 );
        return campaignMonthTransfers;
    }


    private CampaignMonthTransfer[] createCampaignMonths( Campaign campaign ) {

        CampaignFrequencyType campaignFrequencyType = campaign.getCampaignFrequencyType();
        Long campaignFrequencyTypeId = campaignFrequencyType.getId();

        CampaignFrequencyTypeEnum campaignFrequencyTypeEnum =
                CampaignFrequencyTypeEnum.getById( campaignFrequencyTypeId );

        CampaignMonthTransfer[] campaignMonthTransfers = null;

        switch ( campaignFrequencyTypeEnum ) {

            case MONTH:
                campaignMonthTransfers = getCampaignMonthsMonthly();
                break;

            case QUARTERLY:
                campaignMonthTransfers = getCampaignMonthsQuarterly();
                break;

            case SINGLE:
                campaignMonthTransfers = getCampaignMonthsSingle();
                break;
        }

        return campaignMonthTransfers;
    }


    private void removeExistingCampaignMonths( Campaign campaign ) {

        Set<CampaignMonth> existingCampaignMonths = campaign.getCampaignMonths();

        if ( existingCampaignMonths.size() > 0 ) {

            campaignMonthRepository.delete( existingCampaignMonths );
        }
    }


    private void saveCampaignMonth( Campaign campaign, CampaignArtRequest campaignArtRequest ) {

        Long artId = campaignArtRequest.getArtId();
        Art art = artRepository.findOne( artId );
        CampaignMonth campaignMonth = new CampaignMonth();
        campaignMonth.setArt( art );
        campaignMonth.setCampaign( campaign );
        campaignMonth.setMonthIndex( campaignArtRequest.getMonthIndex() );
        campaignMonthRepository.save( campaignMonth );
    }


    private void saveCampaignList( Campaign campaign, Long campaignListId ) {

        CampaignList campaignList = campaignListRepository.findOne( campaignListId );
        campaign.setCampaignList( campaignList );
        campaignRepository.save( campaign );
    }


    @Override
    public CampaignLinkInitialData getInitialData( Long campaignId ) {

        Campaign campaign = campaignRepository.findOne( campaignId );
        CampaignClient campaignClient = campaign.getCampaignClient();
        String campaignName = campaign.getName();
        String campaignFrequencyType = campaign.getCampaignFrequencyType().getName();
        ArtTransfer[] arts = createArtTransfers( campaignClient );
        ListTransfer[] lists = createListTransfers( campaignClient );
        CampaignMonthTransfer[] campaignMonths = createCampaignMonths( campaign );

        CampaignLinkInitialData initialData =
                new CampaignLinkInitialData(
                        campaignName,
                        campaignFrequencyType,
                        campaignId,
                        arts,
                        lists,
                        campaignMonths );

        return initialData;
    }


    @Override
    @Transactional
    public SaveResponse save( CampaignLinkRequest request ) {

        Long campaignId = request.getCampaignId();
        Campaign campaign = campaignRepository.findOne( campaignId );
        CampaignArtRequest[] campaignArtRequests = request.getCampaignArtRequests();
        removeExistingCampaignMonths( campaign );

        for ( CampaignArtRequest campaignArtRequest : campaignArtRequests ) {

            saveCampaignMonth( campaign, campaignArtRequest );
        }

        saveCampaignList( campaign, request.getCampaignListId() );
        return new SaveResponse( Boolean.TRUE, null );
    }
}

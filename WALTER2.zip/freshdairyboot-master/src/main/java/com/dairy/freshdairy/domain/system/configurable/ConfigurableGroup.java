/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.system.configurable;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "configurable_groups" )
public class ConfigurableGroup extends AbstractPersistentEntity {

    private static final long serialVersionUID = -8913609830021642638L;

    @Column( name = "name", nullable = false, unique = false,
            length = 60 )
    private String name;

    @OneToMany( mappedBy = "configurableGroup" )
    private Set<Configurable> configurables;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public Set<Configurable> getConfigurables() {

        return configurables;
    }


    public void setConfigurables( Set<Configurable> configurables ) {

        this.configurables = configurables;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.date;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public interface DateHelper {

    SimpleDateFormat FORMAT_yyyy_MM_dd_HH_mm_ss_SSS = new SimpleDateFormat(
            "yyyy_MM_dd_HH_mm_ss_SSS" );

    SimpleDateFormat FORMAT_EEE_d_MMMM_yyyy = new SimpleDateFormat(
            "EEEE, MMMM d, yyyy" );


    String getLetterDateFormatForLocale( Date date, Locale locale );
}

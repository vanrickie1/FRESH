/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.shared;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dairy.freshdairy.domain.domain.DomainOrganisation;
import com.dairy.freshdairy.domain.user.User;
import com.dairy.freshdairy.helper.email.EmailActivationResponse;
import com.dairy.freshdairy.helper.email.EmailSentResponse;
import com.dairy.freshdairy.helper.loggingin.LoggedInCredentialsHelper;
import com.dairy.freshdairy.repository.domain.DomainOrganisationRepository;
import com.dairy.freshdairy.repository.user.UserRepository;
import com.dairy.freshdairy.service.shared.email.EmailService;
import com.dairy.freshdairy.service.shared.email.ForgottenPasswordRequest;
import com.dairy.freshdairy.service.shared.forgottenpassword.ForgottenPasswordInitialData;
import com.dairy.freshdairy.service.shared.forgottenpassword.ForgottenPasswordService;
import com.dairy.freshdairy.service.shared.forgottenpassword.reset.ResetUserForgottenPasswordService;
import com.dairy.freshdairy.service.shared.forgottenpassword.reset.UserResetForgottenPasswordRequest;
import com.dairy.freshdairy.service.shared.forgottenpassword.reset.UserVerifyForgottenPasswordCodeRequest;
import com.dairy.freshdairy.service.shared.forgottenpassword.reset.VerificationResponse;
import com.dairy.freshdairy.service.shared.loggedindetails.LoggedInUserDetails;
import com.dairy.freshdairy.service.shared.loggedindetails.LoggedInUserDetailsService;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;
import com.dairy.freshdairy.threads.ThreadLocals;

/**
 * @author John Dickerson
 * @date   17 Oct 2019
 */
@RestController
@RequestMapping( "/freshdairy/user/" )
public class SharedControlller {

    @Autowired
    private EmailService emailService;

    @Autowired
    private LoggedInCredentialsHelper loggedInCredentialsHelper;

    @Autowired
    private LoggedInUserDetailsService loggedInUserDetailsService;

    @Autowired
    private ResetUserForgottenPasswordService resetUserForgottenPasswordService;

    @Autowired
    private DomainOrganisationRepository domainOrganisationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ForgottenPasswordService forgottenPasswordService;


    /**
     * Call this method to get the username for the header
     */
    @RequestMapping( value = "/forgottenpassword/initialdata",
            method = RequestMethod.POST )
    public ResponseEntity<ForgottenPasswordInitialData> getForgottenPasswordInitialData() {

        ForgottenPasswordInitialData initialData = forgottenPasswordService.getInitialData();
        return ResponseEntity.status( HttpStatus.OK ).body( initialData );
    }


    /*
     * Sends an email with a forgotten password link in it
     */
    @RequestMapping( value = "/sendforgottenpasswordemail",
            method = RequestMethod.POST )
    public EmailSentResponse sendForgottenPasswordEmail(
            @RequestBody ForgottenPasswordRequest request ) {

        String domain = ThreadLocals.domainThreadLocal.get();
        String protocol = ThreadLocals.protocolThreadLocal.get();
        int serverPort = ThreadLocals.portThreadLocal.get();

        EmailSentResponse emailSentResponse =
                emailService.sendForgottenPasswordEmail(
                        request, domain, serverPort, protocol );

        return emailSentResponse;
    }


    /**
     * call this method when you want to resend an activation email
     */
    @RequestMapping( value = "/resendactivationemail",
            method = RequestMethod.POST )
    public ResponseEntity<EmailSentResponse> resendActivationEmail() {

        Long userId = loggedInCredentialsHelper.getLoggedInUser().getId();
        String domain = ThreadLocals.domainThreadLocal.get();
        Integer serverPort = ThreadLocals.portThreadLocal.get();
        String protocol = ThreadLocals.protocolThreadLocal.get();
        DomainOrganisation organisation = domainOrganisationRepository.findByDomain( domain );
        Locale locale = Locale.forLanguageTag( "en" );
        User user = userRepository.findOne( userId );

        EmailSentResponse emailSentResponse = emailService.sendActivationEmail(
                organisation, user, user.getEmail(), locale, domain, serverPort, protocol );

        return ResponseEntity.status( HttpStatus.OK ).body( emailSentResponse );
    }


    /**
     * Call this to complete activation. When the user clicks on the link in the
     * email it calls the web which in turn calls this
     */
    @RequestMapping( value = "/activate", method = RequestMethod.POST )
    public ResponseEntity<EmailActivationResponse> activateUserEmail(
            @RequestBody String emailActivationCode ) {

        EmailActivationResponse emailActivationResponse = emailService
                .activateUserEmail( emailActivationCode );

        return ResponseEntity.status( HttpStatus.OK ).body(
                emailActivationResponse );
    }


    /**
     * Call this method to get the username for the header
     */
    @RequestMapping( value = "/loggedinuserdetails/get",
            method = RequestMethod.POST )

    public ResponseEntity<LoggedInUserDetails> getLoggedInUserDetails() {

        User user = loggedInCredentialsHelper.getLoggedInUser();

        LoggedInUserDetails loggedInDetails =
                loggedInUserDetailsService.getLoggedInUserDetails( user.getId() );

        return ResponseEntity.status( HttpStatus.OK ).body( loggedInDetails );
    }


    /**
     * call this to check if the code is ok
     */
    @RequestMapping( value = "/verifyforgottenpasswordcode",
            method = RequestMethod.POST )
    public ResponseEntity<VerificationResponse> verifyForgottenPasswordResetCode(
            @RequestBody UserVerifyForgottenPasswordCodeRequest userVerifyForgottenPasswordCodeRequest ) {

        VerificationResponse verificationResponse =
                resetUserForgottenPasswordService
                        .verifyForgottenPasswordResetCode(
                                userVerifyForgottenPasswordCodeRequest );

        return ResponseEntity.status( HttpStatus.CREATED ).body(
                verificationResponse );
    }


    /**
     * Call this to save the new password
     */
    @RequestMapping( value = "/resetforgottenpassword",
            method = RequestMethod.POST )
    public ResponseEntity<SaveResponse> resetForgottenPassword(
            @RequestBody UserResetForgottenPasswordRequest userResetForgottenPasswordRequest ) {

        SaveResponse saveUserResponse = resetUserForgottenPasswordService
                .resetUserForgottenPassword(
                        userResetForgottenPasswordRequest );

        return ResponseEntity.status( HttpStatus.CREATED ).body(
                saveUserResponse );
    }

}

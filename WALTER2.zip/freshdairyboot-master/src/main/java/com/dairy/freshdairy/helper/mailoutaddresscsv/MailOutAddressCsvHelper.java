/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.mailoutaddresscsv;

/**
 * @author John Dickerson
 * @date   25 Oct 2019
 */
public interface MailOutAddressCsvHelper {

    String full_name = "full_name";
    String street_address = "street_address";
    String apartment_suite = "apartment_suite";
    String city = "city";
    String zip = "zip";
    String state = "state";

    String[] mailOutAddressHeaders =
            { full_name, street_address, apartment_suite, city, zip, state };


    String createCsv( MailoutAddressTransfer[] mailOutAddressTransfers, String quote )
            throws MailoutAddressCsvHelperException;


    MailoutAddressTransfer[] createMailoutAddressTransfers( String csvString, String quote )
            throws MailoutAddressCsvHelperException;
}

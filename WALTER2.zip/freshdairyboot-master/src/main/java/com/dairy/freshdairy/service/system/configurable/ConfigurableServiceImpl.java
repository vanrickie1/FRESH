/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.system.configurable;

import java.util.EnumMap;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.system.configurable.Configurable;
import com.dairy.freshdairy.domain.system.configurable.ConfigurableEnum;
import com.dairy.freshdairy.domain.system.configurable.ConfigurableGroup;
import com.dairy.freshdairy.domain.system.configurable.ConfigurableGroupEnum;
import com.dairy.freshdairy.repository.system.configurable.ConfigurableGroupRepository;

/**
 * @author John Dickerson
 * @date   17 Oct 2019
 */
@Service
public class ConfigurableServiceImpl implements ConfigurableService {

    private Logger logger = LoggerFactory.getLogger( ConfigurableServiceImpl.class );

    @Autowired
    private ConfigurableGroupRepository configurableGroupRepository;

    private EnumMap<ConfigurableGroupEnum,
            CacheConfigurableGroup> cacheConfigurableGroupByConfigurableGroupEnum = new EnumMap<>(
                    ConfigurableGroupEnum.class );


    private void reinitializeCacheSecurityGroup() {

        ConfigurableGroup configurableGroup =
                configurableGroupRepository.findOne( ConfigurableGroupEnum.SECURITY.getId() );

        Set<Configurable> configurables = configurableGroup.getConfigurables();
        String name;
        String value;
        ConfigurableEnum configurableEnum;
        Integer minPasswordLength = null;
        Integer maxPasswordLength = null;

        for ( Configurable configurable : configurables ) {

            name = configurable.getName();
            value = configurable.getValue();
            configurableEnum = ConfigurableEnum.valueOf( name );

            switch ( configurableEnum ) {

                case security_minPasswordLength:
                    minPasswordLength = Integer.parseInt( value );
                    break;

                case security_maxPasswordLength:
                    maxPasswordLength = Integer.parseInt( value );
                    break;

                default:
                    break;
            }
        }

        CacheSecurityGroup cacheSecurityGroup =
                new CacheSecurityGroup( minPasswordLength, maxPasswordLength );

        cacheConfigurableGroupByConfigurableGroupEnum.put(
                ConfigurableGroupEnum.SECURITY, cacheSecurityGroup );

        logger.info( "Reinitialized Security properties for the cache" );
    }


    private void reinitializeCacheImageGroup() {

        ConfigurableGroup configurableGroup =
                configurableGroupRepository.findOne( ConfigurableGroupEnum.IMAGE.getId() );

        Set<Configurable> configurables = configurableGroup.getConfigurables();
        String name;
        String value;
        ConfigurableEnum configurableEnum;
        Integer minWidthArtInPixels = null;
        Integer maxWidthArtInPixels = null;
        Integer minHeightArtInPixels = null;
        Integer maxHeightArtInPixels = null;

        for ( Configurable configurable : configurables ) {

            name = configurable.getName();
            value = configurable.getValue();

            configurableEnum = ConfigurableEnum.valueOf( name );

            switch ( configurableEnum ) {

                case image_minWidthArtInPixels:
                    minWidthArtInPixels = Integer.parseInt( value );
                    break;

                case image_maxWidthArtInPixels:
                    maxWidthArtInPixels = Integer.parseInt( value );
                    break;

                case image_minHeightArtInPixels:
                    minHeightArtInPixels = Integer.parseInt( value );
                    break;

                case image_maxHeightArtInPixels:
                    maxHeightArtInPixels = Integer.parseInt( value );
                    break;

                default:
                    break;
            }
        }

        CacheImageGroup cacheImageGroup =
                new CacheImageGroup(
                        minWidthArtInPixels, maxWidthArtInPixels,
                        minHeightArtInPixels, maxHeightArtInPixels );

        cacheConfigurableGroupByConfigurableGroupEnum.put(
                ConfigurableGroupEnum.IMAGE, cacheImageGroup );

        logger.info( "Reinitialized Image properties for the cache" );
    }


    @Override
    public CacheSecurityGroup getCacheSecurityGroup() {

        synchronized ( this ) {

            CacheSecurityGroup cacheSecurityGroup =
                    ( CacheSecurityGroup )cacheConfigurableGroupByConfigurableGroupEnum.get(
                            ConfigurableGroupEnum.SECURITY );

            return cacheSecurityGroup;
        }
    }


    @Override
    public CacheImageGroup getCacheImageGroup() {

        synchronized ( this ) {

            CacheImageGroup cacheImageGroup =
                    ( CacheImageGroup )cacheConfigurableGroupByConfigurableGroupEnum.get(
                            ConfigurableGroupEnum.IMAGE );

            return cacheImageGroup;
        }
    }


    @Override
    @Transactional
    public void reinitializeCache() {

        for ( ConfigurableGroupEnum configurableGroupEnum : ConfigurableGroupEnum.values() ) {

            reinitializeConfigurableGroup( configurableGroupEnum );
        }
    }


    @Override
    @Transactional
    public void reinitializeConfigurableGroup( ConfigurableGroupEnum configurableGroupEnum ) {

        synchronized ( this ) {

            switch ( configurableGroupEnum ) {

                case SECURITY:
                    reinitializeCacheSecurityGroup();
                    break;

                case IMAGE:
                    reinitializeCacheImageGroup();
                    break;
            }
        }
    }
}

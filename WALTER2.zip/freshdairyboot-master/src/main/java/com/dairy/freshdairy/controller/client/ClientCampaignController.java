/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.controller.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.helper.loggingin.LoggedInCredentialsHelper;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.service.client.campaign.create.ClientCreateCampaignInitialData;
import com.dairy.freshdairy.service.client.campaign.create.ClientCreateCampaignService;
import com.dairy.freshdairy.service.client.campaign.create.CreateCampaignRequest;
import com.dairy.freshdairy.service.client.campaign.edit.ClientEditCampaignInitialData;
import com.dairy.freshdairy.service.client.campaign.edit.ClientEditCampaignService;
import com.dairy.freshdairy.service.client.campaign.edit.EditCampaignRequest;
import com.dairy.freshdairy.service.client.campaign.show.ClientShowCampaignInitialData;
import com.dairy.freshdairy.service.client.campaign.show.ClientShowCampaignsService;
import com.dairy.freshdairy.service.client.campaign.show.ClientShowCustomerInitialData;
import com.dairy.freshdairy.service.client.campaign.show.ClientShowCustomerService;
import com.dairy.freshdairy.service.shared.transfer.SaveResponse;

/**
 * @author John Dickerson
 * @date 27 Oct 2019
 */
@RestController
@RequestMapping("/freshdairy/client/campaign")
public class ClientCampaignController {

	@Autowired
	private ClientCreateCampaignService clientCreateCampaignService;

	@Autowired
	private ClientEditCampaignService clientEditCampaignService;

	@Autowired
	private ClientShowCustomerService clientShowCustomerService;

	@Autowired
	private ClientShowCampaignsService ç;

	@Autowired
	private LoggedInCredentialsHelper loggedInCredentialsHelper;

	@Autowired
	private CampaignClientRepository campaignClientRepository;

	@RequestMapping(value = "/create/initialdata", method = RequestMethod.POST)
	public ResponseEntity<ClientCreateCampaignInitialData> getClientCreateCampaignInitialData() {

		ClientCreateCampaignInitialData initialData = clientCreateCampaignService.getInitialData();

		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/create/save", method = RequestMethod.POST)
	public ResponseEntity<SaveResponse> save(@RequestBody CreateCampaignRequest request) {

		Long userId = loggedInCredentialsHelper.getLoggedInUser().getId();

		CampaignClient campaignClient = campaignClientRepository.findByUserId(userId);

		SaveResponse saveResponse = clientCreateCampaignService.save(request, campaignClient.getId());

		return ResponseEntity.status(HttpStatus.OK).body(saveResponse);
	}

	@RequestMapping(value = "/edit/initialdata", method = RequestMethod.POST)
	public ResponseEntity<ClientEditCampaignInitialData> getClientEditCampaignInitialData(
			@RequestBody Long campaignId) {

		ClientEditCampaignInitialData initialData = clientEditCampaignService.getInitialData(campaignId);

		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}

	@RequestMapping(value = "/edit/save", method = RequestMethod.POST)
	public ResponseEntity<SaveResponse> save(@RequestBody EditCampaignRequest request) {

		SaveResponse saveResponse = clientEditCampaignService.save(request);
		return ResponseEntity.status(HttpStatus.OK).body(saveResponse);
	}

	@RequestMapping(value = "/show/initialdata", method = RequestMethod.POST)
	public ResponseEntity<ClientShowCustomerInitialData> getInitialData() {

		ClientShowCustomerInitialData initialData = clientShowCustomerService.getInitialData();

		return ResponseEntity.status(HttpStatus.OK).body(initialData);
	}
}

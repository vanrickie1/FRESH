/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.qrcode;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Component;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * @author John Dickerson
 * @date 30th Sept 2019
 */
@Component
public class QrCodeHelperImpl implements QrCodeHelper {

	public QrCodeHelperImpl() {

	}

	private BitMatrix getBitMatrix(int widthHeight, String stringToEncode) throws WriterException {

		Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);

		hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");

		hintMap.put(EncodeHintType.MARGIN, 1); /* default = 4 */
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

		QRCodeWriter qrCodeWriter = new QRCodeWriter();

		BitMatrix bitMatrix = qrCodeWriter.encode(stringToEncode, BarcodeFormat.QR_CODE, widthHeight, widthHeight,
				hintMap);

		return bitMatrix;
	}

	private BufferedImage createBufferedImageFromBitMatrix(BitMatrix bitMatrix) {

		int imageWidth = bitMatrix.getWidth();

		BufferedImage bufferedImage = new BufferedImage(imageWidth, imageWidth, BufferedImage.TYPE_INT_RGB);

		bufferedImage.createGraphics();
		Graphics2D graphics = (Graphics2D) bufferedImage.getGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, imageWidth, imageWidth);
		graphics.setColor(Color.BLACK);

		for (int i = 0; i < imageWidth; i++) {
			for (int j = 0; j < imageWidth; j++) {
				if (bitMatrix.get(i, j)) {
					graphics.fillRect(i, j, 1, 1);
				}
			}
		}

		return bufferedImage;
	}

	@Override
	public void generateQrCode(String stringToEncode, FileType fileType, File fileToSaveTo, int widthHeight)
			throws WriterException, IOException {

		BitMatrix bitMatrix = getBitMatrix(widthHeight, stringToEncode);

		BufferedImage bufferedImage = createBufferedImageFromBitMatrix(bitMatrix);

		ImageIO.write(bufferedImage, fileType.getFileType(), fileToSaveTo);
	}

	public static void main(String[] args) throws WriterException, IOException {

		QrCodeHelper qrCodeHelperImpl = new QrCodeHelperImpl();

		qrCodeHelperImpl.generateQrCode("http://ec2-3-84-83-205.compute-1.amazonaws.com/", FileType.PNG,
				new File("/Users/ronaldkasaija/dairyproducts.png"), 250);
	}
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.art;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;
import com.dairy.freshdairy.service.client.campaign.art.create.ClientCreateArtRequest;
import com.dairy.freshdairy.service.client.campaign.art.edit.ClientEditArtRequest;

/**
 * @author John Dickerson
 * @date   31 Oct 2019
 */
@Component
public class ArtHelperImpl implements ArtHelper {

    @Autowired
    private CampaignClientRepository campaignClientRepository;

    @Autowired
    private ArtRepository artRepository;


    public Art saveArt( Long campaignClientId, ClientCreateArtRequest request ) {

        Art art = new Art();
        CampaignClient campaignClient = campaignClientRepository.findOne( campaignClientId );
        art.setCampaignClient( campaignClient );
        art.setEditsLocked( Boolean.FALSE );
        art.setName( request.getName() );
        art.setNote( request.getNote() );
        art.setNumberEdits( 3 ); // read from config
        Art savedArt = artRepository.save( art );
        return savedArt;
    }


    @Override
    public Art saveArt( ClientEditArtRequest request ) {

        // request

        // TODO Auto-generated method stub
        return null;
    }
}

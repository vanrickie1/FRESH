/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art;

/**
 * @author John Dickerson
 * @date   29 Oct 2019
 */
public enum FileTypeEnum {

    PNG( 1l, new String[] { "PNG", "png" } );

    private Long id;
    private String[] variants;


    private FileTypeEnum( Long id, String[] variants ) {

        this.id = id;
        this.variants = variants;
    }


    public Long getId() {

        return this.id;
    }


    public String[] getVariants() {

        return this.variants;
    }
}

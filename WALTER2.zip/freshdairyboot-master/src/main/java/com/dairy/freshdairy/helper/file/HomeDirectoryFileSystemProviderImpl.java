/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.file;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dairy.freshdairy.helper.hash.HashHelper;

/**
 * @author John Dickerson
 * @date 28 Oct 2019
 */
@Component
public class HomeDirectoryFileSystemProviderImpl implements HomeDirectoryFileSystemProvider {

	@Autowired
	private HashHelper hashHelper;

	private File userHomeDir;
	private File uweeeDirectory;
	private File domainOrganisationsUweeeDirectory;

	private void makeDirectoryIfNotExist(String errorMessage, File directory) {

		if (!directory.exists()) {

			if (!directory.mkdir()) {

				throw new RuntimeException(errorMessage + ": " + directory.getAbsolutePath());
			}
		}
	}

	@Override
	public String saveFile(Long domainOrganisationId, String namespace, byte[] bytes, String orignalFileName)
			throws IOException {

		File namespaceDirectory = getCreateNamespaceDirectory(domainOrganisationId, namespace);
		String hash = hashHelper.getRandomHash();
		File fileToSave = new File(namespaceDirectory, hash + "_" + orignalFileName);
		Files.write(fileToSave.toPath(), bytes);
		return fileToSave.getAbsolutePath();
	}

	@Override
	public void deleteFile(String path) {

	}

	@Override
	public File getHomeDirectory() {

		if (userHomeDir == null) {

			userHomeDir = new File(System.getProperty(USER_HOME));
		}

		return userHomeDir;
	}

	@Override
	public File getCreateUweeeDirectory() {

		if (uweeeDirectory == null) {

			uweeeDirectory = new File(getHomeDirectory(), FRESHDAIRY);

			makeDirectoryIfNotExist("Could not create", uweeeDirectory);

		}

		return uweeeDirectory;
	}

	@Override
	public File getCreateDommainOrganisationsUweeeDirectory() {

		if (domainOrganisationsUweeeDirectory == null) {

			File uweeeDirectory = getCreateUweeeDirectory();

			domainOrganisationsUweeeDirectory = new File(uweeeDirectory, ORGANISATION);

			makeDirectoryIfNotExist("Could not create Organisatons directory", domainOrganisationsUweeeDirectory);
		}

		return domainOrganisationsUweeeDirectory;
	}

	@Override
	public File getCreateDomainOrganisationHomeDirectory(Long domainOrganisationId) {

		File domainOrganisationsDirectory = getCreateDommainOrganisationsUweeeDirectory();

		File organisationHomeDir = new File(domainOrganisationsDirectory, domainOrganisationId + "");

		if (organisationHomeDir != null) {

			makeDirectoryIfNotExist("Could not create Organisaton directory", organisationHomeDir);
		}

		return organisationHomeDir;
	}

	@Override
	public File getCreateNamespaceDirectory(Long domainOrganisationId, String namespace) {

		File domainOrganisationDirectory = getCreateDomainOrganisationHomeDirectory(domainOrganisationId);

		File namespaceDirectory = new File(domainOrganisationDirectory, namespace);

		if (namespaceDirectory != null) {

			makeDirectoryIfNotExist("Could not create Namespace directory", namespaceDirectory);
		}

		return namespaceDirectory;
	}
}

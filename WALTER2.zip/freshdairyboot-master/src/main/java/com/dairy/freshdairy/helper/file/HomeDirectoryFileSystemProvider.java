/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.file;

import java.io.File;
import java.io.IOException;

/**
 * @author John Dickerson
 * @date 29 Oct 2019
 */
public interface HomeDirectoryFileSystemProvider {

	String USER_HOME = "user.home";
	String FRESHDAIRY = "freshdairy";
	String ORGANISATION = "o";

	File getHomeDirectory();

	File getCreateUweeeDirectory();

	File getCreateDommainOrganisationsUweeeDirectory();

	File getCreateDomainOrganisationHomeDirectory(Long domainOrganisationId);

	File getCreateNamespaceDirectory(Long domainOrganisationId, String namespace);

	String saveFile(Long domainOrganisationId, String namespace, byte[] bytes, String orignalFileName)
			throws IOException;

	void deleteFile(String path);
}

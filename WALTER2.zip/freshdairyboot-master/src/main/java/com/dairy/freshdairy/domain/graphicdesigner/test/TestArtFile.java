/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "test_art_files" )
public class TestArtFile extends AbstractPersistentEntity {

    private static final long serialVersionUID = -3147570800988190486L;

    @Column( name = "path", nullable = false, unique = false, length = 1024 )
    private String path;

    @Column( name = "score", nullable = true, unique = false )
    private Integer score;

    @ManyToOne( )
    @JoinColumn( name = "fk_test_art_templates",
            foreignKey = @ForeignKey( name = "fk_testarttemplates_testartfiles" ),
            nullable = false )
    private TestArtTemplate testArtTemplate;


    public String getPath() {

        return path;
    }


    public void setPath( String path ) {

        this.path = path;
    }


    public Integer getScore() {

        return score;
    }


    public void setScore( Integer score ) {

        this.score = score;
    }


    public TestArtTemplate getTestArtTemplate() {

        return testArtTemplate;
    }


    public void setTestArtTemplate( TestArtTemplate testArtTemplate ) {

        this.testArtTemplate = testArtTemplate;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.link;

/**
 * @author John Dickerson
 * @date   12 Nov 2019
 */
public class CampaignMonthTransfer {

    private int monthIndex;


    public CampaignMonthTransfer() {

    }


    public CampaignMonthTransfer( int monthIndex ) {

        super();
        this.monthIndex = monthIndex;
    }


    public int getMonthIndex() {

        return monthIndex;
    }


    public void setMonthIndex( int monthIndex ) {

        this.monthIndex = monthIndex;
    }
}

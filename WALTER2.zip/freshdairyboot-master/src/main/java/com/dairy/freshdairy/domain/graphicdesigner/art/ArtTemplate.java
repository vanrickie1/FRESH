/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.art;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "art_templates" )
public class ArtTemplate extends AbstractPersistentEntity {

    private static final long serialVersionUID = 8709812893181050758L;

    @Column( name = "name", nullable = false, unique = false, length = 20 )
    private String name;

    @Column( name = "path", nullable = false, unique = false, length = 1024 )
    private String path;

    @ManyToOne( )
    @JoinColumn( name = "fk_arts",
            foreignKey = @ForeignKey( name = "fk_arts_arttemplates" ),
            nullable = false )
    private Art art;

    @ManyToOne( )
    @JoinColumn( name = "fk_domain_organisations",
            foreignKey = @ForeignKey( name = "fk_domainorganisations_arttemplates" ),
            nullable = false )
    private DomainOrganisation domainOrganisation;

    @ManyToOne( )
    @JoinColumn( name = "fk_art_template_types",
            foreignKey = @ForeignKey( name = "fk_arttemplatetypes_arttemplates" ),
            nullable = false )
    private ArtTemplateType artTemplateType;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getPath() {

        return path;
    }


    public void setPath( String path ) {

        this.path = path;
    }


    public Art getArt() {

        return art;
    }


    public void setArt( Art art ) {

        this.art = art;
    }


    public DomainOrganisation getDomainOrganisation() {

        return domainOrganisation;
    }


    public void setDomainOrganisation( DomainOrganisation domainOrganisation ) {

        this.domainOrganisation = domainOrganisation;
    }


    public ArtTemplateType getArtTemplateType() {

        return artTemplateType;
    }


    public void setArtTemplateType( ArtTemplateType artTemplateType ) {

        this.artTemplateType = artTemplateType;
    }
}

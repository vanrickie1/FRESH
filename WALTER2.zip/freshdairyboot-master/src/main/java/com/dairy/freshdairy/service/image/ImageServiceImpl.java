/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.image;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFile;
import com.dairy.freshdairy.domain.graphicdesigner.art.ArtFileTypeEnum;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtFileRepository;
import com.dairy.freshdairy.repository.graphicdesigner.art.ArtRepository;

/**
 * @author John Dickerson
 * @date   13 Nov 2019
 */
@Service
public class ImageServiceImpl implements ImageService {

    @Autowired
    private ArtRepository artRepository;

    @Autowired
    private ArtFileRepository artFileRepository;


    private List<MediaType> getSupportedMediaTypes() {

        List<MediaType> list = new ArrayList<MediaType>();
        list.add( MediaType.IMAGE_JPEG );
        list.add( MediaType.IMAGE_PNG );
        list.add( MediaType.IMAGE_GIF );
        return list;
    }


    private HttpHeaders addHttpHeaders( HttpHeaders httpHeaders, File imageFile,
            String filePath ) {

        httpHeaders = new HttpHeaders();

        try {

            httpHeaders.setAccessControlExposeHeaders( Collections
                    .singletonList( "Content-Disposition" ) );

            httpHeaders.set( "Content-Disposition", "attachment; filename="
                    + imageFile.getName() );

            httpHeaders.setAccept( getSupportedMediaTypes() );
            httpHeaders.setContentLength( Files.size( Paths.get( filePath ) ) );
        }
        catch ( IOException e ) {
            throw new RuntimeException(
                    "An I/O error occurred file composition", e );
        }
        return httpHeaders;
    }


    private ResponseEntity<InputStreamResource> getResponseEntity(
            String imagePath ) {

        InputStream inputStream;
        InputStreamResource inputStreamResource = null;
        HttpHeaders headers = new HttpHeaders();

        try {
            inputStream = new FileInputStream( new File( imagePath ) );
            inputStreamResource = new InputStreamResource( inputStream );
            File file = new File( imagePath );
            headers = addHttpHeaders( headers, file, imagePath );

            return new ResponseEntity<InputStreamResource>( inputStreamResource,
                    headers, HttpStatus.OK );
        }
        catch ( FileNotFoundException e ) {
            throw new RuntimeException( "The file can't be found", e );
        }
    }


    @Override
    public ResponseEntity<InputStreamResource> downloadBackArt( Long artId ) {

        ArtFile artFile =
                artFileRepository.findByArtIdAndArtFileTypeId( artId, ArtFileTypeEnum.BACK
                        .getArtFileTypeId() );

        String artPath = artFile.getPath();
        return getResponseEntity( artPath );
    }


    @Override
    public ResponseEntity<InputStreamResource> downloadFrontArt( Long artId ) {

        ArtFile artFile =
                artFileRepository.findByArtIdAndArtFileTypeId( artId, ArtFileTypeEnum.FRONT
                        .getArtFileTypeId() );

        String artPath = artFile.getPath();
        return getResponseEntity( artPath );
    }
}

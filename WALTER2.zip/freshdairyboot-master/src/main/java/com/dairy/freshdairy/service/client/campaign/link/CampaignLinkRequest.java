/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.link;

/**
 * @author John Dickerson
 * @date   12 Nov 2019
 */
public class CampaignLinkRequest {

    private Long campaignId;
    private CampaignArtRequest[] campaignArtRequests;
    private Long campaignListId;


    public CampaignLinkRequest() {

    }


    public CampaignLinkRequest( Long campaignId, CampaignArtRequest[] campaignArtRequests,
            Long campaignListId ) {

        super();
        this.campaignId = campaignId;
        this.campaignArtRequests = campaignArtRequests;
        this.campaignListId = campaignListId;
    }


    public Long getCampaignId() {

        return campaignId;
    }


    public void setCampaignId( Long campaignId ) {

        this.campaignId = campaignId;
    }


    public CampaignArtRequest[] getCampaignArtRequests() {

        return campaignArtRequests;
    }


    public void setCampaignArtRequests( CampaignArtRequest[] campaignArtRequests ) {

        this.campaignArtRequests = campaignArtRequests;
    }


    public Long getCampaignListId() {

        return campaignListId;
    }


    public void setCampaignListId( Long campaignListId ) {

        this.campaignListId = campaignListId;
    }
}

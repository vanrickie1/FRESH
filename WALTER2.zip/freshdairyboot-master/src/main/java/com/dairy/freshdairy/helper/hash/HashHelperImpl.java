/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.hash;

import java.security.SecureRandom;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
@Component
public class HashHelperImpl implements HashHelper {

    private SecureRandom secureRandom = new SecureRandom();


    @Override
    public String getPasswordHashWithBcrypt( String password ) {

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String hashedPassword = passwordEncoder.encode( password );
        return hashedPassword;
    }


    @Override
    public String getRandomHash() {

        return secureRandom.nextLong() + "";
    }


    public static void main( String[] args ) {

        HashHelper hashHelper = new HashHelperImpl();
        String password = hashHelper.getPasswordHashWithBcrypt( "bling" );
        System.out.println( password );
    }
}

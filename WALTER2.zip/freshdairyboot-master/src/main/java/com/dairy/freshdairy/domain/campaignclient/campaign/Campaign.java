/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.campaignclient.campaign;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "campaign" )
public class Campaign extends AbstractPersistentEntity {

    private static final long serialVersionUID = -5136634434213402185L;

    @Column( name = "name", nullable = false, unique = true, length = 30 )
    private String name;

    @Column( name = "activated", nullable = false, columnDefinition = "boolean default false" )
    private Boolean activated;

    @ManyToOne( )
    @JoinColumn( name = "fk_campaign_clients",
            foreignKey = @ForeignKey( name = "fk_campaignclients_campaigns" ),
            nullable = false )
    private CampaignClient campaignClient;

    @ManyToOne( )
    @JoinColumn( name = "fk_campaign_lists",
            foreignKey = @ForeignKey( name = "fk_campaign_lists_campaigns" ),
            nullable = true )
    private CampaignList campaignList;

    @ManyToOne( )
    @JoinColumn( name = "fk_campaign_frequency_types",
            foreignKey = @ForeignKey( name = "fk_campaignfrequencytypes_campaigns" ),
            nullable = false )
    private CampaignFrequencyType campaignFrequencyType;

    @OneToMany( mappedBy = "campaign" )
    private Set<CampaignMonth> campaignMonths;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public CampaignClient getCampaignClient() {

        return campaignClient;
    }


    public void setCampaignClient( CampaignClient campaignClient ) {

        this.campaignClient = campaignClient;
    }


    public Boolean getActivated() {

        return activated;
    }


    public void setActivated( Boolean activated ) {

        this.activated = activated;
    }


    public CampaignList getCampaignList() {

        return campaignList;
    }


    public void setCampaignList( CampaignList campaignList ) {

        this.campaignList = campaignList;
    }


    public CampaignFrequencyType getCampaignFrequencyType() {

        return campaignFrequencyType;
    }


    public void setCampaignFrequencyType(
            CampaignFrequencyType campaignFrequencyType ) {

        this.campaignFrequencyType = campaignFrequencyType;
    }


    public Set<CampaignMonth> getCampaignMonths() {

        return campaignMonths;
    }


    public void setCampaignMonths( Set<CampaignMonth> campaignMonths ) {

        this.campaignMonths = campaignMonths;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.show;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dairy.freshdairy.domain.campaignclient.campaign.Campaign;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignClient;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignFrequencyType;
import com.dairy.freshdairy.domain.campaignclient.campaign.CampaignMonth;
import com.dairy.freshdairy.domain.graphicdesigner.art.Art;
import com.dairy.freshdairy.repository.campaignclient.campaign.CampaignClientRepository;

/**
 * @author John Dickerson
 * @date   27 Oct 2019
 */
@Service
public class ClientShowCampaignServiceImpl implements ClientShowCampaignsService {

    @Autowired
    private CampaignClientRepository campaignClientRepository;


    private Boolean isConfigured( CampaignMonth campaignMonth ) {

        Boolean configured = false;
        Art art = campaignMonth.getArt();

        if ( art != null ) {

            configured = true;
        }

        return configured;
    }


    private Boolean campaignMonthsConfigured( Set<CampaignMonth> campaignMonths ) {

        Boolean configured = true;

        for ( CampaignMonth campaignMonth : campaignMonths ) {

            if ( isConfigured( campaignMonth ) ) {

                configured = false;
                break;
            }
        }

        return configured;
    }


    private Boolean getCampaignConfigured( Campaign campaign ) {

        Boolean configured = false;

        if ( campaign.getCampaignList() != null ) {

            Set<CampaignMonth> campaignMonths = campaign.getCampaignMonths();

            if ( campaignMonthsConfigured( campaignMonths ) ) {

                configured = true;
            }
        }

        return configured;
    }


    private Boolean getCampaignHasList( Campaign campaign ) {

        return campaign.getCampaignList() != null;
    }


    private Integer getNumberArts( Campaign campaign ) {

        Set<CampaignMonth> campaignMonths = campaign.getCampaignMonths();
        Integer numberArts = 0;

        for ( CampaignMonth campaignMonth : campaignMonths ) {

            if ( campaignMonth.getArt() != null ) {

                numberArts++;
            }
        }

        return numberArts;
    }


    private String getCampaignFrequencyType( Campaign campaign ) {

        CampaignFrequencyType campaignFrequencyType = campaign.getCampaignFrequencyType();
        return campaignFrequencyType.getName();
    }


    private CampaignTransfer createCampaignTransfer( Campaign campaign ) {

        Long campaignId = campaign.getId();
        String campaignName = campaign.getName();
        Boolean campaignActivated = campaign.getActivated();
        Boolean campaignConfigured = getCampaignConfigured( campaign );
        Boolean hasList = getCampaignHasList( campaign );
        Integer numberArt = getNumberArts( campaign );
        String campaignType = getCampaignFrequencyType( campaign );

        CampaignTransfer campaignTransfer =
                new CampaignTransfer( campaignId, campaignName, campaignActivated,
                        campaignConfigured, hasList, numberArt, campaignType );

        return campaignTransfer;

    }


    private CampaignTransfer[] createCampaignTransfers( Set<Campaign> campaigns ) {

        List<CampaignTransfer> campaignTransfers = new ArrayList<>();

        for ( Campaign campaign : campaigns ) {

            campaignTransfers.add( createCampaignTransfer( campaign ) );
        }

        return campaignTransfers.toArray( new CampaignTransfer[campaignTransfers.size()] );
    }


    private CampaignTransfer[] createCampaignTransfers( Long campaignClientId ) {

        CampaignClient campaignClient = campaignClientRepository.findOne( campaignClientId );
        Set<Campaign> campaigns = campaignClient.getCampaigns();
        CampaignTransfer[] campaignTransfers = createCampaignTransfers( campaigns );
        return campaignTransfers;
    }


    @Override
    public ClientShowCampaignInitialData getInitialData( Long campaignClientId ) {

        CampaignTransfer[] campaignTransfers = createCampaignTransfers( campaignClientId );

        ClientShowCampaignInitialData initialData =
                new ClientShowCampaignInitialData( campaignTransfers );

        return initialData;
    }
}

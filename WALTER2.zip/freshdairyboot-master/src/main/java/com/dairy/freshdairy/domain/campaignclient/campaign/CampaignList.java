/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.campaignclient.campaign;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "campaign_lists" )
public class CampaignList extends AbstractPersistentEntity {

    private static final long serialVersionUID = 4482700036756369415L;

    @Column( name = "name", nullable = false, unique = false, length = 30 )
    private String name;

    @Column( name = "description", nullable = true, unique = false, length = 200 )
    private String description;

    @ManyToOne( )
    @JoinColumn( name = "fk_campaign_clients",
            foreignKey = @ForeignKey( name = "fk_campaignclients_caampaignlists" ),
            nullable = false )
    private CampaignClient campaignClient;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getDescription() {

        return description;
    }


    public void setDescription( String description ) {

        this.description = description;
    }


    public CampaignClient getCampaignClient() {

        return campaignClient;
    }


    public void setCampaignClient( CampaignClient campaignClient ) {

        this.campaignClient = campaignClient;
    }
}

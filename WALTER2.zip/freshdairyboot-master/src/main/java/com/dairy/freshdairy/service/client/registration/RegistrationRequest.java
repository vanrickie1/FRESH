/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.registration;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public class RegistrationRequest {

    private String firstName;
    private String lastName;
    private String companyName;
    private String streetAddress;
    private String apartmentSuite;
    private String city;
    private Long stateId;
    private String zip;
    private String telephone;
    private String email;
    private String password;


    public RegistrationRequest() {

    }


    public RegistrationRequest( String firstName, String lastName,
            String companyName, String streetAddress, String apartmentSuite,
            String city, Long stateId, String zip, String telephone,
            String email, String password ) {

        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.companyName = companyName;
        this.streetAddress = streetAddress;
        this.apartmentSuite = apartmentSuite;
        this.city = city;
        this.stateId = stateId;
        this.zip = zip;
        this.telephone = telephone;
        this.email = email;
        this.password = password;
    }


    public String getFirstName() {

        return firstName;
    }


    public void setFirstName( String firstName ) {

        this.firstName = firstName;
    }


    public String getLastName() {

        return lastName;
    }


    public void setLastName( String lastName ) {

        this.lastName = lastName;
    }


    public String getCompanyName() {

        return companyName;
    }


    public void setCompanyName( String companyName ) {

        this.companyName = companyName;
    }


    public String getStreetAddress() {

        return streetAddress;
    }


    public void setStreetAddress( String streetAddress ) {

        this.streetAddress = streetAddress;
    }


    public String getApartmentSuite() {

        return apartmentSuite;
    }


    public void setApartmentSuite( String apartmentSuite ) {

        this.apartmentSuite = apartmentSuite;
    }


    public String getCity() {

        return city;
    }


    public void setCity( String city ) {

        this.city = city;
    }


    public Long getStateId() {

        return stateId;
    }


    public void setStateId( Long stateId ) {

        this.stateId = stateId;
    }


    public String getZip() {

        return zip;
    }


    public void setZip( String zip ) {

        this.zip = zip;
    }


    public String getTelephone() {

        return telephone;
    }


    public void setTelephone( String telephone ) {

        this.telephone = telephone;
    }


    public String getEmail() {

        return email;
    }


    public void setEmail( String email ) {

        this.email = email;
    }


    public String getPassword() {

        return password;
    }


    public void setPassword( String password ) {

        this.password = password;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.create;

import com.dairy.freshdairy.service.client.campaign.art.FileTypeTransfer;

/**
 * @author John Dickerson
 * @date   29 Oct 2019
 */
public class ClientCreateArtInitialData {

    private FileTypeTransfer[] fileTypeTransfers;
    private Integer allowedWidthPixels;
    private Integer allowedHeightPixels;


    public ClientCreateArtInitialData() {

    }


    public ClientCreateArtInitialData( FileTypeTransfer[] fileTypeTransfers,
            Integer allowedWidthPixels, Integer allowedHeightPixels ) {

        super();
        this.fileTypeTransfers = fileTypeTransfers;
        this.allowedWidthPixels = allowedWidthPixels;
        this.allowedHeightPixels = allowedHeightPixels;
    }


    public FileTypeTransfer[] getFileTypeTransfers() {

        return fileTypeTransfers;
    }


    public void setFileTypeTransfers( FileTypeTransfer[] fileTypeTransfers ) {

        this.fileTypeTransfers = fileTypeTransfers;
    }


    public Integer getAllowedWidthPixels() {

        return allowedWidthPixels;
    }


    public void setAllowedWidthPixels( Integer allowedWidthPixels ) {

        this.allowedWidthPixels = allowedWidthPixels;
    }


    public Integer getAllowedHeightPixels() {

        return allowedHeightPixels;
    }


    public void setAllowedHeightPixels( Integer allowedHeightPixels ) {

        this.allowedHeightPixels = allowedHeightPixels;
    }
}

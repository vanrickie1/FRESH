/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.email;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public class EmailSentResponse {

    private boolean emailSent;
    private String error;


    public EmailSentResponse( boolean emailSent, String error ) {

        super();
        this.emailSent = emailSent;
        this.error = error;
    }


    public boolean isEmailSent() {

        return emailSent;
    }


    public void setEmailSent( boolean emailSent ) {

        this.emailSent = emailSent;
    }


    public String getError() {

        return error;
    }


    public void setError( String error ) {

        this.error = error;
    }
}

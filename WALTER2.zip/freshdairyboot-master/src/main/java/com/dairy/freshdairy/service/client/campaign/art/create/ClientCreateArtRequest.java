/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.campaign.art.create;

/**
 * @author John Dickerson
 * @date   28 Oct 2019
 */
public class ClientCreateArtRequest {

    private String name;
    private String note;


    public ClientCreateArtRequest() {

    }


    public ClientCreateArtRequest( String name, String note ) {

        super();
        this.name = name;
        this.note = note;
    }


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getNote() {

        return note;
    }


    public void setNote( String note ) {

        this.note = note;
    }
}

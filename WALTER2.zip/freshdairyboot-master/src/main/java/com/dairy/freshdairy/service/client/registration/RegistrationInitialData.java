/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.registration;

import com.dairy.freshdairy.service.shared.transfer.StateTransfer;

/**
 * @author John Dickerson
 * @date   15 Oct 2019
 */
public class RegistrationInitialData {

    private StateTransfer[] stateTransfers;
    private Integer minPasswordLength;
    private Integer maxPasswordLength;


    public RegistrationInitialData() {

    }


    /**
     * @param stateTransfers
     */
    public RegistrationInitialData( StateTransfer[] stateTransfers, Integer minPasswordLength,
            Integer maxPasswordLength ) {

        super();
        this.stateTransfers = stateTransfers;
        this.minPasswordLength = minPasswordLength;
        this.maxPasswordLength = maxPasswordLength;
    }


    public StateTransfer[] getStateTransfers() {

        return stateTransfers;
    }


    public void setStateTransfers( StateTransfer[] stateTransfers ) {

        this.stateTransfers = stateTransfers;
    }


    public Integer getMinPasswordLength() {

        return minPasswordLength;
    }


    public void setMinPasswordLength( Integer minPasswordLength ) {

        this.minPasswordLength = minPasswordLength;
    }


    public Integer getMaxPasswordLength() {

        return maxPasswordLength;
    }


    public void setMaxPasswordLength( Integer maxPasswordLength ) {

        this.maxPasswordLength = maxPasswordLength;
    }
}

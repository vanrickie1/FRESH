/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.service.client.registration;

/**
 * @author John Dickerson
 * @date 15 Oct 2019
 */
public class DrawRequest {

	private String firstName;
	private String lastName;
	private String outlet;
	private String location;
	private String phoneNumber;
	private String receiptNumber;
	private Long artId;

	public DrawRequest() {

	}

	public DrawRequest(String firstName, String lastName, String outlet, String location, String phoneNumber,
			String receiptNumber, Long artId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.outlet = outlet;
		this.location = location;
		this.phoneNumber = phoneNumber;
		this.receiptNumber = receiptNumber;
		this.artId = artId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOutlet() {
		return outlet;
	}

	public void setOutlet(String outlet) {
		this.outlet = outlet;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getReceiptNumber() {
		return receiptNumber;
	}

	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}

	public Long getArtId() {
		return artId;
	}

	public void setArtId(Long artId) {
		this.artId = artId;
	}
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.helper.mailoutaddresscsv;

/**
 * @author John Dickerson
 * @date   25 Oct 2019
 */
public class MailoutAddressTransfer {

    private String fullName;
    private String streetAddress;
    private String apartmentSuite;
    private String city;
    private String zip;
    private String state;


    public MailoutAddressTransfer() {

    }


    public MailoutAddressTransfer( String fullName, String streetAddress, String apartmentSuite,
            String city, String zip, String state ) {

        super();
        this.fullName = fullName;
        this.streetAddress = streetAddress;
        this.apartmentSuite = apartmentSuite;
        this.city = city;
        this.zip = zip;
        this.state = state;
    }


    public String getFullName() {

        return fullName;
    }


    public void setFullName( String fullName ) {

        this.fullName = fullName;
    }


    public String getStreetAddress() {

        return streetAddress;
    }


    public void setStreetAddress( String streetAddress ) {

        this.streetAddress = streetAddress;
    }


    public String getApartmentSuite() {

        return apartmentSuite;
    }


    public void setApartmentSuite( String apartmentSuite ) {

        this.apartmentSuite = apartmentSuite;
    }


    public String getCity() {

        return city;
    }


    public void setCity( String city ) {

        this.city = city;
    }


    public String getZip() {

        return zip;
    }


    public void setZip( String zip ) {

        this.zip = zip;
    }


    public String getState() {

        return state;
    }


    public void setState( String state ) {

        this.state = state;
    }


    @Override
    public int hashCode() {

        final int prime = 31;
        int result = 1;
        result = prime * result + ( ( apartmentSuite == null ) ? 0 : apartmentSuite.hashCode() );
        result = prime * result + ( ( city == null ) ? 0 : city.hashCode() );
        result = prime * result + ( ( fullName == null ) ? 0 : fullName.hashCode() );
        result = prime * result + ( ( state == null ) ? 0 : state.hashCode() );
        result = prime * result + ( ( streetAddress == null ) ? 0 : streetAddress.hashCode() );
        result = prime * result + ( ( zip == null ) ? 0 : zip.hashCode() );
        return result;
    }


    @Override
    public boolean equals( Object obj ) {

        if ( this == obj )
            return true;
        if ( obj == null )
            return false;
        if ( getClass() != obj.getClass() )
            return false;
        MailoutAddressTransfer other = ( MailoutAddressTransfer )obj;
        if ( apartmentSuite == null ) {
            if ( other.apartmentSuite != null )
                return false;
        }
        else if ( !apartmentSuite.equals( other.apartmentSuite ) )
            return false;
        if ( city == null ) {
            if ( other.city != null )
                return false;
        }
        else if ( !city.equals( other.city ) )
            return false;
        if ( fullName == null ) {
            if ( other.fullName != null )
                return false;
        }
        else if ( !fullName.equals( other.fullName ) )
            return false;
        if ( state == null ) {
            if ( other.state != null )
                return false;
        }
        else if ( !state.equals( other.state ) )
            return false;
        if ( streetAddress == null ) {
            if ( other.streetAddress != null )
                return false;
        }
        else if ( !streetAddress.equals( other.streetAddress ) )
            return false;
        if ( zip == null ) {
            if ( other.zip != null )
                return false;
        }
        else if ( !zip.equals( other.zip ) )
            return false;
        return true;
    }
}

/*
    =======================================================================================
    This code is part of the Javaspeak project.

    Javaspeak is software owned by Javaspeak. Inc.

    The Javaspeak software has a proprietary license. Please look at or request
    javaspeak_license.txt for further details.

    Copyright (C) 2019 Javaspeak. Inc.

    Email:  reenez.den@gmail.com

    ========================================================================================
    Author : Ronald Kasaija
    ========================================================================================
*/
package com.dairy.freshdairy.domain.graphicdesigner.test;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.dairy.freshdairy.domain.AbstractPersistentEntity;
import com.dairy.freshdairy.domain.domain.DomainOrganisation;

/**
 * @author John Dickerson
 * @date   6 Oct 2019
 */
@Entity
@Table( name = "recruitment_runs" )
public class RecruitmentRun extends AbstractPersistentEntity {

    private static final long serialVersionUID = -6862230948878078407L;

    @Column( name = "name", nullable = false, unique = false, length = 30 )
    private String name;

    @Column( name = "description", nullable = false, unique = false, length = 500 )
    private String description;

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "start", nullable = false, unique = false )
    private Date start;

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "end", nullable = false, unique = false )
    private Date end;

    @OneToOne( )
    @JoinColumn( name = "fk_domain_organisations",
            foreignKey = @ForeignKey( name = "fk_domainorganisations_recruitmentruns" ),
            nullable = false )
    private DomainOrganisation domainOrganisation;


    public String getName() {

        return name;
    }


    public void setName( String name ) {

        this.name = name;
    }


    public String getDescription() {

        return description;
    }


    public void setDescription( String description ) {

        this.description = description;
    }


    public Date getStart() {

        return start;
    }


    public void setStart( Date start ) {

        this.start = start;
    }


    public Date getEnd() {

        return end;
    }


    public void setEnd( Date end ) {

        this.end = end;
    }


    public DomainOrganisation getDomainOrganisation() {

        return domainOrganisation;
    }


    public void setDomainOrganisation( DomainOrganisation domainOrganisation ) {

        this.domainOrganisation = domainOrganisation;
    }
}

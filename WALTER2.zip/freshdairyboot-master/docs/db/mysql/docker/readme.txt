====================================================================================================
~/workspaces/uweee/uweee_one_boot/docs/db/mysql/docker/readme.txt

Author: John Dickerson
Date:   30th Sept 2019
====================================================================================================

Install Docker if you do not have it already:

    https://www.docker.com/products/docker-desktop
    
====================================================================================================

To Download the docker image of mysql:

    https://hub.docker.com/_/percona

    docker pull percona
    
====================================================================================================
    
For admin of mysql db:
    
    https://dev.mysql.com/downloads/workbench/
    
====================================================================================================

Start mysql db:

    -- docker run --name some-percona -e MYSQL_ROOT_PASSWORD=my-secret-pw -d percona:tag
    -- docker run --name uweee -e MYSQL_ROOT_PASSWORD=uweee -d percona:latest
    -- docker run --name percona_mysql_8 -p 3306:3306  -e MYSQL_ROOT_PASSWORD=root -d percona:8.0.16-7-centos
    
    docker run -d \
  --name ps_8 \
  -e MYSQL_ROOT_PASSWORD=root \
  -e MYSQL_ROOT_HOST=% \
  -p 3306:3306 \
  percona/percona-server:8.0  

====================================================================================================

Stop mysql db:

    docker ps
    docker stop 091a1c93eb7b
    
Stop all docker containers:

   docker stop $(docker ps -a -q)
  
====================================================================================================

To get a list of containers:

    docker container ls -a
    
====================================================================================================

To remove a container:

    docker container rm 091a1c93eb7b

====================================================================================================

Start client and connect to db:

    -- docker run -it --network some-network --rm percona mysql -huweee -uroot -p
    
    docker run -it --network <docker network> --rm percona mysql -hpercona_mysql_8 -uroot -p
    
====================================================================================================
    
Connecting via mysql

    mysql -h 127.0.0.1 -tcp -uroot -p
    enter root
    show databases;
    use uweee;
    
=====

$ telnet 127.0.0.1 3306

=====

docker exec -it ps_8 /bin/bash

mysql -h127.0.0.1  -uroot -p -tcp

create database uweeeDevDB;

CREATE USER 'uweee'@'%'  IDENTIFIED BY 'uweee'; 
GRANT ALL PRIVILEGES ON uweeeDevDB.* TO 'uweee'@'%';
FLUSH PRIVILEGES;





    
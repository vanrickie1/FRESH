================================================================================
~/workspaces/uweee/uweee_one_boot/docs/uml/star/README.txt
================================================================================
Author: JD
Date:   27/09/2019
================================================================================

Star UML is a free software that you can view the uml entity / DB hybrid 
diagram.

The diagram is hybrid.  It shows the relationships between entities in terms
of:

    One to One
    Many to One
    One to Many
    Many to Many

The DB hybrid aspect is that it also shows:

    Which side of the relationship has the FK or if there is a mapping table
    
    The fields of the entity and whether they are mandatory (m) or optional (o)

    It shows the max length of fields

    e.g   +organisationName: string m 30

The entities are in camel case.

To translation and entity to a  DB table name:

    DomainOrganisation becomes domain_organisation

The same is with the fields of an entity:

    organisationName becomes organisation_name

Each entity does not include the id field - all entites have implicitly an 
id field.

When there is a mapping table between two entities the translation to a DB 
mapping table name is as follows:

    SomeTable  OtherTable   =>   sometable_othertable

To download star uml go to:

    http://staruml.io/download


PLEASE NOTE:
===========

We have the concept of a UML batton.  It is a bit like running a Relay 
race.  In order to edit the entity diagram you have to request the 
UML batton from who ever had it first.

After you have made your edits you do not give the batton back.

You keep it until someone asks it off you.

This measure is enforced to prevent corrupting the diagram with a
git merge.

In other words - if you do not have the batton do not push save.

If you save by mistake you can go to the command line and type the 
following to revert the edits:

    git checkout fileName

fileName is the star uml file.




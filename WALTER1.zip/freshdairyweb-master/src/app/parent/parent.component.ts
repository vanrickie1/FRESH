import { Component, OnInit, OnDestroy, ViewChild, HostListener, ChangeDetectorRef } from '@angular/core';
import { SidenavMenuService } from '../header/sidenav-menu/sidenav-menu.service';
import { Router } from '@angular/router';
import { UserService } from '../services/user/user.service';
import { TranslateService } from '@ngx-translate/core';
import { ConfigService } from '../services/config/config.service';
import { ParentInitialData } from './parent-request-response';
import { Settings, AppSettings } from '../app.settings';
import { ParentService } from './parent.service';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss'],
  providers: [SidenavMenuService]
})
export class ParentComponent implements OnInit, OnDestroy {

  langChangeSubscription: any;
  imagePath: any;
  imageAltOrTitle: string;
  error: string;
  organisationName: string;
  loggedInUsername: string;
  organisationDefaultLocale: string;
  initialData: ParentInitialData;
  loading = false;
  bufferSize = 50;
  public showBackToTop = false;
  public sidenavMenuItems: Array<any>;
  public settings: Settings;
  @ViewChild('sidenav', { static: false }) sidenav: any;

  constructor(
    public appSettings: AppSettings,
    public sidenavMenuService: SidenavMenuService,
    private loginService: LoginService,
    public router: Router,
    private userService: UserService,
    public translateService: TranslateService,
    public configService: ConfigService,
    public parentService: ParentService,
    private cdr: ChangeDetectorRef
  ) {
    this.settings = this.appSettings.settings;
  }

  ngOnInit() {
    this.loggedInUsername = this.loginService.firstName;
    this.cdr.detectChanges();
  }

  public logout() {
    localStorage.clear();
    this.userService.loggedInUsername = null;
    this.router.navigate(['/client/login']);
  }

  hasPermission(permission: string): boolean {
    return this.userService.hasPermission(permission);
  }

  public changeTheme(theme) {
    this.settings.theme = theme;
  }

  public stopClickPropagate(event: any) {
    event.stopPropagation();
    event.preventDefault();
  }

  public scrollToTop() {
    const scrollDuration = 200;
    const scrollStep = -window.pageYOffset / (scrollDuration / 20);
    const scrollInterval = setInterval(() => {
      if (window.pageYOffset !== 0) {
        window.scrollBy(0, scrollStep);
      } else {
        clearInterval(scrollInterval);
      }
    }, 10);
    if (window.innerWidth <= 768) {
      setTimeout(() => { window.scrollTo(0, 0); });
    }
  }
  @HostListener('window:scroll', ['$event'])
  onWindowScroll($event) {
    ($event.target.documentElement.scrollTop > 300) ? this.showBackToTop = true : this.showBackToTop = false;
  }

  public closeSubMenus() {
    if (window.innerWidth < 960) {
      this.sidenavMenuService.closeAllSubMenus();
    }
  }

  ngOnDestroy() {
    this.langChangeSubscription.unsubscribe();
  }
}

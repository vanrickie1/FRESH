
export class ParentInitialData {

    public constructor(
        public organisationName: string) {

    }
}

export class ImageTransfer {

    public constructor(
        public id: number,
        public name: string,
        public fileName: string,
        public description: string,
        public showNameIfPossible: boolean,
        public showDescriptionIfPossible: boolean) {
    }
}

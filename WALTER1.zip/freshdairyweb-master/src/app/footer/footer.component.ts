import { Component, OnInit } from '@angular/core';
import { FooterService } from './footer.service';
import { FooterInitialData } from './footer-request-response';
import { TranslateService } from '@ngx-translate/core';
import { ConfigService } from '../services/config/config.service';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  lat = 40.678178;
  lng = -73.944158;
  zoom = 12;
  organisationName: string;
  address: string;
  contactEmail: string;
  initialData: FooterInitialData;

  constructor(
    private footerService: FooterService,
    public translateService: TranslateService,
    public configService: ConfigService
  ) {
  }

  ngOnInit() {
    // this.getInitialData();
  }

  private getInitialData(): void {
    this.footerService.getInitialData().subscribe(
      (initialData: FooterInitialData) => {
        this.initialData = initialData;
        this.organisationName = initialData.organisationName;
      }
    );
  }
}

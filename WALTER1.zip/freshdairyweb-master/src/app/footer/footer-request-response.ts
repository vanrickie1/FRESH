
export class FooterInitialData {
  public constructor(
    public organisationName: string,
    public address: string,
    public contactNumber: string,
    public contactEmail: string
  ) {

  }
}


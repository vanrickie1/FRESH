import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { FooterInitialData } from './footer-request-response';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class FooterService {

  GET_FOOTER_INITIAL_DATA_URL = '/freshdairy/footer/getinitialdata';

  constructor(
    private http: HttpClient) {

  }

  getInitialData(): Observable<FooterInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(this.GET_FOOTER_INITIAL_DATA_URL, httpOptions).pipe(map(
      (response: FooterInitialData) => {
        return response;
      }
    ));
  }
}

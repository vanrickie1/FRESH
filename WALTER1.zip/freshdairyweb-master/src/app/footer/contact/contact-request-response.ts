export class ContactInitialData {

  public constructor(
    public email: string,
    public phone: string,
    public address: AddressTransfer
  ) {

  }
}

export class AddressTransfer {

  public constructor(
    public firstLine: string,
    public secondLine: string,
    public townOrCity: string,
    public postCode: string,
    public country: string) {
  }
}

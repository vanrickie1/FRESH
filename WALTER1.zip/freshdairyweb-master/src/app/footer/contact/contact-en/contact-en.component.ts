import { Component, OnInit } from '@angular/core';
import { ContactInitialData } from '../contact-request-response';
import { ContactService } from '../contact.service';
import { ConfigService } from '../../../services/config/config.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-contact-en',
  templateUrl: './contact-en.component.html',
  styleUrls: ['./contact-en.component.css']
})
export class ContactEnComponent implements OnInit {

  public initialData: ContactInitialData;
  debug: boolean = environment.debug;

  constructor(
    public configService: ConfigService,
    public service: ContactService
  ) {

  }

  ngOnInit() {
    // this.getInitialData();
  }

  private getInitialData(): void {
    this.service.getInitialData().subscribe(
      (initialData: ContactInitialData) => {
        this.initialData = initialData;
      }
    );
  }
}

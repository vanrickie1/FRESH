import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ContactInitialData } from './contact-request-response';
import { map } from 'rxjs/operators/map';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  CONTACT_GET_INITIAL_DATA_URL = '/freshdairy/contact/getinitialdata';

  constructor(private http: HttpClient) {
  }

  getInitialData(): Observable<ContactInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(this.CONTACT_GET_INITIAL_DATA_URL, httpOptions).pipe(map(
      (response: ContactInitialData) => {
        return response;
      }
    ));
  }
}

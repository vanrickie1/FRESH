import { Component, OnInit } from '@angular/core';
import { ContactService } from './contact.service';
import { ContactInitialData } from './contact-request-response';
import { ConfigService } from '../../services/config/config.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  public initialData: ContactInitialData;

  constructor(
    public configService: ConfigService,
    public service: ContactService
  ) {

  }

  ngOnInit() {
    // this.getInitialData();
  }

  private getInitialData(): void {
    this.service.getInitialData().subscribe(
      (initialData: ContactInitialData) => {
        this.initialData = initialData;
      }
    );
  }
}

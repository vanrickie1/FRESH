import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acceptable-use-policy',
  templateUrl: './acceptable-use-policy.component.html',
  styleUrls: ['./acceptable-use-policy.component.css']
})
export class AcceptableUsePolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

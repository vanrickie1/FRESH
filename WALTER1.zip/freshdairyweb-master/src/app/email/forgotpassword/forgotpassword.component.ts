import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { EmailService } from '../email.service';
import { ForgottenPasswordRequest, EmailSentResponse } from './forgotpassword-request-response';
import { ForgotpasswordService } from './forgotpassword.service';
import { TranslateService } from '@ngx-translate/core';
import { ParentService } from 'src/app/parent/parent.service';
import { Router } from '@angular/router';
import { AppErrorStateMatcherComponent } from 'src/app/validators/app-error-state-matcher/app-error-state-matcher.component';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})

export class ForgotpasswordComponent implements OnInit {

  public sitekey = '6Lc133sUAAAAAB-0ea4zIuxM1gHFR7qh6DyXuWfa';

  errorForgottenPassword: string;
  emailHasBeenSent: boolean;
  cannotFindEmail: boolean;
  unexpectedError: boolean;
  unexpectedErrorStr: string;
  forgottenPasswordRequest: ForgottenPasswordRequest;
  forgottenPasswordFormGroup: FormGroup;
  lang: string = this.translateService.currentLang;
  matcher = new AppErrorStateMatcherComponent();
  emailPattern = '[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}';

  constructor(
    private parentService: ParentService,
    private forgotpasswordService: ForgotpasswordService,
    private router: Router,
    private formBuilder: FormBuilder,
    private translateService: TranslateService) {
    this.parentService.hidePublicHeader = true;
    this.parentService.hidePrivateHeader = true;
    this.createFormGroup();
  }

  createFormGroup() {
    this.forgottenPasswordFormGroup = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.pattern(this.emailPattern)]],
    });
  }

  ngOnInit() {

  }


  showEmailHasBeenSent(response) {
    this.emailHasBeenSent = true;
  }

  showCannotFindEmail(response) {
    this.cannotFindEmail = true;
  }

  ShowUnexpectedError(error) {
    this.unexpectedError = true;
    this.unexpectedErrorStr = error.string;
  }

  login() {
    this.router.navigate(['/client/login']);
  }

  onSubmitEmail() {
    const email = this.forgottenPasswordFormGroup.controls['email'].value;
    const forgottenPasswordRequest = new ForgottenPasswordRequest(email);

    this.forgotpasswordService.sendForgottenPasswordEmail(forgottenPasswordRequest).subscribe(
      (response: EmailSentResponse) => {
        if (response.emailSent) {
          this.showEmailHasBeenSent(response);
        } else {
          this.showCannotFindEmail(response);
        }
      },
      (error: Error) => {
        this.ShowUnexpectedError(error);
      }
    );
  }
}

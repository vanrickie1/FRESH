export class ValidateEmailRequest {

    public constructor(public email: string) {

    }
}

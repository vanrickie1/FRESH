import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { NgForm, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { EmailService } from '../email.service';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import {
  UserResetForgottenPasswordRequest,
  VerificationResponse,
  VerifyForgottenPasswordResetCodeRequest,
  SaveResponse,
  ForgottenPasswordInitialData
} from './resetforgottenpassword-request-response';
import { ResetforgottenpasswordService } from './resetforgottenpassword.service';
import { PasswordValidation } from 'src/app/directive/password-validator';
import { AppErrorStateMatcherComponent } from 'src/app/validators/app-error-state-matcher/app-error-state-matcher.component';
import { ParentService } from 'src/app/parent/parent.service';

@Component({
  selector: 'app-resetforgottenpassword',
  templateUrl: './resetforgottenpassword.component.html',
  styleUrls: ['./resetforgottenpassword.component.css']
})

export class ResetforgottenpasswordComponent implements OnInit {

  initialData: ForgottenPasswordInitialData;
  data: VerificationResponse;
  passwordHasbeenReset: boolean;
  passwordResetLinkAlreadyUsed: boolean;
  passwordResentLinkInvalid: boolean;
  passwordNotReset: boolean;
  passwordResetError: boolean;
  resetFormGroup: FormGroup;
  matcher = new AppErrorStateMatcherComponent();
  hide: boolean;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private parentService: ParentService,
    private resetForgottenPasswordService: ResetforgottenpasswordService) {
    this.parentService.hidePublicHeader = true;
    this.parentService.hidePrivateHeader = true;
    this.createFormGroup();
  }

  ngOnInit() {
    this.hide = true;

    this.getInitialData();
    this.verifyForgottenPasswordResetCode();
  }

  private getInitialData() {
    this.resetForgottenPasswordService.getInitialData().subscribe(data => {
      this.initialData = data;
    });
  }

  createFormGroup() {
    this.resetFormGroup = this.formBuilder.group({
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    },
      {
        validator: PasswordValidation.MatchPassword
      }
    );
  }

  verifyForgottenPasswordResetCode() {
    const code = this.route.snapshot.queryParamMap.get('code');
    const userId = Number(this.route.snapshot.queryParamMap.get('userid'));

    const verifyForgottenPasswordResetCodeRequest =
      new VerifyForgottenPasswordResetCodeRequest(userId, code);

    this.resetForgottenPasswordService.verifyForgottenPasswordResetCode(
      verifyForgottenPasswordResetCodeRequest).subscribe(
        (verification: VerificationResponse) => {
          this.data = verification;

          if (verification.status) {
            this.showLinkAlreadyUsed();
          } else if (!verification.status && verification.response === null) {
            this.showLinkIsInvalid();
          }
        },
        (error: Error) => {

        }
      );
  }

  showPasswordReset(response) {
    this.passwordHasbeenReset = true;
  }

  showLinkAlreadyUsed() {
    this.passwordResetLinkAlreadyUsed = true;
  }

  showLinkIsInvalid() {
    this.passwordResentLinkInvalid = true;
  }

  showPasswordNotReset(response) {
    this.passwordNotReset = true;

  }

  login() {
    this.router.navigate(['/client/login']);
  }

  showPasswordResetError(error) {
    this.passwordResetError = true;
  }

  onSubmitNewPassword() {
    const password = this.resetFormGroup.controls['password'].value;
    const userId = Number(this.route.snapshot.queryParamMap.get('userid'));
    const code = this.route.snapshot.queryParamMap.get('code');

    const userResetForgottenPasswordRequest =
      new UserResetForgottenPasswordRequest(userId, code, password);

    this.resetForgottenPasswordService.resetForgottenPassword(userResetForgottenPasswordRequest).subscribe(
      (response: SaveResponse) => {

        if (response.saved) {
          this.showPasswordReset(response);
        } else {
          this.showPasswordNotReset(response);
        }
      },
      (error: Error) => {
        this.showPasswordResetError(error);
      }
    );
  }
}

export class LoggedInUserDetails {
    public constructor(
        public userId: number,
        public firstName: string) {

    }
}

import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthenticationService } from '../services/auth/authentication.service';
import { UserService } from '../services/user/user.service';
import { ErrorService } from '../errors/error.service';
import { ConfigService } from '../services/config/config.service';
import { LoginService } from './login.service';
import { LoggedInUserDetails } from './login-request-response';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerVisibilityService } from 'ng-http-loader';
import { ConfigInitialData } from '../services/config/config-request-response';
import { TOKEN_NAME } from '../services/auth/auth-constants';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AppErrorStateMatcherComponent } from '../validators/app-error-state-matcher/app-error-state-matcher.component';
import { ParentService } from '../parent/parent.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  model: any = {};
  loading = false;
  authorities;
  error: string;
  redirectUrl: string;
  redirectMessage: string;
  firstName: string;
  dashboardUrls: string[] = [];
  privateMode: boolean;
  initialdata: ConfigInitialData;
  tokenExpired: string;
  hide: boolean;

  loginFormGroup: FormGroup;
  matcher = new AppErrorStateMatcherComponent();
  emailPattern = '[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}';

  constructor(private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private loginService: LoginService,
    private router: Router,
    private translateService: TranslateService,
    private authenticationService: AuthenticationService,
    public errorService: ErrorService,
    public configService: ConfigService,
    private spinner: SpinnerVisibilityService,
    private parentService: ParentService,
    private formBuilder: FormBuilder
  ) {
    this.parentService.hidePublicHeader = true;
    this.parentService.hidePrivateHeader = true;
    this.createFormGroup();
  }

  createFormGroup() {
    this.loginFormGroup = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email, Validators.pattern(this.emailPattern)]],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.hide = true;
    this.initializeParams();
  }

  private initializeParams() {
    this.redirectMessage = this.activatedRoute.snapshot.queryParams['redirectMessage'];
    this.tokenExpired = this.activatedRoute.snapshot.params['tokenExpired'];
    this.redirectUrl = this.activatedRoute.snapshot.queryParams['redirectTo'];
  }

  private removeJwtToken(): void {
    localStorage.removeItem(TOKEN_NAME);
  }

  private navigateToValidateEmail(email: string) {
    this.router.navigate(['/email/validate'],
      { queryParams: { email: email } });
  }

  private emailValidated(roles: string[]): boolean {
    if (roles !== undefined) {
      const emailValidated = roles.find(x => x === 'EMAIL_VALIDATED');

      if (emailValidated) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  private navigateToCurrentUserDashboard(roles: string[]): string {
    const admin = roles.find(x => x === 'ADMIN');
    const client = roles.find(x => x === 'CLIENT');

    if (admin) {
      return '/admin/dashboard';
    } else if (client) {
      return '/client/home';
    }
    return '#';
  }

  private navigateAfterSuccess(email: string): void {
    this.userService.getUserDashboardByRole();
    const roles: string[] = this.userService.getAuthorities();

    if (!this.emailValidated(roles)) {
      this.navigateToValidateEmail(email);
    } else if (this.redirectUrl) {
      this.router.navigateByUrl(this.redirectUrl);
    } else {
      const route = this.navigateToCurrentUserDashboard(roles);
      this.router.navigate([route]);
    }
  }

  private getLoginInitialData(email): void {
    this.loginService.getInitialData(email).subscribe(
      (loggedInUserDetails: LoggedInUserDetails) => {
        this.loginService.firstName = loggedInUserDetails.firstName;
        this.loginService.userId = loggedInUserDetails.userId;
        this.navigateAfterSuccess(email);
      }
    );
  }

  private errorYouDoNotHavePermissionToAccessThisDomain(): void {
    this.translateService.get(
      'login/you_do_not_have_permission_to_access_this_domain').subscribe(
        youDoNotHavePermissionToAccessThisDomain => {
          this.error = youDoNotHavePermissionToAccessThisDomain;
        }
      );
  }

  resetForgottenPassword() {
    this.router.navigate(['/user/forgottenpassword']);
  }

  quickLogin() {
    this.router.navigate(['/client/home']);
  }


  login(): void {
    const email = this.loginFormGroup.get('email').value;
    const password = this.loginFormGroup.get('password').value;
    this.userService.loggedInUsername = email;
    this.removeJwtToken();
    this.spinner.show();
    this.loading = true;
    this.authenticationService.login(email, password)
      .subscribe(
        result => {
          this.loading = false;

          if (result) {
            this.userService.login(result);
            this.authorities = this.userService.authorities;
            // if (this.authorities === undefined || this.authorities === null) {
            //   this.errorYouDoNotHavePermissionToAccessThisDomain();
            //   this.spinner.hide();
            // } else {
            this.userService.loggedInUsername = email;
            this.getLoginInitialData(email);
            this.spinner.hide();
            // }
          }
        },
        (error: Error) => {
          this.error = this.errorService.error;
          this.spinner.hide();
        }
      );
  }

  ngOnDestroy() {
    this.spinner.hide();
  }
}

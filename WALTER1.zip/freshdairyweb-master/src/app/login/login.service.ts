import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { LoggedInUserDetails } from './login-request-response';

@Injectable({
    providedIn: 'root'
})

export class LoginService {
    firstName: string;
    public userId: number;
    GET_LOGIN_INITIAL_DATA_URL = '/freshdairy/user/loggedinuserdetails/get';

    constructor(private http: HttpClient) { }

    getInitialData(email: string): Observable<LoggedInUserDetails> {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
            })
        };

        return this.http.post(
            this.GET_LOGIN_INITIAL_DATA_URL, email, httpOptions).pipe(map(
                (initialData: LoggedInUserDetails) => {
                    this.userId = initialData.userId;
                    return initialData;
                }
            ));
    }
}

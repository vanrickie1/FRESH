import { Component, OnInit, TemplateRef } from '@angular/core';
import { ParentService } from '../parent/parent.service';
import { ImageService } from '../services/image/image.service';
import { Router } from '@angular/router';
import { ClientShowArtInitialData } from './what-we-do-request-response';
import { WhatWeDoService } from './what-we-do.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';

@Component({
  selector: 'app-what-we-do',
  templateUrl: './what-we-do.component.html',
  styleUrls: ['./what-we-do.component.css']
})
export class WhatWeDoComponent implements OnInit {

  artInitialData: ClientShowArtInitialData;
  modalRef: BsModalRef;
  modalProduct: string;
  modalQrcodeId: number;

  constructor(
    public imageService: ImageService,
    public whatWeDoService: WhatWeDoService,
    private modalService: BsModalService,
    private parentService: ParentService) {
    this.parentService.hidePublicHeader = false;
    this.parentService.hidePrivateHeader = true;
  }

  ngOnInit() {
    this.getArtInitialData();
  }

  // Start Art initialdata setup
  private getArtInitialData() {
    this.whatWeDoService.getInitialData().subscribe(data => {
      this.artInitialData = data;
    });
  }

  openModal(template: TemplateRef<any>, productName, artId) {
    this.modalProduct = productName;
    this.modalQrcodeId = artId;
    const config = {
      animated: true,
      keyboard: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'modal-sm'
    };
    this.modalRef = this.modalService.show(template, config);
  }
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ClientShowArtInitialData } from './what-we-do-request-response';

@Injectable({
  providedIn: 'root'
})
export class WhatWeDoService {

  GET_INITIAL_DATA_URL = '/freshdairy/client/art/show/publicinitialdata';
  constructor(private http: HttpClient) { }

  getInitialData(): Observable<ClientShowArtInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: ClientShowArtInitialData) => initialData));
  }

}

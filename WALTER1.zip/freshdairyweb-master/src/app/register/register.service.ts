import { Injectable } from '@angular/core';
import {
  RegistrationInitialData,
  RegistrationRequest,
  DrawSaveResponse
} from './register-request-response';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private REGISTER_URL = '/freshdairy/client/registration/draw/save';
  private REGISTER_APPLICANT_GET_INITIAL_DATA_URL = '/freshdairy/client/registration/initialdata';

  constructor(private http: HttpClient) {

  }

  getInitialData(): Observable<RegistrationInitialData> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.REGISTER_APPLICANT_GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: RegistrationInitialData) => {
          return initialData;
        }
      ));
  }

  save(registrationRequest: RegistrationRequest):
    Observable<DrawSaveResponse> {
    const headers = new HttpHeaders();

    return this.http.post(this.REGISTER_URL,
      registrationRequest, { headers }).pipe(map(
        (response: DrawSaveResponse) => {
          return response;
        }
      ));
  }
}

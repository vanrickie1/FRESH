

export class RegistrationInitialData {

  public constructor(public stateTransfers: StateTransfer[],
    public minPasswordLength: number,
    public maxPasswordLength: number) {

  }
}


export class StateTransfer {

  public constructor(public id: number, public name: string) {

  }
}

export class RegistrationRequest {

  public constructor(
    public firstName: string,
    public lastName: string,
    public outlet: string,
    public location: string,
    public phoneNumber: string,
    public receiptNumber: string,
    public artId: number) {
  }
}

export class DrawSaveResponse {

  public constructor(
    public saved: boolean,
    public receiptExistsAlready: boolean,
  ) {

  }
}

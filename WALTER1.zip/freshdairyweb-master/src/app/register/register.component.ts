import { Component, OnInit } from '@angular/core';
import { RegisterService } from './register.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import {
  AppErrorStateMatcherComponent
} from '../validators/app-error-state-matcher/app-error-state-matcher.component';
import { ParentService } from '../parent/parent.service';
import {
  RegistrationInitialData,
  RegistrationRequest, DrawSaveResponse
} from './register-request-response';
import { Router, ActivatedRoute } from '@angular/router';
import { PasswordValidation } from '../directive/password-validator';
import { ImageService } from '../services/image/image.service';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})

export class RegisterComponent implements OnInit {

  selectedState: number;
  registerFormGroup: FormGroup;
  email: string;
  telephone: string;
  initialData: RegistrationInitialData;
  matcher = new AppErrorStateMatcherComponent();
  registered: boolean;
  artId: number;
  userEmail: string;
  response: DrawSaveResponse;
  hide: boolean;
  emailPattern = '[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}';
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  createFormGroup() {
    this.registerFormGroup = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      outlet: ['', Validators.required],
      location: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      receiptNumber: [' ', [Validators.required]]
    });
  }

  constructor(private registerService: RegisterService,
    private router: Router,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    public imageService: ImageService,
    private snackBar: MatSnackBar,
    private parentService: ParentService) {
    this.parentService.hidePublicHeader = true;
    this.parentService.hidePrivateHeader = true;
    this.selectedState = 1;
    this.hide = true;
    this.createFormGroup();
  }

  ngOnInit() {
    this.registered = false;
    this.getInitialData();
  }

  private getInitialData() {
    this.artId = Number(this.activatedRoute.snapshot.params['artId']);
    this.registerService.getInitialData().subscribe(data => {
      this.initialData = data;
    });
  }

  public login() {
    this.router.navigate(['/client/login']);
  }

  public back() {
    this.router.navigate(['/what-we-do']);
  }

  public onSubmit() {
    const firstName = this.registerFormGroup.get('firstName').value;
    const lastName = this.registerFormGroup.get('lastName').value;
    const outlet = this.registerFormGroup.get('outlet').value;
    const location = this.registerFormGroup.get('location').value;
    const phoneNumber = this.registerFormGroup.get('phoneNumber').value;
    const receiptNumber = this.registerFormGroup.get('receiptNumber').value;
    const artId = this.artId;

    if (this.registerFormGroup.valid) {
      const registrationRequest: RegistrationRequest =
        new RegistrationRequest(firstName, lastName, outlet, location, phoneNumber,
          receiptNumber, artId);

      this.registerService.save(registrationRequest).subscribe(
        (response: DrawSaveResponse) => {
          this.response = response;
          if (response.saved) {
            this.registered = true;
            this.openSnackBar('Congratulations. You have successfully entered the draw.NOTE. Please keep your receipt.  It will be required to prove ownership', 'X', 5000,
              'green-snackbar');

            this.router.navigate(['/what-we-do']);
          } else {
            this.openSnackBar('Receipt number already exists', 'X', 5000,
              'red-snackbar');
            if (response.receiptExistsAlready) {
              this.registerFormGroup.controls['receiptNumber'].setErrors({ 'receiptExistsAlready': true });
            }
            this.registered = false;
          }
        }
      );
    }
  }

  openSnackBar(message: string, panelClass: string, seconds: number,
    snackBarClass: string) {
    this.snackBar.open(message, panelClass, {
      duration: seconds,
      verticalPosition: 'top',
      panelClass: [snackBarClass]
    });
  }

  openSnackBarNotes(message: string, panelClass: string, seconds: number,
    snackBarClass: string) {
    this.snackBar.open(message, panelClass, {
      duration: seconds,
      verticalPosition: 'bottom',
      panelClass: [snackBarClass]
    });
  }

  scroll(el) {
    el.scrollIntoView();
  }
}

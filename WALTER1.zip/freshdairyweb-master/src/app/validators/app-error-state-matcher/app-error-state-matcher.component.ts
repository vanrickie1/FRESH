import { Component, OnInit } from '@angular/core';
import { ErrorStateMatcher } from '@angular/material';
import { FormControl, FormGroupDirective, NgForm } from '@angular/forms';

@Component({
  selector: 'app-app-error-state-matcher',
  templateUrl: './app-error-state-matcher.component.html',
  styleUrls: ['./app-error-state-matcher.component.css']
})
export class AppErrorStateMatcherComponent implements OnInit, ErrorStateMatcher {
  constructor() { }
  ngOnInit() {
  }

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

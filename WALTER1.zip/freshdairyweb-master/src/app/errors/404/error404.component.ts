import { Component, Injectable, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-error404',
  templateUrl: './error404.component.html'
})

export class Error404Component implements OnInit {

  redirectUrl: string;
  invalidPath: string;

  constructor(private router: Router,
    private activatedRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.invalidPath = this.activatedRoute.snapshot.params['invalidPath'];
    if (this.invalidPath === undefined) {
      this.invalidPath = this.router.url;
    }
  }

  backToPreviousPage() {
    if (this.redirectUrl) {
      this.router.navigateByUrl(this.redirectUrl);
    } else {
      this.router.navigate(['/login']);
    }
  }

}

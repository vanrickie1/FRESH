import { Component, OnInit } from '@angular/core';
import { ParentService } from '../parent/parent.service';

@Component({
  selector: 'app-who-we-serve',
  templateUrl: './who-we-serve.component.html',
  styleUrls: ['./who-we-serve.component.css']
})
export class WhoWeServeComponent implements OnInit {

  constructor(private parentService: ParentService) {
    this.parentService.hidePublicHeader = false;
  }

  ngOnInit() {
  }

}

export class ConfirmEmailPasswordRequest {

    public constructor(
        public email: string,
        public password: string,
        public localeStr: string
    ) {
    }
}

export class VerificationResponse {
    public constructor(public status: boolean,
        public response: string) {

    }
}

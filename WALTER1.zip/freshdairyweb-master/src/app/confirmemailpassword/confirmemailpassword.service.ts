

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import {
  ConfirmEmailPasswordRequest,
  VerificationResponse
} from './confirmemailpassword-request-response';


@Injectable({
  providedIn: 'root'
})

export class ConfirmEmailPasswordService {

  CONFIRM_EMAIL_PASSWORD_URL = '/freshdairy/user/email/validatepassword';

  constructor(private http: HttpClient) {

  }

  confirmEmailPassword(confirmEmailPasswordRequest: ConfirmEmailPasswordRequest):
    Observable<VerificationResponse> {
    const body = JSON.stringify(confirmEmailPasswordRequest);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(this.CONFIRM_EMAIL_PASSWORD_URL, body, httpOptions).pipe(map(
      (response: VerificationResponse) => {
        return response;
      }
    ));
  }

}

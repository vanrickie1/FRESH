import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { ConfirmEmailPasswordService } from './confirmemailpassword.service';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmEmailPasswordRequest, VerificationResponse } from './confirmemailpassword-request-response';

@Component({
  selector: 'app-confirmemailpassword',
  templateUrl: './confirmemailpassword.component.html'
})

export class ConfirmemailpasswordComponent implements OnInit {

  errorsConfirmPassword: string;
  passwordMatched = true;
  accountCreated = false;
  message: string;
  email: string;

  constructor(private router: Router,
    private activatedRoute: ActivatedRoute,
    private confirmEmailPasswordService: ConfirmEmailPasswordService,
    private translateService: TranslateService) {

  }

  ngOnInit() {

    this.activatedRoute.queryParams.forEach((params: Params) => {
      this.email = params['email'];
    });
  }

  showError(error) {
    const observable_message = this.translateService.get('generic/error');

    observable_message.subscribe(
      messageLabel => {
        this.errorsConfirmPassword = messageLabel + ': ' + error.message;
      }
    );
  }

  onSubmitConfrimEmailPassword(form: NgForm) {
    const password = form.controls['password'].value;
    const email = this.email;
    const localeStr = this.translateService.currentLang;
    const confirmEmailPasswordRequest = new ConfirmEmailPasswordRequest(email, password, localeStr);

    this.confirmEmailPasswordService.confirmEmailPassword(confirmEmailPasswordRequest).subscribe(
      (verificationResponse: VerificationResponse) => {
        if (verificationResponse.response === 'invalidpassword') {
          this.passwordMatched = false;
          this.message = 'notloggedin/confirmemailpassword/password_did_not_match';
        } else if (verificationResponse.response === 'applicantnotactivated') {
          this.passwordMatched = true;
          this.accountCreated = true;
          this.message = 'notloggedin/confirmemailpassword/email_sent';

        } else {
          this.passwordMatched = true;
          this.accountCreated = true;
          this.message = 'notloggedin/confirmemailpassword/account_created';
        }
      },
      (error: Error) => {
        this.showError(error);
      }
    );
  }

}

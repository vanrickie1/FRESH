export const TOKEN_AUTH_USERNAME = 'testjwtclientid';
export const TOKEN_AUTH_PASSWORD = 'XY7kmzoNzl100';
export const TOKEN_NAME = 'access_token';

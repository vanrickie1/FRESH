import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class LocaleService {

  constructor(
    public translateService: TranslateService
  ) {

  }

  // note that the navigator language may or may not be suppoered by the
  // spring back end. If it is not supported the back end should return any
  // translations such as product categories in the organisation's default
  // language.
  public getlocaleFromTranslateServiceOrLocalStorageOrBrowser(): string {

    let locale = this.translateService.currentLang;

    if (locale === undefined) {
      locale = localStorage.getItem('locale');
    }

    if (locale === undefined) {
      locale = navigator.language;
    }

    return locale;
  }
}

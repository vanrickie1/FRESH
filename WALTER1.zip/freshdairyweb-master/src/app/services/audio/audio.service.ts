import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AudioService {

  private RIDDLE_AUDIO_PATH_STEM = '/freshdairy/audio/riddle?riddleId=';
  private QUESTION_AUDIO_PATH_STEM = '/freshdairy/audio/videointerviewquestion?videoInterviewQuestionId=';
  private ORIGINAL_AUDIO_PATH_STEM = '/freshdairy/audio/downloadoriginalaudio?audioId=';
  private AUDIO_NAME_STEM = '&audioName=';

  constructor() {
  }

  getRiddleAudioPath(audioId: number, fileName: string): string {
    return this.RIDDLE_AUDIO_PATH_STEM + audioId + this.AUDIO_NAME_STEM + fileName;
  }

  getQuestionAudioPath(audioId: number, fileName: string): string {
    return this.QUESTION_AUDIO_PATH_STEM + audioId + this.AUDIO_NAME_STEM + fileName;
  }

  getOriginalAudioPath(audioId: number, fileName: string): string {
    return this.ORIGINAL_AUDIO_PATH_STEM + audioId + this.AUDIO_NAME_STEM + fileName;
  }
}

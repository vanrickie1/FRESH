
export class TitleInitialData {

    public constructor(
        public organisationName: string) {

    }
}


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { TitleInitialData } from './title-request-response';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class TitleService {

  GET_TITLE_INITIAL_DATA_URL = '/freshdairy/title/getinitialdata';

  constructor(
    private http: HttpClient) {

  }

  getInitialData(): Observable<TitleInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(this.GET_TITLE_INITIAL_DATA_URL, httpOptions).pipe(map(
      (response: TitleInitialData) => {
        return response;
      }
    ));
  }
}

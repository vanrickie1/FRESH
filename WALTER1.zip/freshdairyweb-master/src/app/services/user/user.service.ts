import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';

import { TOKEN_NAME } from '../auth/auth-constants';
import { User } from './user-request';
import { UserTransfer } from './user-response';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  // GET_USERS_URL = '/43kare/users';
  GET_USER_TRANSFERS_URL = '/freshdairy/admin/users';
  GET_NON_ADMIN_USERS = '/freshdairy/admin/users/nonadminusers';
  accessToken: string;
  loggedInUserId: number;
  authorities: string[];
  loggedInUsername: string;
  dashboardUrls: string[] = [];
  dashboardTitles: string[] = [];

  constructor(private http: HttpClient, private route: ActivatedRoute,
    private router: Router,
    private jwtHelperService: JwtHelperService) {

  }

  login(accessToken: string): void {
    const decodedToken = this.jwtHelperService.decodeToken(accessToken);
    this.authorities = decodedToken.authorities;
    this.loggedInUsername = decodedToken.user_name;

    if (this.authorities !== undefined) {
      for (const authority of decodedToken.authorities) {
      }
    }

    this.accessToken = accessToken;
    localStorage.setItem(TOKEN_NAME, accessToken);
  }

  isLoggedIn(): boolean {
    if (this.loggedInUsername) {
      return true;
    }
    return false;
  }

  getAuthorities(): string[] {
    return this.authorities;
  }

  getUserDashboardByRole(): void {
    const roles: string[] = this.getAuthorities();
    this.dashboardUrls = [];
    this.dashboardTitles = [];

    if (roles !== undefined) {
      if (roles.indexOf('APPLICANT') > -1) {
        this.dashboardUrls.push('/applicant/dashboard');
        this.dashboardTitles.push('header/topheader/applicant_dashboard');
      } else if (roles.indexOf('ADMIN') > -1) {
        this.dashboardUrls.push('/admin/dashboard');
        this.dashboardTitles.push('header/topheader/admin_dashboard');
      } else if (roles.indexOf('REPORTING') > -1) {
        this.dashboardUrls.push('/reporting/dashboard');
        this.dashboardTitles.push('header/topheader/reporting_dashboard');
      } else if (roles.indexOf('LEX') > -1) {
        this.dashboardUrls.push('/lex/dashboard');
        this.dashboardTitles.push('header/topheader/lex_dashboard');
      } else if (roles.indexOf('EMPLOYEE') > -1) {
        this.dashboardUrls.push('/employee/dashboard');
        this.dashboardTitles.push('header/topheader/employee_dashboard');
      }
    }
  }

  getAccessToken(): string {
    return 'Bearer ' + localStorage.getItem('access_token');
  }

  getAccessTokenForImage(): string {
    return 'bearer=' + localStorage.getItem('access_token');
  }

  hasPermission(permission: string): boolean {
    return this.authorities.some(el => el === permission);
  }

  getUserTransfers(): Observable<UserTransfer[]> {
    return this.http.get(this.GET_USER_TRANSFERS_URL).pipe(map(
      (response: UserTransfer[]) => {
        return response;
      }
    ));
  }

  getNonAdminUsers(): Observable<User[]> {
    return this.http.get(this.GET_NON_ADMIN_USERS).pipe(map(
      (response: User[]) => {
        return response;
      }
    ));
  }
}

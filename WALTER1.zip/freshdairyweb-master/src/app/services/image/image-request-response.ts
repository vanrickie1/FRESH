
export class ImageDetails {

    public constructor(
        public imagePath: string,
        public imageAltOrTitle: string) {
    }
}

export class Base64Image {

    public constructor(
        public base64String: string) {
    }
}

export class Image {

    public constructor(
        public id: number,
        public name: string,
        public description: string,
        public show_name_if_possible: boolean,
        public show_description_if_possible: boolean) {
    }
}



import { ImageDetails, Image } from './image-request-response';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../user/user.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  private FRONT_IMAGE_PATH_STEM = '/freshdairy/image/art/front?artId=';
  private BACK_IMAGE_PATH_STEM = '/freshdairy/image/art/back?artId=';
  private IMAGE_NAME_STEM = '&imageName=';

  constructor(private http: HttpClient,
    private userService: UserService) {
  }

  getFrontImageDetails(image: Image): ImageDetails {
    let imagePath;
    let imageAltOrTitle;

    if (image !== null) {
      imagePath = this.FRONT_IMAGE_PATH_STEM + image.id;
      imageAltOrTitle = image.name;
    } else {
      imagePath = null;
      imageAltOrTitle = 'Image not found';
    }

    return new ImageDetails(imagePath, imageAltOrTitle);
  }

  getBackImageDetails(image: Image): ImageDetails {
    let imagePath;
    let imageAltOrTitle;

    if (image !== null) {
      imagePath = this.BACK_IMAGE_PATH_STEM + image.id;
      imageAltOrTitle = image.name;
    } else {
      imagePath = null;
      imageAltOrTitle = 'Image not found';
    }

    return new ImageDetails(imagePath, imageAltOrTitle);
  }

  getFrontImagePath(imageId: number, fileName: string): string {
    return this.FRONT_IMAGE_PATH_STEM + imageId + this.IMAGE_NAME_STEM + fileName;
  }

  getQrcodeImagePath(imageId: number, fileName: string): string {
    return this.BACK_IMAGE_PATH_STEM + imageId + this.IMAGE_NAME_STEM + fileName;
  }
}

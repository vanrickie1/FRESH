
export class CvDetails {

    public constructor(
        public cvPath: string,
        public cvAltOrTitle: string) {
    }
}

export class Cv {

    public constructor(
        public id: number,
        public name: string,
        public description: string,
        public show_name_if_possible: boolean,
        public show_description_if_possible: boolean) {
    }
}


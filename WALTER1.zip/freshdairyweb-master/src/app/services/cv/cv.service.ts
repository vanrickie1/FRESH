import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CvService {

  private CV_PATH_STEM = '/freshdairy/cv/download?cvId=';
  private ORIGINAL_CV_PATH_STEM = '/freshdairy/cv/downloadoriginalcv?cvId=';
  private CV_NAME_STEM = '&cvName=';

  constructor() {
  }

  getCvPath(cvId: number, cvName: string): string {
    return this.CV_PATH_STEM + cvId + this.CV_NAME_STEM + cvName;
  }

  getOriginalCvPath(cvId: number, cvName: string): string {
    return this.ORIGINAL_CV_PATH_STEM + cvId + this.CV_NAME_STEM + cvName;
  }
}

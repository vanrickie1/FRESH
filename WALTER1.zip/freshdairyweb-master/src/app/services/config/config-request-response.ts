export class ConfigInitialData {
  public constructor(
    public privateMode: boolean
  ) {

  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ConfirmemailpasswordComponent } from './confirmemailpassword/confirmemailpassword.component';
import { EmailvalidatedComponent } from './email/emailvalidated/emailvalidated.component';
import { ForgotpasswordComponent } from './email/forgotpassword/forgotpassword.component';
import { ResetforgottenpasswordComponent } from './email/resetforgottenpassword/resetforgottenpassword.component';
import { ValidateemailComponent } from './email/validateemail/validateemail.component';
import { Error404Component } from './errors/404/error404.component';
import { ErrorComponent } from './errors/error/error.component';
import { ErrorofflineComponent } from './errors/offline/erroroffline.component';
import { AcceptableUsePolicyComponent } from './footer/acceptable-use-policy/acceptable-use-policy.component';
import { ContactEnComponent } from './footer/contact/contact-en/contact-en.component';
import { CookiePolicyComponent } from './footer/cookie-policy/cookie-policy.component';
import { PrivacyPolicyComponent } from './footer/privacy-policy/privacy-policy.component';
import { TermsOfServiceComponent } from './footer/terms-of-service/terms-of-service.component';
import { AuthGuard } from './guards/auth-guard';
import { HasPermissionGuard } from './guards/haspermission-guard';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { WhatWeDoComponent } from './what-we-do/what-we-do.component';
import { WhoWeAreComponent } from './who-we-are/who-we-are.component';
import { WhoWeServeComponent } from './who-we-serve/who-we-serve.component';
import { ParentComponent } from './parent/parent.component';

const appRoutes: Routes = [
  {
    path: '',
    component: ParentComponent, children: [
      { path: 'what-we-do', component: WhatWeDoComponent },
      { path: 'enterdraw/:artId', component: RegisterComponent },
      { path: 'who-we-are', component: WhoWeAreComponent },
      { path: 'who-we-serve', component: WhoWeServeComponent },
      { path: 'client/resetforgottenpassword', component: ResetforgottenpasswordComponent },
      { path: 'client/register', component: RegisterComponent },
      { path: 'client/registration/activate', component: EmailvalidatedComponent },
      { path: 'client/login', component: LoginComponent },
      { path: 'user/forgottenpassword', component: ForgotpasswordComponent },
      { path: 'user/confirmpassword', component: ConfirmemailpasswordComponent },
      { path: 'user/resetforgottenpassword', component: ResetforgottenpasswordComponent },
      { path: 'user/validate', component: ValidateemailComponent, canActivate: [AuthGuard] },
      { path: 'email/validate', component: ValidateemailComponent, canActivate: [AuthGuard] },
      { path: 'error404', component: Error404Component },
      { path: 'erroroffline', component: ErrorofflineComponent },
      { path: 'error', component: ErrorComponent },
      {
        path: 'superadmin',
        loadChildren: () => import('./modules/superadmin/superadmin.module').then(m => m.SuperadminModule),
        canActivate: [HasPermissionGuard], data: { authorities: ['ACCESS_SUPER_ADMIN'] }
      },
      {
        path: 'admin',
        loadChildren: () => import('./modules/admin/admin.module').then(m => m.AdminModule),
        canActivate: [HasPermissionGuard], data: { authorities: ['ADMIN'] }
      },
      {
        path: 'client',
        loadChildren: () => import('./modules/client/client.module').then(m => m.ClientModule)
      },
      {
        path: 'contact', children: [
          { path: 'contact_en', component: ContactEnComponent },
        ]
      },
      { path: 'acceptable_user_policy', component: AcceptableUsePolicyComponent },
      { path: 'privacy_policy', component: PrivacyPolicyComponent },
      { path: 'terms_of_service', component: TermsOfServiceComponent },
      { path: 'cookie_policy', component: CookiePolicyComponent },
      { path: '', redirectTo: 'what-we-do', pathMatch: 'full' },
      { path: '**', component: Error404Component },
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, { enableTracing: true, onSameUrlNavigation: 'reload' }),
  ],
  exports: [
    RouterModule,
  ]
})

export class AppRoutingModule {

}

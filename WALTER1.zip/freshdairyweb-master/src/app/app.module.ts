import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { NgxSpinnerModule } from 'ngx-spinner';

import { Overlay, OverlayContainer } from '@angular/cdk/overlay';
import { CustomOverlayContainer } from './theme/utils/custom-overlay-container';
import { menuScrollStrategy } from './theme/utils/scroll-strategy';

import { AppRoutingModule } from './app.routing.module';
import { AppSettings } from './app.settings';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';
import localeEn from '@angular/common/locales/en';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ErrorService } from './errors/error.service';
import { ErrorInterceptor } from './interceptors/error.interceptor';
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { SharedModule } from './modules/shared/shared.module';
import { RegisterComponent } from './register/register.component';
import { ForgotpasswordComponent } from './email/forgotpassword/forgotpassword.component';
import { EmailvalidatedComponent } from './email/emailvalidated/emailvalidated.component';
import { ResetforgottenpasswordComponent } from './email/resetforgottenpassword/resetforgottenpassword.component';
import { ValidateemailComponent } from './email/validateemail/validateemail.component';
import { ConfirmemailpasswordComponent } from './confirmemailpassword/confirmemailpassword.component';
import { ContactEnComponent } from './footer/contact/contact-en/contact-en.component';
import { LoginComponent } from './login/login.component';
import { Error404Component } from './errors/404/error404.component';
import { ErrorofflineComponent } from './errors/offline/erroroffline.component';
import { ErrorComponent } from './errors/error/error.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDropdownModule } from 'ngx-bootstrap';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { JwtModule } from '@auth0/angular-jwt';
import { ContextMenuModule } from 'ngx-contextmenu';
import { NgHttpLoaderModule } from 'ng-http-loader';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { TopHeaderComponent } from './header/topheader/topheader.component';
import { BottomHeaderComponent } from './header/bottomheader/bottomheader';
import { SidenavMenuComponent } from './header/sidenav-menu/sidenav-menu.component';
import { ContactComponent } from './footer/contact/contact.component';
import { CookiePolicyComponent } from './footer/cookie-policy/cookie-policy.component';
import { TermsOfServiceComponent } from './footer/terms-of-service/terms-of-service.component';
import { PrivacyPolicyComponent } from './footer/privacy-policy/privacy-policy.component';
import { AcceptableUsePolicyComponent } from './footer/acceptable-use-policy/acceptable-use-policy.component';
import { MAT_MENU_SCROLL_STRATEGY } from '@angular/material/menu';
import { HomeComponent } from './home/home.component';
import { WhoWeAreComponent } from './who-we-are/who-we-are.component';
import { WhatWeDoComponent } from './what-we-do/what-we-do.component';
import { WhoWeServeComponent } from './who-we-serve/who-we-serve.component';
import { AppErrorStateMatcherComponent } from './validators/app-error-state-matcher/app-error-state-matcher.component';
import { ParentComponent } from './parent/parent.component';
import { NgxMatIntlTelInputModule } from 'ngx-mat-intl-tel-input';
import { PhoneMaskDirective } from './directive/phone-mask.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

registerLocaleData(localeDe, 'de');
registerLocaleData(localeEn, 'en');

export function HttpLoaderFactory(http: HttpClient) {
  // return new TranslateHttpLoader(http, './assets/i18n/', '.json');
  return new TranslateHttpLoader(http);
}

export function tokenGetter() {
  return localStorage.getItem('access_token');
}

const jwtConf = {
  config: {
    throwNoTokenError: false,
    tokenGetter: tokenGetter,
    whitelistedDomains: ['localhost:8080'],
  }
};

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    NgxSpinnerModule,
    ReactiveFormsModule,
    SharedModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    NgxMatIntlTelInputModule,
    TabsModule.forRoot(),
    NgHttpLoaderModule.forRoot(),
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot(),
    ContextMenuModule.forRoot({
      useBootstrap4: true
    }),
    ModalModule.forRoot(),
    TabsModule.forRoot(),
    HttpClientModule,
    JwtModule.forRoot(jwtConf),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
  ],
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ForgotpasswordComponent,
    EmailvalidatedComponent,
    Error404Component,
    ErrorofflineComponent,
    ErrorComponent,
    ResetforgottenpasswordComponent,
    ValidateemailComponent,
    ConfirmemailpasswordComponent,
    ContactEnComponent,
    TopHeaderComponent,
    PhoneMaskDirective,
    BottomHeaderComponent,
    SidenavMenuComponent,
    FooterComponent,
    ContactComponent,
    CookiePolicyComponent,
    TermsOfServiceComponent,
    PrivacyPolicyComponent,
    AcceptableUsePolicyComponent,
    HomeComponent,
    WhoWeAreComponent,
    WhatWeDoComponent,
    WhoWeServeComponent,
    ParentComponent,
    AppErrorStateMatcherComponent,
  ],
  providers: [
    AppSettings,
    { provide: OverlayContainer, useClass: CustomOverlayContainer },
    { provide: MAT_MENU_SCROLL_STRATEGY, useFactory: menuScrollStrategy, deps: [Overlay] },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: ErrorHandler, useClass: ErrorService },
    TranslateService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HasPermissionGuard } from '../../guards/haspermission-guard';
import { AdmindashboardComponent } from './dashboard/admindashboard.component';
import { AdmineditmyaccountComponent } from './myaccount/edit/editmyaccount.component';

const orgRoutes: Routes = [
  {
    path: 'dashboard',
    component: AdmindashboardComponent,
    canActivate: [HasPermissionGuard],
    data: { authorities: ['ADMIN'] }
  },
  {
    path: 'myaccount', children: [
      {
        path: 'edit',
        component: AdmineditmyaccountComponent,
        canActivate: [HasPermissionGuard],
        data: { authorities: ['ADMIN'] }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(orgRoutes),
  ],
  exports: [
    RouterModule,
  ]
})
export class AdminroutingModule {

}

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { NgSelectModule } from '@ng-select/ng-select';
import { TranslateModule } from '@ngx-translate/core';
import { CollapseModule } from 'ngx-bootstrap';
import { TabsModule } from 'ngx-bootstrap/tabs';

import { SharedModule } from '../shared/shared.module';
import { AdminroutingModule } from './admin.routing.module';
import { AdmindashboardComponent } from './dashboard/admindashboard.component';
import { AdmineditmyaccountComponent } from './myaccount/edit/editmyaccount.component';
@NgModule({
  imports: [
    AngularEditorModule,
    CommonModule,
    FormsModule,
    NgSelectModule,
    CollapseModule,
    AdminroutingModule,
    TranslateModule.forChild(),
    CollapseModule.forRoot(),
    TabsModule,
    SharedModule
  ],
  declarations: [
    AdmindashboardComponent,
    AdmineditmyaccountComponent
  ],
  providers: []
})
export class AdminModule { }

import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user/user.service';
import { SpinnerVisibilityService } from 'ng-http-loader';


@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html'
})

export class AdmindashboardComponent implements OnInit {

  constructor(private userService: UserService,
    private spinner: SpinnerVisibilityService) { }

  ngOnInit() {
    this.spinner.hide();
  }

  isLoggedIn() {
    if (this.userService.authorities === undefined) {
      return false;
    }
    return this.userService.isLoggedIn();
  }
}

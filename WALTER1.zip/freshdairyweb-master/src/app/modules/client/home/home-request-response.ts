export class ClientShowCampaignInitialData {

    public constructor(
        public campaignTransfers: CampaignTransfer[]
    ) {

    }
}

export class CampaignTransfer {

    public constructor(
        public campaignId: number,
        public campaignName: string,
        public campaignActivated: boolean,
        public campaignConfigured: boolean,
        public hasList: boolean,
        public numberArt: number,
        public campaignType: string
    ) {

    }
}

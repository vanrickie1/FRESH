import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ParentComponent } from 'src/app/parent/parent.component';
import { ArtService } from '../art/art.service';
import { CampaignService } from '../campaign/campaign.service';
import { ListService } from '../list/list.service';
import { HomeService } from './home.service';

@Component({
  selector: 'app-client-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit, AfterViewInit {

  currentTabIndex: number;
  @ViewChild('tabGroup', { static: false }) tabGroup;

  selectTab() {
    // this.currentTabIndex = this.tabGroup.selectedIndex;
    if (this.currentTabIndex === 0) {
      // this.getCampaignInitialData();
    } else if (this.currentTabIndex === 1) {
      // this.getArtInitialData();
    } else if (this.currentTabIndex === 2) {
      // this.getListInitialData();
    }
  }

  constructor(
    private parentComponent: ParentComponent,
    private campaignService: CampaignService,
    private artService: ArtService,
    private homeService: HomeService,
    private listService: ListService) {
  }

  ngOnInit() {
    this.parentComponent.ngOnInit();
  }

  ngAfterViewInit(): void {
    this.tabGroup.selectedIndex = this.homeService.selectedTabIndex;
  }

  // Start Campaign initialdata setup
  // We are currently not calling this because it's the first component which is loaded
  private getCampaignInitialData() {
    this.campaignService.getInitialData();
  }
  // End Campaign initialdata setup

  // Start Art initialdata setup
  private getArtInitialData() {
    this.artService.getInitialData().subscribe(data => {
    });
  }
  // End Art initialdata setup

  // Start List initialdata setup
  private getListInitialData() {
    this.listService.getInitialData().subscribe(data => {
    });
  }
}


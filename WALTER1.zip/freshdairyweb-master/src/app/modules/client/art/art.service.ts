import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ClientShowArtInitialData } from './art-request-response';

@Injectable({
  providedIn: 'root'
})
export class ArtService {

  GET_INITIAL_DATA_URL = '/freshdairy/client/art/show/initialdata';
  constructor(private http: HttpClient) { }

  getInitialData(): Observable<ClientShowArtInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: ClientShowArtInitialData) => initialData));
  }

}

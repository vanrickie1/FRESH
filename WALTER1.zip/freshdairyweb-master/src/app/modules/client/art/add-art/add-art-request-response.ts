export class ClientUploadArtInitialData {

    public constructor(
        public fileTypeTransfer: FileTypeTransfer[],
        public allowedWidthPixels: number,
        public allowedHeightPixels: number
    ) {

    }
}

export class FileTypeTransfer {

    public constructor(
        public id: number,
        public name: string
    ) {

    }
}

export class ClientUploadArtRequest {

    public constructor(
        public name: string,
        public note: string
    ) {

    }
}

export class SaveArtResponse {

    public constructor(
        public saved: boolean,
        public incorrectDimensions: boolean,
        public allowedWidthPixels: number,
        public allowedHeightPixels: number,
        public actualWidthPixels: number,
        public actualHeightPixels: number,
        public actualHeightBackPixels: number,
        public actualHeightFrontPixels: number,
        public errorMessage: string,
    ) {

    }
}

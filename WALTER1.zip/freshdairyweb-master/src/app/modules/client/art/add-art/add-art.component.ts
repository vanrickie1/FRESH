import { Component, OnInit, TemplateRef } from '@angular/core';
import {
  SaveArtResponse, ClientUploadArtRequest,
  ClientUploadArtInitialData
} from './add-art-request-response';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {
  AppErrorStateMatcherComponent
} from 'src/app/validators/app-error-state-matcher/app-error-state-matcher.component';
import { AddArtService } from './add-art.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { HomeService } from '../../home/home.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

@Component({
  selector: 'app-add-art',
  templateUrl: './add-art.component.html',
  styleUrls: ['./add-art.component.css']
})
export class AddArtComponent implements OnInit {

  artFormGroup: FormGroup;
  initialData: ClientUploadArtInitialData;
  response: SaveArtResponse;
  frontArtFile: File;
  backArtFile: File;
  imagePath: string;
  message: string;
  frontArtUrl: any;
  backArtUrl: any;
  clientLogo: File;
  matcher = new AppErrorStateMatcherComponent();
  modalRef: BsModalRef;

  imgSrc: any = [];
  uploadedFrontImgSrc: any;
  uploadedBackImgSrc: any;
  uploadedFrontImgSrcView: any;
  uploadedBackImgSrcView: any;
  validFrontImgSrc: any;
  validBackImgSrc: any;
  backImageIsValid: boolean;
  frontImageIsValid: boolean;

  validFrontImageWidth: boolean;
  validFrontImageHeight: boolean;
  validBackImageWidth: boolean;
  validBackImageHeight: boolean;
  frontImageWidth: number;
  frontImageHeight: number;
  backImageWidth: number;
  backImageHeight: number;

  createFormGroup() {
    this.artFormGroup = this.formBuilder.group({
      artName: ['', Validators.required],
      note: []
    }
    );
  }

  constructor(private addArtService: AddArtService,
    private router: Router,
    private snackBar: MatSnackBar,
    private homeService: HomeService,
    private modalService: BsModalService,
    private formBuilder: FormBuilder) {
    this.createFormGroup();
    // Set tab to navigate too
    this.homeService.selectedTabIndex = 1;
  }

  ngOnInit() {
    this.getInitialData();
  }

  dataURItoBlob(dataURI, fileName: string) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    let byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      byteString = atob(dataURI.split(',')[1]);
    } else {
      byteString = unescape(dataURI.split(',')[1]);
    }
    // separate out the mime component
    const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    // write the bytes of the string to a typed array
    const ia = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new File([new Blob([ia], { type: 'image/png' })], fileName);
  }

  private getInitialData() {
    this.addArtService.getInitialData().subscribe(data => {
      this.initialData = data;
    });
  }


  base64ToFile(base64File: any) {
    const byteString = atob(base64File.split(',')[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i += 1) {
      ia[i] = byteString.charCodeAt(i);
    }
    const newBlob = new Blob([ab], {
      type: 'image/jpeg',
    });
    return newBlob;
  }

  public onSubmit() {
    const name = this.artFormGroup.get('artName').value;
    const note = this.artFormGroup.get('note').value;

    const clientUploadArtRequest =
      new ClientUploadArtRequest(name, note);

    const saveArtRequestFormData = new FormData();

    saveArtRequestFormData.append('clientUploadArtRequest',
      new Blob([JSON.stringify(clientUploadArtRequest)], {
        type: 'application/json'
      }));

    const frontArtFile = this.dataURItoBlob(this.validFrontImgSrc, 'front.png');
    if (frontArtFile) {
      saveArtRequestFormData.append('frontArt',
        frontArtFile, frontArtFile.name);
    }

    // const backArtFile = this.dataURItoBlob(this.validBackImgSrc, 'back');
    // if (backArtFile) {
    //   saveArtRequestFormData.append('backArt',
    //     backArtFile, backArtFile.name);
    // }

    if (this.artFormGroup.valid) {

      this.addArtService.save(saveArtRequestFormData).subscribe(
        (response: SaveArtResponse) => {
          this.response = response;
          if (response.saved) {
            this.openSnackBar('Successfully saved art', 'X', 4000,
              'green-snackbar');
            this.router.navigate(['/client/home']);
          } else {
            this.openSnackBar('Failed to saved art', 'X', 10000,
              'red-snackbar');
          }
        }
      );
    }
  }

  openSnackBar(message: string, panelClass: string, seconds: number,
    snackBarClass: string) {
    this.snackBar.open(message, panelClass, {
      duration: seconds,
      verticalPosition: 'top',
      panelClass: [snackBarClass]
    });
  }

  preview(files, artType: string) {
    if (files.length === 0) {
      return;
    }

    const mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = 'Only images are supported.';
      return;
    }

    const reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);

    if (artType === 'frontArt') {
      this.frontArtFile = files[0];
    } else if (artType === 'backArt') {
      this.backArtFile = files[0];
    }

    reader.onload = (_event) => {
      if (artType === 'frontArt') {
        this.frontArtUrl = reader.result;
      } else if (artType === 'backArt') {
        this.backArtUrl = reader.result;
      }
    };
  }

  deleteFrontArt() {
    this.frontArtUrl = '';
    this.artFormGroup.get('frontArt').setErrors({ 'frontArtMissing': true });
  }

  deleteBackArt() {
    this.backArtUrl = '';
    this.artFormGroup.get('backArt').setErrors({ 'backArtMissing': true });
  }

  onSelect($event: any, imageType: string) {
    this.imgSrc = [];
    switch (typeof ($event)) {
      case 'string':
        this.imgSrc = [$event];
        break;
      case 'object':
        this.imgSrc = $event;
        break;
      default:
    }
    this.validFrontImgSrc = this.imgSrc[0];
  }

  reset() {
    this.imgSrc = [];
  }

  scroll(el) {
    el.scrollIntoView();
  }

  openModal(template: TemplateRef<any>) {
    this.uploadedFrontImgSrcView = null;
    this.uploadedBackImgSrcView = null;
    const config = {
      animated: true,
      keyboard: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'modal-lg'
    };
    this.modalRef = this.modalService.show(template, config);
  }

  resetUpload() {
    this.modalRef.hide();
  }
}

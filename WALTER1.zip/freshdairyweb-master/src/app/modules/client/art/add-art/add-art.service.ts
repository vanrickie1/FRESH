import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ClientUploadArtInitialData, SaveArtResponse } from './add-art-request-response';


@Injectable({
  providedIn: 'root'
})
export class AddArtService {

  GET_INITIAL_DATA_URL = '/freshdairy/client/art/create/initialdata';
  SAVE_URL = '/freshdairy/client/art/create/save';

  constructor(private http: HttpClient) { }

  getInitialData(): Observable<ClientUploadArtInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: ClientUploadArtInitialData) => initialData));
  }

  save(saveArtRequestFormData: FormData):
    Observable<SaveArtResponse> {

    const httpOptions = {
      headers: new HttpHeaders({
      })
    };

    return this.http.post(this.SAVE_URL,
      saveArtRequestFormData, httpOptions).pipe(map(
        (response: SaveArtResponse) => response));
  }
}

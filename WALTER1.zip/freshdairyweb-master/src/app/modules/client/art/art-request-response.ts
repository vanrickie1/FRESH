export class ClientShowArtInitialData {

    public constructor(
        public artTransfers: ArtTransfer[]
    ) {

    }
}

export class ArtTransfer {

    public constructor(
        public id: number,
        public name: string,
        public note: string,
        public frontArtId: number,
        public qrcodeId: number,
    ) {

    }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ArtService } from './art.service';
import { Router } from '@angular/router';
import { ClientShowArtInitialData, ArtTransfer } from './art-request-response';
import { style, state, transition, animate, trigger } from '@angular/animations';
import { ImageService } from 'src/app/services/image/image.service';

@Component({
  selector: 'app-art',
  templateUrl: './art.component.html',
  styleUrls: ['./art.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '100px' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ArtComponent implements OnInit {

  displayedColumns: string[] = ['name', 'note', 'dropDown'];

  artData: MatTableDataSource<ArtTransfer>;
  artInitialData: ClientShowArtInitialData;
  artsExist: boolean;
  expandedElement: any;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(
    private artService: ArtService,
    public imageService: ImageService,
    private router: Router) {
  }

  ngOnInit() {
    this.getArtInitialData();
  }

  // Start Art initialdata setup
  private getArtInitialData() {
    this.artService.getInitialData().subscribe(data => {
      this.artInitialData = data;
      this.artData = new MatTableDataSource(this.artInitialData.artTransfers);
      this.artData.paginator = this.paginator;
      this.applyArtSorting();
      this.checkIfArtExists();
    });
  }

  getFrontArt(id: number) {
    return this.imageService.getFrontImagePath(id, 'front');
  }

  getQrcodeArt(id: number) {
    return this.imageService.getQrcodeImagePath(id, 'qrcode');
  }

  applyArtFilter(filterValue: string) {
    this.artData.filter = filterValue.trim().toLowerCase();
  }

  applyArtSorting() {
    this.artData.sort = this.sort;
  }

  addArt() {
    this.router.navigate(['/client/art/add']);
  }

  checkIfArtExists(): boolean {
    this.artsExist = false;
    if (this.artInitialData.artTransfers.length > 0) {
      this.artsExist = true;
    }
    return this.artsExist;
  }

  collapseRow(row: any) {
    if (!this.expandedElement) {
      this.expandedElement = row;
    } else {
      this.expandedElement = null;
    }
  }
  // End Art initialdata setup
}

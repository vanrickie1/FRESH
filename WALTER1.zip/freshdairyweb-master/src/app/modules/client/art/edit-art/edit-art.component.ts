import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-art',
  templateUrl: './edit-art.component.html',
  styleUrls: ['./edit-art.component.css']
})
export class EditArtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ClientShowListInitialData } from './list-request-response';

@Injectable({
  providedIn: 'root'
})
export class ListService {

  GET_INITIAL_DATA_URL = '/freshdairy/client/campaign/list/show/initialdata';
  constructor(private http: HttpClient) { }

  getInitialData(): Observable<ClientShowListInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: ClientShowListInitialData) => initialData));
  }

}

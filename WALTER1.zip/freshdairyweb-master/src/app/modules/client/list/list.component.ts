import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { ListService } from './list.service';
import { Router } from '@angular/router';
import { ClientShowListInitialData, ListTransfer } from './list-request-response';
import { style, state, transition, animate, trigger } from '@angular/animations';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ListComponent implements OnInit {

  displayedColumns: string[] = ['name', 'description', 'dropDown'];

  listData: MatTableDataSource<ListTransfer>;
  listInitialData: ClientShowListInitialData;
  listsExist: boolean;
  expandedElement: any;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(
    private listService: ListService,
    private router: Router) {
  }

  ngOnInit() {
    this.getListInitialData();
  }

  // Stlist List initialdata setup
  private getListInitialData() {
    this.listService.getInitialData().subscribe(data => {
      this.listInitialData = data;
      this.listData = new MatTableDataSource(this.listInitialData.listTransfers);
      this.listData.paginator = this.paginator;
      this.applyListSorting();
      this.checkIfListsExists();
    });
  }

  applyListFilter(filterValue: string) {
    this.listData.filter = filterValue.trim().toLowerCase();
  }

  applyListSorting() {
    this.listData.sort = this.sort;
  }

  addList() {
    this.router.navigate(['/client/list/add']);
  }

  checkIfListsExists(): boolean {
    this.listsExist = false;
    if (this.listInitialData.listTransfers.length > 0) {
      this.listsExist = true;
    }
    return this.listsExist;
  }

  collapseRow(row: any) {
    if (!this.expandedElement) {
      this.expandedElement = row;
    } else {
      this.expandedElement = null;
    }
  }
  // End List initialdata setup

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {
  AppErrorStateMatcherComponent
} from 'src/app/validators/app-error-state-matcher/app-error-state-matcher.component';
import {
  ClientCreateCampaignListInitialData, SaveMailAddressResponse,
  ClientCreateCampaignListRequest
} from './add-list-request-response';
import { AddListService } from './add-list.service';
import { HomeService } from '../../home/home.service';

@Component({
  selector: 'app-add-list',
  templateUrl: './add-list.component.html',
  styleUrls: ['./add-list.component.css']
})
export class AddListComponent implements OnInit {

  selectedQuoteType: number;
  listFormGroup: FormGroup;
  initialData: ClientCreateCampaignListInitialData;
  response: SaveMailAddressResponse;
  list: File;
  matcher = new AppErrorStateMatcherComponent();
  selectedZipId: number = Number(999);
  numberOfAddresses: number;

  createFormGroup() {
    this.listFormGroup = this.formBuilder.group({
      listName: ['', Validators.required],
      description: [],
      csv: ['', Validators.required],
      quoteType: ['', Validators.required]
    }
    );
  }

  constructor(private addListService: AddListService,
    private router: Router,
    private snackBar: MatSnackBar,
    private homeService: HomeService,
    private formBuilder: FormBuilder) {
    this.createFormGroup();
    // Set tab to navigate too
    this.homeService.selectedTabIndex = 2;
  }

  ngOnInit() {
    this.selectedQuoteType = 1;
    this.getInitialData();
  }

  private getInitialData() {
    this.addListService.getInitialData().subscribe(data => {
      this.initialData = data;
    });
  }

  public onSubmit() {
    const name = this.listFormGroup.get('listName').value;
    const description = this.listFormGroup.get('description').value;
    const quoteId = this.listFormGroup.get('quoteType').value;

    const clientCreateCampaignListRequest =
      new ClientCreateCampaignListRequest(name, description, quoteId);

    const saveListRequestFormData = new FormData();

    saveListRequestFormData.append('clientCreateCampaignListRequest',
      new Blob([JSON.stringify(clientCreateCampaignListRequest)], {
        type: 'application/json'
      }));

    if (this.list) {
      saveListRequestFormData.append('mailAddressCsvFile',
        this.list, this.list.name);
    }

    if (this.listFormGroup.valid) {

      this.addListService.save(saveListRequestFormData).subscribe(
        (response: SaveMailAddressResponse) => {
          this.response = response;
          if (response.saved) {
            this.openSnackBar('Successfully saved list', 'X');
            this.router.navigate(['/client/home']);
          } else {
          }
        }
      );
    }
  }

  setCsv(files) {
    if (files.length === 0) {
      return;
    }
    const reader = new FileReader();
    this.list = files;
    reader.readAsDataURL(files[0]);
    this.list = files[0];
  }

  openSnackBar(message: string, panelClass: string) {
    this.snackBar.open(message, panelClass, {
      duration: 5000,
      verticalPosition: 'top',
      panelClass: ['green-snackbar']
    });
  }

  scroll(el) {
    el.scrollIntoView();
  }
}

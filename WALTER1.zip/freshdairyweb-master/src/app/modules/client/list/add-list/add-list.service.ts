import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ClientCreateCampaignListInitialData, SaveMailAddressResponse } from './add-list-request-response';


@Injectable({
  providedIn: 'root'
})
export class AddListService {

  GET_INITIAL_DATA_URL = '/freshdairy/client/campaign/list/initialdata';
  SAVE_URL = '/freshdairy/client/campaign/list/upload/csv';

  constructor(private http: HttpClient) { }

  getInitialData(): Observable<ClientCreateCampaignListInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: ClientCreateCampaignListInitialData) => initialData));
  }

  save(saveListRequestFormData: FormData):
    Observable<SaveMailAddressResponse> {

    const httpOptions = {
      headers: new HttpHeaders({
      })
    };

    return this.http.post(this.SAVE_URL,
      saveListRequestFormData, httpOptions).pipe(map(
        (response: SaveMailAddressResponse) => response));
  }
}

export class ClientCreateCampaignListInitialData {

    public constructor(
        public stateTransfer: StateTransfer,
        public zipTransfers: ZipTransfer[],
        public filterTransfer: FilterTransfer,
        public quoteTypeTransfers: QuoteTypeTransfer[],
        public mailoutUnitCost: number
    ) {

    }
}

export class StateTransfer {

    public constructor(
        public id: number,
        public name: string
    ) {

    }
}

export class ZipTransfer {

    public constructor(
        public zip: string,
        public stateId: number
    ) {

    }
}

export class FilterTransfer {

    public constructor(
        public householdSizeTransfers: HouseholdSizeTransfer[],
        public incomeRangeTransfers: IncomeRangeTransfer[]
    ) {

    }
}


export class QuoteTypeTransfer {

    public constructor(
        public id: number,
        public quote: string
    ) {

    }
}

export class HouseholdSizeTransfer {
    public constructor(
        public id: string,
        public name: number
    ) {

    }
}


export class IncomeRangeTransfer {
    public constructor(
        public id: string,
        public name: number
    ) {

    }
}

export class ClientCreateCampaignListRequest {
    public constructor(
        public name: string,
        public description: number,
        public quoteId: number
    ) {

    }
}

export class SaveMailAddressResponse {

    public constructor(
        public saved: boolean,
        public formatError: string
    ) {

    }
}


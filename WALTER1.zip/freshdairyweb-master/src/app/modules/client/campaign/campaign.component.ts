import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { CampaignService } from './campaign.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ParentService } from 'src/app/parent/parent.service';
import { CampaignTransfer, ClientShowCustomerInitialData, CustomerTransfer } from './campaign-request-response';
import { Router } from '@angular/router';
import { style, state, transition, animate, trigger } from '@angular/animations';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CampaignComponent implements OnInit {

  displayedColumns: string[] = ['receiptNumber', 'productScanned', 'firstName', 'lastName', 'outlet',
    'location', 'phoneNumber'];

  customerInitialData: ClientShowCustomerInitialData;
  customerData: MatTableDataSource<CustomerTransfer>;
  campaignsExist: boolean;
  expandedElement: any;
  modalRef: BsModalRef;

  // Modal Attributes
  modalCampaignName: string;
  modalArtName: string;
  modalListName: string;
  modalCampaignType: string;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(
    private campaignService: CampaignService,
    private router: Router,
    private modalService: BsModalService,
    private parentService: ParentService) {
    this.parentService.hidePublicHeader = true;
    this.parentService.hidePrivateHeader = false;
  }

  ngOnInit() {
    this.getCampaignInitialData();
  }

  // Start Campaign initialdata setup
  private getCampaignInitialData() {
    this.campaignService.getInitialData().subscribe(data => {
      this.customerInitialData = data;
      this.customerData = new MatTableDataSource(this.customerInitialData.customerTransfers);
      this.customerData.paginator = this.paginator;
      this.applyCampaignSorting();
      this.checkIfCustomerExists();
    });
  }

  applyCampaignFilter(filterValue: string) {
    this.customerData.filter = filterValue.trim().toLowerCase();
  }

  applyCampaignSorting() {
    this.customerData.sort = this.sort;
  }

  addCampaign() {
    this.router.navigate(['/client/campaign/add']);
  }

  checkIfCustomerExists(): boolean {
    this.campaignsExist = false;
    if (this.customerInitialData.customerTransfers.length > 0) {
      this.campaignsExist = true;
    }
    return this.campaignsExist;
  }

  collapseRow(row: any) {
    if (!this.expandedElement) {
      this.expandedElement = row;
    } else {
      this.expandedElement = null;
    }
  }

  openModal(template: TemplateRef<any>, campaignName: string,
    artName: string, listName: string, campaignType: string) {
    this.setModalValues(campaignName, artName, listName, campaignType);
    const config = {
      animated: true,
      keyboard: true,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'modal-md'
    };
    this.modalRef = this.modalService.show(template, config);
  }

  setModalValues(campaignName: string,
    artName: string, listName: string, campaignType: string) {
    artName = 'No Art';
    listName = 'No List';
    this.modalCampaignName = campaignName;
    this.modalArtName = artName;
    this.modalListName = listName;
    this.modalCampaignType = campaignType;
  }
  // End Campaign initialdata setup
}

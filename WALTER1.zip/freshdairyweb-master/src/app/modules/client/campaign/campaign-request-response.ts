export class ClientShowCampaignInitialData {

    public constructor(
        public campaignTransfers: CampaignTransfer[]
    ) {

    }
}

export class CampaignTransfer {

    public constructor(
        public campaignId: number,
        public campaignName: string,
        public campaignActivated: boolean,
        public campaignConfigured: boolean,
        public hasList: boolean,
        public numberArt: number,
        public campaignType: string
    ) {

    }
}

export class ClientShowCustomerInitialData {

    public constructor(
        public customerTransfers: CustomerTransfer[]
    ) {

    }
}

export class CustomerTransfer {

    public constructor(
        public id: number,
        public firstName: string,
        public lastName: string,
        public outlet: string,
        public location: string,
        public phoneNumber: string,
        public productScanned: string,
        public receiptNumber: string
    ) {

    }
}

import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import {
  AppErrorStateMatcherComponent
} from 'src/app/validators/app-error-state-matcher/app-error-state-matcher.component';
import { Router } from '@angular/router';
import { AddCampaginService } from './add-campagin.service';
import {
  ClientCreateCampaignInitialData, SaveResponse,
  CreateCampaignRequest
} from './add-campagin-request-response';
import { MatSnackBar } from '@angular/material';
import { HomeService } from '../../home/home.service';

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.scss']
})
export class AddCampaignComponent implements OnInit {
  campaignFormGroup: FormGroup;
  initialData: ClientCreateCampaignInitialData;
  response: SaveResponse;
  matcher = new AppErrorStateMatcherComponent();

  createFormGroup() {
    this.campaignFormGroup = this.formBuilder.group({
      campaignName: ['', Validators.required],
      campaignType: ['', Validators.required]
    }
    );
  }

  constructor(private addCampaginService: AddCampaginService,
    private router: Router,
    private snackBar: MatSnackBar,
    private homeService: HomeService,
    private formBuilder: FormBuilder) {
    this.createFormGroup();
    // Set tab to navigate too
    this.homeService.selectedTabIndex = 0;
  }

  ngOnInit() {
    this.getInitialData();
  }

  private getInitialData() {
    this.addCampaginService.getInitialData().subscribe(data => {
      this.initialData = data;
    });
  }

  public onSubmit() {
    const campaignName = this.campaignFormGroup.get('campaignName').value;
    const campaignType = this.campaignFormGroup.get('campaignType').value;

    if (this.campaignFormGroup.valid) {

      const createCampaignRequest: CreateCampaignRequest =
        new CreateCampaignRequest(campaignType, campaignName);

      this.addCampaginService.save(createCampaignRequest).subscribe(
        (response: SaveResponse) => {
          this.response = response;
          if (response.saved) {
            this.openSnackBar('Successfully saved campaign', 'X');
            this.router.navigate(['/client/home']);
          } else {
          }
        }
      );
    }
  }

  openSnackBar(message: string, panelClass: string) {
    this.snackBar.open(message, panelClass, {
      duration: 5000,
      verticalPosition: 'top',
      panelClass: ['green-snackbar']
    });
  }

  scroll(el) {
    el.scrollIntoView();
  }
}

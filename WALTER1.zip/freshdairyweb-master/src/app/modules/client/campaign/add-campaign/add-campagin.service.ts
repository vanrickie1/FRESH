import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ClientCreateCampaignInitialData, SaveResponse, CreateCampaignRequest } from './add-campagin-request-response';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class AddCampaginService {

  GET_INITIAL_DATA_URL = '/freshdairy/client/campaign/create/initialdata';
  SAVE_URL = '/freshdairy/client/campaign/create/save';

  constructor(private http: HttpClient) { }

  getInitialData(): Observable<ClientCreateCampaignInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (initialData: ClientCreateCampaignInitialData) => initialData));
  }

  save(addJobPostingRequest: CreateCampaignRequest):
    Observable<SaveResponse> {

    const httpOptions = {
      headers: new HttpHeaders({
      })
    };

    return this.http.post(this.SAVE_URL,
      addJobPostingRequest, httpOptions).pipe(map(
        (response: SaveResponse) => response));
  }
}

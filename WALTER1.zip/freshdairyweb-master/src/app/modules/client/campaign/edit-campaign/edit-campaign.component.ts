import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-campaign',
  templateUrl: './edit-campaign.component.html',
  styleUrls: ['./edit-campaign.component.css']
})
export class EditCampaignComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

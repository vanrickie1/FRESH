export class ClientCreateCampaignInitialData {

    public constructor(
        public campaignFrequencyTypeTransfers: CampaignFrequencyTypeTransfer[]
    ) {

    }
}

export class CampaignFrequencyTypeTransfer {

    public constructor(
        public campaignFrequencyTypeId: number,
        public name: string
    ) {

    }
}

export class CreateCampaignRequest {

    public constructor(
        public campaignFrequencyTypeId: number,
        public campaignName: string
    ) {

    }
}

export class SaveResponse {

    public constructor(
        public saved: boolean,
        public error: string
    ) {

    }
}


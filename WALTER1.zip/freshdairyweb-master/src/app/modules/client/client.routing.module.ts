import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { ClientdashboardComponent } from './dashboard/clientdashboard.component';
import { HomeComponent } from './home/home.component';
import { HasPermissionGuard } from 'src/app/guards/haspermission-guard';
import { AddCampaignComponent } from './campaign/add-campaign/add-campaign.component';
import { EditCampaignComponent } from './campaign/edit-campaign/edit-campaign.component';
import { AddArtComponent } from './art/add-art/add-art.component';
import { EditArtComponent } from './art/edit-art/edit-art.component';
import { AddListComponent } from './list/add-list/add-list.component';
import { EditListComponent } from './list/edit-list/edit-list.component';

const orgRoutes: Routes = [
  {
    path: 'dashboard', component: ClientdashboardComponent
  },
  {
    path: 'home', component: HomeComponent,
    canActivate: [HasPermissionGuard], data: {
      authorities: ['CLIENT']
    }
  },
  {
    path: 'home/:demo', component: HomeComponent,
    canActivate: [HasPermissionGuard], data: {
      authorities: ['CLIENT']
    }
  },
  {
    path: 'campaign', children: [
      {
        path: 'add', component: AddCampaignComponent,
        canActivate: [HasPermissionGuard], data: {
          authorities: ['CLIENT']
        }
      },
      {
        path: 'edit/:campaignId', component: EditCampaignComponent,
        canActivate: [HasPermissionGuard], data: {
          authorities: ['CLIENT']
        }
      },
    ],
  },
  {
    path: 'art', children: [
      {
        path: 'add', component: AddArtComponent,
        canActivate: [HasPermissionGuard], data: {
          authorities: ['CLIENT']
        }
      },
      {
        path: 'edit/:artId', component: EditArtComponent,
        canActivate: [HasPermissionGuard], data: {
          authorities: ['CLIENT']
        }
      },
    ],
  },
  {
    path: 'list', children: [
      {
        path: 'add', component: AddListComponent,
        canActivate: [HasPermissionGuard], data: {
          authorities: ['CLIENT']
        }
      },
      {
        path: 'edit/:listId', component: EditListComponent,
        canActivate: [HasPermissionGuard], data: {
          authorities: ['CLIENT']
        }
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(orgRoutes),
    DeviceDetectorModule.forRoot()
  ],
  exports: [
    RouterModule,
  ]
})
export class ClientroutingModule {

}

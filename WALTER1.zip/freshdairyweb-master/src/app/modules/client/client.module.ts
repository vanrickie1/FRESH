import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { ClientdashboardComponent } from './dashboard/clientdashboard.component';
import { ClientroutingModule } from './client.routing.module';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { HomeComponent } from './home/home.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CampaignComponent } from './campaign/campaign.component';
import { ArtComponent } from './art/art.component';
import { ListComponent } from './list/list.component';
import { AddCampaignComponent } from './campaign/add-campaign/add-campaign.component';
import { EditCampaignComponent } from './campaign/edit-campaign/edit-campaign.component';
import { EditArtComponent } from './art/edit-art/edit-art.component';
import { AddArtComponent } from './art/add-art/add-art.component';
import { AddListComponent } from './list/add-list/add-list.component';
import { EditListComponent } from './list/edit-list/edit-list.component';
import { NgxImgModule } from 'ngx-img';
import { TooltipModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    TranslateModule.forChild(),
    TabsModule.forRoot(),
    TooltipModule.forRoot(),
    MatTableModule,
    MatPaginatorModule,
    FlexLayoutModule,
    ClientroutingModule,
    NgxImgModule.forRoot(),
    SharedModule
  ],
  declarations: [
    ClientdashboardComponent,
    HomeComponent,
    CampaignComponent,
    ArtComponent,
    ListComponent,
    AddCampaignComponent,
    EditCampaignComponent,
    EditArtComponent,
    AddArtComponent,
    AddListComponent,
    EditListComponent,
  ],
  providers: []
})
export class ClientModule { }

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { TranslateModule } from '@ngx-translate/core';
import { TabsModule } from 'ngx-bootstrap/tabs';

import { SharedModule } from '../shared/shared.module';
import { SuperadmindashboardComponent } from './dashboard/superadmindashboard.component';
import { AddadminComponent } from './applicant/admin/add/addadmin.component';
import { EditadminComponent } from './applicant/admin/edit/editadmin.component';
import { SelectadminComponent } from './applicant/admin/select/selectadmin.component';
import { SuperadmineditmyaccountComponent } from './myaccount/edit/editmyaccount.component';
import { SuperadminroutingModule } from './superadmin.routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SuperadminroutingModule,
    TranslateModule.forChild(),
    TabsModule,
    SharedModule,
    NgSelectModule
  ],
  declarations: [SuperadmindashboardComponent,
    AddadminComponent,
    SelectadminComponent, EditadminComponent, SuperadmineditmyaccountComponent],

  providers: []
})
export class SuperadminModule { }

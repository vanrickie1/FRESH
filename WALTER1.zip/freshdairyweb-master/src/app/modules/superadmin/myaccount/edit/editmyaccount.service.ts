import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import {
  SuperAdminEditMyAccountInitialData,
  SuperAdminMyAccountEditResponse,
  SuperAdminEditMyAccountPersonalDetailsRequest,
  SuperAdminEditMyEmailAndPasswordRequest,
} from './editmyaccount-request-response';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class SuperadmineditmyaccountService {
  EDIT_MY_ACCOUNT_GET_INITIAL_DATA_URL = '/freshdairy/superadmin/myaccount/getinitialdata';
  EDIT_MY_PERSONAL_DETAILS_ACCOUNT_URL = '/freshdairy/superadmin/myaccount/editmyaccount/personal_details';
  EDIT_MY_EMAIL_AND_PASSWORD_ACCOUNT_URL = '/freshdairy/superadmin/myaccount/editmyaccount/email_and_password';

  constructor(private http: HttpClient) {

  }

  getInitialData(): Observable<SuperAdminEditMyAccountInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    return this.http.post(
      this.EDIT_MY_ACCOUNT_GET_INITIAL_DATA_URL, httpOptions).pipe(map(
        (response: SuperAdminEditMyAccountInitialData) => {
          return response;
        }
      ));
  }


  editMyPersonalDetails(superAdminEditMyAccountPersonalDetailsRequest: SuperAdminEditMyAccountPersonalDetailsRequest):
    Observable<SuperAdminMyAccountEditResponse> {
    const body = JSON.stringify(superAdminEditMyAccountPersonalDetailsRequest);

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.EDIT_MY_PERSONAL_DETAILS_ACCOUNT_URL, body, httpOptions).pipe(map(
        (response: SuperAdminMyAccountEditResponse) => {
          return response;
        }
      ));
  }

  editMyEmailAndPassword(superAdminEditMyEmailAndPasswordRequest: SuperAdminEditMyEmailAndPasswordRequest):
    Observable<SuperAdminMyAccountEditResponse> {
    const body = JSON.stringify(superAdminEditMyEmailAndPasswordRequest);

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.EDIT_MY_EMAIL_AND_PASSWORD_ACCOUNT_URL, body, httpOptions).pipe(map(
        (response: SuperAdminMyAccountEditResponse) => {
          return response;
        }
      ));
  }
}

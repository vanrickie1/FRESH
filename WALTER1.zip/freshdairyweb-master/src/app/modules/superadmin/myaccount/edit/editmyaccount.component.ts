import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SuperadmineditmyaccountService } from './editmyaccount.service';
import { UserService } from '../../../../services/user/user.service';
import {
  SuperAdminEditMyAccountInitialData,
  SuperAdminMyAccountEditResponse,
  SuperAdminEditMyAccountPersonalDetailsRequest,
  SuperAdminEditMyEmailAndPasswordRequest,
} from './editmyaccount-request-response';
import { ConfigService } from '../../../../services/config/config.service';
import { environment } from '../../../../../environments/environment';


@Component({
  selector: 'app-editmyaccount',
  templateUrl: './editmyaccount.component.html'
})

export class SuperadmineditmyaccountComponent implements OnInit {

  error;
  status;
  superAdminEditMyAccountInitialData: SuperAdminEditMyAccountInitialData;
  organisationName: string;
  dashboardUrl: string;
  userId: number;
  invalidPasswordMatch: boolean;
  emailAlreadyExists: boolean;
  notSaved: boolean;
  saved: boolean;
  debug: boolean;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private superAdmineditmyaccountService: SuperadmineditmyaccountService,
    public configService: ConfigService) {
  }

  ngOnInit() {
    const email = this.userService.loggedInUsername;
    this.superAdmineditmyaccountService.getInitialData().subscribe(
      (superAdminEditMyAccountInitialData: SuperAdminEditMyAccountInitialData) => {
        this.superAdminEditMyAccountInitialData = superAdminEditMyAccountInitialData;
        this.userId = superAdminEditMyAccountInitialData.user.userId;
        console.log('user id =' + this.userId);
      },
    );
    this.debug = environment.debug;
  }

  // saves edit
  // onSubmitPersonalDetails(form: NgForm) {
  //   const firstname = form.value['firstName'];
  //   const lastname = form.value['lastName'];
  //   const superAdminEditMyAccountPersonalDetailsRequest =
  //     new SuperAdminEditMyAccountPersonalDetailsRequest(this.userId, firstname, lastname);

  //   this.superAdmineditmyaccountService.editMyPersonalDetails(superAdminEditMyAccountPersonalDetailsRequest).subscribe(
  //     (response: SuperAdminMyAccountEditResponse) => {
  //       if (response.saved) {
  //         this.successSaved();
  //       } else {
  //         this.errorEmailExistsAlready();
  //       }
  //     }
  //   );
  // }

  // private successSaved(): void {
  //   this.saved = true;
  //   this.notSaved = false;
  //   this.invalidPasswordMatch = false;
  //   this.emailAlreadyExists = false;
  // }

  // private errorEmailExistsAlready(): void {
  //   this.saved = false;
  //   this.notSaved = true;
  //   this.emailAlreadyExists = true;
  //   this.invalidPasswordMatch = false;
  // }

  // userAlreadyExists() {
  //   this.saved = false;
  //   this.notSaved = true;
  //   this.emailAlreadyExists = true;
  //   this.invalidPasswordMatch = false;
  // }

  // invalidPassword() {
  //   this.saved = false;
  //   this.notSaved = true;
  //   this.invalidPasswordMatch = true;
  //   this.emailAlreadyExists = false;
  // }

  // onSubmitEmailAndPassword(form: NgForm) {
  //   const email = form.value['email'];
  //   const currentPassword = form.value['currentPassword'];
  //   const password = form.value['password'];

  //   const superAdminEditMyEmailAndPasswordRequest =
  //     new SuperAdminEditMyEmailAndPasswordRequest(email, currentPassword, password);

  //   this.superAdmineditmyaccountService.editMyEmailAndPassword(superAdminEditMyEmailAndPasswordRequest).subscribe(
  //     (response: SuperAdminMyAccountEditResponse) => {
  //       if (response.saved) {
  //         this.successSaved();
  //       } else if (response.error === 'email') {
  //         this.userAlreadyExists();
  //       } else if (response.error === 'password') {
  //         this.invalidPassword();
  //       }
  //     }
  //   );
  // }

  updateStatusAndError() {
    this.status = '';
    this.error = '';
  }

  navigateBack() {
    this.router.navigate([this.dashboardUrl]);
  }

}


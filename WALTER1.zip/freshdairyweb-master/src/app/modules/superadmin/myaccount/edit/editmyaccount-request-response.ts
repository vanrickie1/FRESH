
export class UserTransfer {
  public constructor(public userId: number,
      public firstName: string,
      public lastName: string,
      public fullName: string,
      public mobile: string,
      public email: string) {

  }
}

export class SuperAdminEditMyAccountInitialData {

  public constructor(
      public user: UserTransfer) {

  }
}


export class SuperAdminMyAccountEditResponse {
  public constructor(public saved: boolean, public error: string) {

  }
}


export class SuperAdminEditMyAccountPersonalDetailsRequest {

  public constructor(
      public userId: number,
      public firstName: string,
      public lastName: string) {

  }
}

export class SuperAdminEditMyEmailAndPasswordRequest {

  public constructor(
      public email: string,
      public currentPassword: string,
      public password: string) {

  }
}


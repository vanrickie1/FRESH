import { NgModule } from '@angular/core';

import { HasPermissionGuard } from '../../guards/haspermission-guard';
import { SuperadmindashboardComponent } from './dashboard/superadmindashboard.component';
import { AddadminComponent } from './applicant/admin/add/addadmin.component';
import { EditadminComponent } from './applicant/admin/edit/editadmin.component';
import { SelectadminComponent } from './applicant/admin/select/selectadmin.component';
import { SuperadmineditmyaccountComponent } from './myaccount/edit/editmyaccount.component';
import { Routes, RouterModule } from '@angular/router';

const orgRoutes: Routes = [
  {
    path: 'dashboard',
    component: SuperadmindashboardComponent,
    canActivate: [HasPermissionGuard],
    data: { authorities: ['ACCESS_SUPER_ADMIN'] }
  },
  {
    path: 'applicant', children: [
      {
        path: 'admin', children: [
          {
            path: 'select/:organisationId',
            component: SelectadminComponent,
            canActivate: [HasPermissionGuard],
            data: { authorities: ['ACCESS_SUPER_ADMIN'] },
            runGuardsAndResolvers: 'always'
          },
          {
            path: 'add/:organisationId',
            component: AddadminComponent,
            canActivate: [HasPermissionGuard],
            data: { authorities: ['ACCESS_SUPER_ADMIN'] },
          },
          {
            path: 'edit/:applicantId',
            component: EditadminComponent,
            canActivate: [HasPermissionGuard],
            data: { authorities: ['ACCESS_SUPER_ADMIN'] },
          },
        ]
      },
    ]
  },
  {
    path: 'myaccount', children: [
      {
        path: 'edit',
        component: SuperadmineditmyaccountComponent,
        canActivate: [HasPermissionGuard],
        data: { authorities: ['ACCESS_SUPER_ADMIN'] }
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(orgRoutes),
  ],
  exports: [
    RouterModule,
  ]
})
export class SuperadminroutingModule {

}

import { Injectable } from '@angular/core';
import {
  EditAdminInitialData,
  EditAdminRequest,
  EditAdminSaveResponse
} from './editadmin-request-response';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';

@Injectable({
  providedIn: 'root'
})
export class EditadminService {

  EDIT_ADMIN_GET_INITIAL_DATA_URL =
    '/freshdairy/superadmin/applicant/admin/edit/getinitialdata';

  SAVE_ADMIN_URL = '/freshdairy/superadmin/applicant/admin/edit/save';

  constructor(private http: HttpClient) {

  }


  getInitialData(adminApplicantId: number): Observable<EditAdminInitialData> {
    const body = JSON.stringify(adminApplicantId);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.EDIT_ADMIN_GET_INITIAL_DATA_URL, body, httpOptions).pipe(map(
        (response: EditAdminInitialData) => {
          return response;
        }
      ));
  }


  save(editAdminRequest: EditAdminRequest): Observable<EditAdminSaveResponse> {
    const httpOptions = {};

    return this.http.post(this.SAVE_ADMIN_URL,
      editAdminRequest, httpOptions).pipe(map(
        (response: EditAdminSaveResponse) => {
          return response;
        }
      ));
  }
}

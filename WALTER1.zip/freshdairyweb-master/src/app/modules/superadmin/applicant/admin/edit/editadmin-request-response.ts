
export class EditAdminRequest {
  public constructor( public firstName: string,
    public lastName: string, public password: string, public email: string,
      public phone: string, public adminApplicantId: number, public active: boolean) {

  }
}

export class EditAdminSaveResponse {

  public constructor(public saved: boolean, public error: string) {

  }
}

export class EditAdminInitialData {
  public constructor( public firstName: string, public lastName: string,
      public password: string, public email: string, public phone: string,
          public adminApplicantId: number, public organisationId: number,
            public active: boolean ) {

  }
}

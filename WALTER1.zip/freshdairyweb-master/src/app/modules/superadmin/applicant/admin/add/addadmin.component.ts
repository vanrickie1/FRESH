import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AddadminService } from './addadmin.service';
import { AddAdminRequest, AddAdminSaveResponse } from './addadmin-request-response';

@Component({
  selector: 'app-addadmin',
  templateUrl: './addadmin.component.html',
  styleUrls: ['./addadmin.component.css']
})
export class AddadminComponent implements OnInit {

  organisationId: Number;
  saved = false;
  error;

  constructor(private addadminService: AddadminService,
      private activatedRoute: ActivatedRoute) {

  }

  ngOnInit() {
    this.organisationId = Number(
      this.activatedRoute.snapshot.paramMap.get('organisationId'));
  }

  private successSaved(): void {
    this.saved = true;
  }

  scroll(el) {
    this.saved = false;
    el.scrollIntoView();
  }

  onSubmit(form: NgForm) {
    const organisationId = Number(this.organisationId);
    const firstName = form.controls['firstName'].value;
    const lastName = form.controls['lastName'].value;
    const password = form.controls['password'].value;
    const email = form.controls['email'].value;
    const phone = form.controls['phone'].value;

    const addAdminRequest: AddAdminRequest =
        new AddAdminRequest(email, firstName, lastName, password,  phone,
            organisationId);

    this.addadminService.save(addAdminRequest).subscribe(
      (response: AddAdminSaveResponse) => {
        this.successSaved();
      }
    );
  }
}

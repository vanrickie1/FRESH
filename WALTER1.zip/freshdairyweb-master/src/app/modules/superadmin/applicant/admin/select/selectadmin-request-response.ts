
export class Admin {

  public constructor(
    public id: number,
    public name: string,
    public email: string) {

  }
}

export class SuperAdminAdminInitialData {

  public constructor(
    public admins: Admin[]
  ) {

  }
}

export class AdminDeleteResponse {

  public constructor(
    public deleted: boolean,
    public error: string
  ) {

  }
}

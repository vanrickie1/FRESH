import { Component, OnInit, ViewChild, TemplateRef, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { SelectadminService } from './selectadmin.service';
import { SuperAdminAdminInitialData, AdminDeleteResponse } from './selectadmin-request-response';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

@Component({
  selector: 'app-selectorgadmin',
  templateUrl: './selectadmin.component.html',
  styleUrls: ['./selectadmin.component.css']
})
export class SelectadminComponent implements OnInit, OnDestroy {

  organisationId: number;
  superAdminAdminInitialData: SuperAdminAdminInitialData;
  modalRef: BsModalRef;
  message: string;
  adminApplicantIdToDelete: number;
  canNotDelete: Boolean;
  // cancelledDelete: boolean;
  navigationSubscription;


  constructor(private activatedRoute: ActivatedRoute,
    private selectAdminService: SelectadminService,
    private modalService: BsModalService,
    private router: Router) {

    // https://medium.com/engineering-on-the-incline/reloading-current-route-on-click-angular-5-1a1bfc740ab2
    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        if (this.organisationId !== undefined) {
          this.getAdminsInitialData(this.organisationId);
        }
      }
    });
  }

  private getAdminsInitialData(organisationId: number): void {
    this.selectAdminService.getInitialData(organisationId).subscribe(
      (superAdminAdminInitialData: SuperAdminAdminInitialData) => {
        this.superAdminAdminInitialData = superAdminAdminInitialData;
      },
    );
  }

  private forwardToSelectAdmin(): void {
    const url = '/superadmin/applicant/admin/select/' + this.organisationId;
    this.router.navigate([url]);
  }

  ngOnInit() {
    this.organisationId = Number(this.activatedRoute.snapshot.paramMap.get('organisationId'));
    this.getAdminsInitialData(this.organisationId);
  }

  ngOnDestroy() {
    // avoid memory leaks here by cleaning up after ourselves. If we
    // don't then we will continue to run our initialiseInvites()
    // method on every navigationEnd event.
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  deleteConfirmation(template: TemplateRef<any>, adminApplicantId) {
    this.adminApplicantIdToDelete = adminApplicantId;
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  scroll(el) {
    this.canNotDelete = false;
    el.scrollIntoView();
  }

  confirm() {
    this.selectAdminService.delete(this.adminApplicantIdToDelete).subscribe(
      (adminDeleteResponse: AdminDeleteResponse) => {
        if (adminDeleteResponse.deleted) {
          this.forwardToSelectAdmin();
        } else {
          this.canNotDelete = true;
        }
      }
    );

    this.modalRef.hide();
  }

  decline() {
    this.modalRef.hide();
  }
}

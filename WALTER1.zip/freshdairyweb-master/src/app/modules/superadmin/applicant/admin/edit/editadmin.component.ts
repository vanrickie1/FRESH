import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EditadminService } from './editadmin.service';
import { EditAdminRequest, EditAdminInitialData, EditAdminSaveResponse } from './editadmin-request-response';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-editorgadmin',
  templateUrl: './editadmin.component.html',
  styleUrls: ['./editadmin.component.css']
})
export class EditadminComponent implements OnInit {

  organisationId: number;
  adminApplicantId: number;
  editAdminInitialData: EditAdminInitialData;
  saved: boolean;
  emailThatIsUsedAlready: string;
  emailExistsAlready: boolean;

  constructor(private activatedRoute: ActivatedRoute,
      private editadminService: EditadminService) {

  }

  ngOnInit() {
    this.adminApplicantId =
        Number(this.activatedRoute.snapshot.paramMap.get('applicantId'));

    this.editadminService.getInitialData(this.adminApplicantId).subscribe(
      (editAdminInitialData: EditAdminInitialData) => {
        this.editAdminInitialData = editAdminInitialData;
        this.organisationId = editAdminInitialData.organisationId;
      }
    );

    this.emailExistsAlready = false;
  }

  scroll(el) {
    this.saved = false;
    this.emailExistsAlready = false;
    this.emailThatIsUsedAlready = undefined;
    el.scrollIntoView();
  }

  private successSaved(): void {
    this.saved = true;
    this.emailExistsAlready = false;
  }

  private errorEmailExistsAlready(): void {
    this.saved = true;
    this.emailExistsAlready = true;
  }

  onSubmit(form: NgForm) {
    const firstName = form.controls['firstName'].value;
    const lastName = form.controls['lastName'].value;
    const password = form.controls['password'].value;
    const email = form.controls['email'].value;
    const phone = form.controls['phone'].value;
    const adminApplicantId = Number(this.adminApplicantId);
    const active = form.controls['active'].value;
    this.emailThatIsUsedAlready = email;


    const editAdminRequest: EditAdminRequest =
        new EditAdminRequest(firstName, lastName, password, email, phone,
          adminApplicantId, active);

    this.editadminService.save(editAdminRequest).subscribe(
      (response: EditAdminSaveResponse) => {
        if ( response.saved ) {
          this.successSaved();
        } else {
          this.errorEmailExistsAlready();
        }
      }
    );
  }
}

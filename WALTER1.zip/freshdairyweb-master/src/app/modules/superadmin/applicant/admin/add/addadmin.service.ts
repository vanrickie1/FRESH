import { Injectable } from '@angular/core';
import {
  AddAdminRequest,
  AddAdminSaveResponse,
  SaveResponse
} from './addadmin-request-response';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AddadminService {

  private ADD_ADMIN_URL = '/freshdairy/superadmin/applicant/admin/add/save';

  constructor(private http: HttpClient) {

  }

  save(addAdminRequest: AddAdminRequest):
    Observable<AddAdminSaveResponse> {
    const headers = new HttpHeaders();

    return this.http.post(this.ADD_ADMIN_URL,
      addAdminRequest, { headers }).pipe(map(
        (response: SaveResponse) => {
          return response;
        }
      ));
  }
}


export class AddAdminRequest {

  public constructor(public email: string, public firstName: string,
    public lastName: string, public password: string,
    public phone: string, public organisationId: number) {

  }
}

export class AddAdminSaveResponse {

  public constructor(public saved: boolean, public error: string) {

  }
}

export class SaveResponse {

  public constructor(public saved: boolean, public error: string) {

  }
}

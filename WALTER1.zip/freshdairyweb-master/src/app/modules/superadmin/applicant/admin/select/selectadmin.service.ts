import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import {
  SuperAdminAdminInitialData,
  AdminDeleteResponse
} from './selectadmin-request-response';

@Injectable({
  providedIn: 'root'
})
export class SelectadminService {

  GET_ADMINS_INITIAL_DATA_URL =
    '/freshdairy/superadmin/applicant/admin/select/getinitialdata';

  DELETE_ADMIN_URL = '/freshdairy/superadmin/applicant/admin/delete';

  constructor(private http: HttpClient) {

  }

  getInitialData(organisationId: number): Observable<SuperAdminAdminInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.GET_ADMINS_INITIAL_DATA_URL, organisationId, httpOptions).pipe(map(
        (response: SuperAdminAdminInitialData) => {
          return response;
        }
      ));
  }

  delete(adminApplicantIdToDelete: number): Observable<AdminDeleteResponse> {
    // need to veryify that logged in user is super admin and that person being
    // deleted has no relationships and is an admin.
    const body = JSON.stringify(adminApplicantIdToDelete);

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(
      this.DELETE_ADMIN_URL, body, httpOptions).pipe(map(
        (response: AdminDeleteResponse) => {
          return response;
        }
      ));
  }
}

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgSelectModule } from '@ng-select/ng-select';
import { CountdownModule } from 'ngx-countdown';
import { PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface, PerfectScrollbarModule } from 'ngx-perfect-scrollbar';

import { EqualValidator } from '../../directive/equalvalidator.directive';
import { SharedroutingModule } from './shared.routing.module';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { TranslateModule } from '@ngx-translate/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSliderModule } from '@angular/material/slider';
import { MatSelectModule } from '@angular/material/select';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatSortModule } from '@angular/material/sort';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatBadgeModule } from '@angular/material/badge';
import { NgxImgModule } from 'ngx-img';
import {
  MatRippleModule, MatFormFieldModule,
  MatTabsModule, MatChipsModule, MatAutocompleteModule, MatExpansionModule, MatDialogModule
} from '@angular/material';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true,
  suppressScrollX: true
};

@NgModule({
  imports: [
    CommonModule,
    CountdownModule,
    NgSelectModule,
    ReactiveFormsModule,
    TranslateModule.forChild(),
    SharedroutingModule,
    FlexLayoutModule,
    MatButtonModule,
    NgxImgModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatRadioModule,
    MatGridListModule,
    MatIconModule,
    MatMenuModule,
    MatDatepickerModule,
    MatSliderModule,
    MatSidenavModule,
    MatToolbarModule,
    MatSelectModule,
    MatSortModule,
    MatSnackBarModule,
    MatExpansionModule,
    MatBadgeModule,
    MatTabsModule,
    MatChipsModule,
    MatDialogModule,
    MatAutocompleteModule,
    PerfectScrollbarModule
  ],
  declarations: [
    EqualValidator,
  ],
  exports: [
    CountdownModule,
    NgSelectModule,
    EqualValidator,
    FlexLayoutModule,
    MatButtonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatIconModule,
    MatMenuModule,
    MatDatepickerModule,
    MatRadioModule,
    MatGridListModule,
    MatSidenavModule,
    MatSelectModule,
    MatSortModule,
    MatSliderModule,
    MatToolbarModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    MatBadgeModule,
    MatTabsModule,
    NgxImgModule,
    MatChipsModule,
    MatExpansionModule,
    MatDialogModule,
    MatAutocompleteModule,
    PerfectScrollbarModule,
  ],

  entryComponents: [
  ],
  providers: [
    { provide: PERFECT_SCROLLBAR_CONFIG, useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG },
  ]
})
export class SharedModule {

}


import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '../../services/user/user.service';
import { ConfigService } from '../../services/config/config.service';

@Component({
  selector: 'app-menu',
  templateUrl: './bottomheader.component.html',
  styleUrls: ['./bottomheader.component.scss']
})
export class BottomHeaderComponent implements OnInit {
  privateMode = true;

  constructor(
    private userService: UserService,
    public translateService: TranslateService,
    private configService: ConfigService
  ) {

  }

  ngOnInit() {

  }

  openMegaMenu() {
    const pane = document.getElementsByClassName('cdk-overlay-pane');
    [].forEach.call(pane, function (el) {
      if (el.children.length > 0) {
        if (el.children[0].classList.contains('mega-menu')) {
          el.classList.add('mega-menu-pane');
        }
      }
    });
  }


  isLoggedIn(): boolean {
    if (this.userService.authorities === undefined) {
      return false;
    }
    return this.userService.isLoggedIn();
  }

}

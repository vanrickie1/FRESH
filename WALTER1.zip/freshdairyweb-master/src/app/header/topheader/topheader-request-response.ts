
export class TopHeaderInitialData {

    public constructor(
        public flags: Flag[]) {

    }
}

export class Flag {

    public constructor(public urlFlag: string,
        public languageCode: string, public title: string) {

    }
}



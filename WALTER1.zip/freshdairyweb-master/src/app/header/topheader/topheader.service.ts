import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { TranslateService } from '@ngx-translate/core';
import { TopHeaderInitialData, Flag } from './topheader-request-response';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class TopHeaderService {
  public flags: Flag[];
  GET_TOP_HEADER_INITIAL_DATA_URL = '/freshdairy/header/gettopheaderinitialdata';

  constructor(
    private http: HttpClient,
    private translateService: TranslateService) {

  }

  getInitialData(): Observable<TopHeaderInitialData> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };

    return this.http.post(this.GET_TOP_HEADER_INITIAL_DATA_URL, httpOptions).pipe(map(
      (response: TopHeaderInitialData) => {
        return response;
      }
    ));
  }
}

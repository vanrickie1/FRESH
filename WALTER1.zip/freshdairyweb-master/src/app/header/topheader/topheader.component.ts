import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user/user.service';
import { LoginService } from '../../login/login.service';
import { TopHeaderInitialData } from './topheader-request-response';
import { TopHeaderService } from './topheader.service';

@Component({
  selector: 'app-top-menu',
  styleUrls: ['./topheader.component.scss'],
  templateUrl: './topheader.component.html'
})
export class TopHeaderComponent implements OnInit {
  error: string;
  email: string;
  firstName: String;
  dashboardUrls: string[];
  dashboardTitles: string[];
  initialData: TopHeaderInitialData;

  constructor(
    public router: Router,
    private headerService: TopHeaderService,
    private userService: UserService,
    private loginService: LoginService,
  ) {
  }

  ngOnInit() {
    this.loadUserDashboard();
  }

  private loadUserDashboard(): void {
    this.dashboardUrls = this.userService.dashboardTitles;
    this.dashboardTitles = this.userService.dashboardUrls;

  }

  isLoggedIn(): boolean {
    const loggedInUsername = this.userService.loggedInUsername;
    this.dashboardUrls = this.userService.dashboardUrls;
    this.dashboardTitles = this.userService.dashboardTitles;
    this.email = loggedInUsername;
    this.firstName = this.loginService.firstName;
    if (this.userService.authorities === undefined) {
      return false;
    }
    return this.userService.isLoggedIn();
  }

  hasPermission(permission: string): boolean {
    return this.userService.hasPermission(permission);
  }

}


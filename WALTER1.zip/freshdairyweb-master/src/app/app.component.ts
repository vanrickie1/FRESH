import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Settings, AppSettings } from './app.settings';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  loading = false;
  organisationName: string;
  public settings: Settings;
  constructor(public appSettings: AppSettings,
    private router: Router,
    private translateService: TranslateService) {
    this.settings = this.appSettings.settings;
  }

  ngOnInit() {
    this.getInitialData();
  }

  ngAfterViewInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        window.scrollTo(0, 0);
      }
    });
  }

  private getInitialData(): void {
    this.setDefaultLang();
  }

  private setDefaultLang() {
    this.translateService.addLangs(['en']);
    this.translateService.setDefaultLang('en');
    this.translateService.use('en');
    localStorage.setItem('locale', this.translateService.currentLang);
  }
}

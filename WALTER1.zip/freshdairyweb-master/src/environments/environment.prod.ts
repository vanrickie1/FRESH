export const environment = {
  production: true,
  email: 'error_freshdairyscore@gmail.com',
  debug: false
};
